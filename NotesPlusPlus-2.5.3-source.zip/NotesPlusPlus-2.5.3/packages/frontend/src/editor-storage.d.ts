import type { MarkdownStorage } from "tiptap-markdown";

import type { SearchStorage } from "./components/content/editor/extensions/search";

declare module "@tiptap/core" {
  interface Storage {
    search: SearchStorage;
    reminderNode: { isContentReplacement: boolean };
    markdown: MarkdownStorage;
  }
}
