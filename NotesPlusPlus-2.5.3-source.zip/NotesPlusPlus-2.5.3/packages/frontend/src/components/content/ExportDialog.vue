<script setup lang="ts">
import Button from "primevue/button";
import Dialog from "primevue/dialog";
import Select from "primevue/select";
import type { Folder, Note } from "shared";
import { onMounted, ref, watch } from "vue";

import { useSDK } from "@/plugins/sdk";
import { download } from "@/utils/evidence";
import { prepareExport } from "@/utils/export";
import { exportContext, serializeMarkdown } from "@/utils/markdownExport";

const props = defineProps<{
  tree: Folder;
  note?: Note;
  copy?: boolean;
  projectId: string;
}>();
const emit = defineEmits<{ close: [] }>();
const sdk = useSDK();
const scope = ref<"Note" | "Folder" | "Project">(
  props.note === undefined ? "Project" : "Note",
);
const busy = ref(false);
const failure = ref("");
const warnings = ref<string[]>([]);
let result: Awaited<ReturnType<typeof prepareExport>> | undefined;
let markdown: string | undefined;
watch(scope, () => {
  warnings.value = [];
  result = undefined;
  markdown = undefined;
  failure.value = "";
});
onMounted(() => {
  if (props.copy) void prepare();
});
async function deliver() {
  try {
    if (markdown !== undefined) await navigator.clipboard.writeText(markdown);
    else if (result !== undefined)
      download(result.data, result.name, result.type);
    emit("close");
  } catch (cause) {
    failure.value = String(cause);
  }
}
async function prepare() {
  busy.value = true;
  failure.value = "";
  warnings.value = [];
  result = undefined;
  markdown = undefined;
  try {
    const project = await sdk.backend.getCurrentProjectId();
    if (project.kind === "Error" || project.value !== props.projectId)
      throw new Error("Project changed. Reopen the export dialog.");
    if (props.copy && props.note !== undefined) {
      const context = exportContext(true);
      context.project = props.projectId;
      markdown = await serializeMarkdown(props.note.content, sdk, context);
      const source = props.note.association;
      if (source !== undefined)
        markdown =
          `Replay session: ${source.sessionId}${source.entryId === undefined ? "" : ` · Execution: ${source.entryId}`}\n\n` +
          markdown;
      const active = await sdk.backend.getCurrentProjectId();
      if (active.kind === "Error" || active.value !== props.projectId)
        throw new Error("Project changed during export");
      warnings.value = context.warnings;
    } else {
      result = await prepareExport(sdk, props.tree, props.note, scope.value);
      warnings.value = result.warnings;
    }
    if (warnings.value.length === 0) await deliver();
  } catch (cause) {
    failure.value = String(cause);
  } finally {
    busy.value = false;
  }
}
</script>
<template>
  <Dialog
    append-to="self"
    :visible="true"
    modal
    :header="copy ? 'Copy as Markdown' : 'Export Markdown'"
    :style="{ width: '540px', maxWidth: '95vw' }"
    @update:visible="emit('close')"
  >
    <div class="npp-form">
      <Select
        v-if="!copy"
        v-model="scope"
        append-to="self"
        :options="note ? ['Note', 'Folder', 'Project'] : ['Project']"
        :disabled="busy"
        aria-label="Export scope"
      />
      <p>
        Folder exports include the current note’s folder and its descendants.
        Assets are included in ZIP exports. Fonts, underline, and highlights use
        restricted HTML supported by some Markdown viewers.
      </p>
      <p v-if="failure" role="alert">{{ failure }}</p>
      <ul v-if="warnings.length">
        <li v-for="(warning, index) in warnings" :key="index">{{ warning }}</li>
      </ul>
      <Button
        :label="busy ? 'Preparing…' : copy ? 'Copy' : 'Export'"
        :disabled="busy"
        @click="prepare"
      />
      <Button
        v-if="warnings.length"
        :label="copy ? 'Copy with placeholders' : 'Download with placeholders'"
        @click="deliver"
      />
    </div>
  </Dialog>
</template>
