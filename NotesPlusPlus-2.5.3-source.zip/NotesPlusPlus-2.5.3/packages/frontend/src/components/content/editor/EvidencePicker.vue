<script setup lang="ts">
import type { Editor } from "@tiptap/core";
import Button from "primevue/button";
import Dialog from "primevue/dialog";
import InputText from "primevue/inputtext";
import Select from "primevue/select";
import { computed, onBeforeUnmount, onMounted, ref, watch } from "vue";

import { useSDK } from "@/plugins/sdk";
import { captureFinding, captureReplay, type Parts } from "@/utils/evidence";

const props = defineProps<{
  editor: Editor;
  range?: { from: number; to: number };
  initial?: string;
}>();
const emit = defineEmits<{ close: [] }>();
const sdk = useSDK();
const category = ref(props.initial === "findings" ? "Findings" : "Replay");
const query = ref("");
const selected = ref<string>();
const execution = ref("draft");
const mode = ref("Snapshot");
const parts = ref<Parts>("request");
const busy = ref(false);
const failure = ref("");
const project = ref("");
const findings = ref<{ id: string; label: string }[]>([]);
const history = ref<{ id: string; label: string }[]>([]);
const page = ref(0);
const more = ref(false);
let generation = 0;
let remaining: string[] = [];
const moreHistory = ref(false);
const baseline = JSON.stringify(props.editor.getJSON());
onBeforeUnmount(() => {
  generation++;
});
const items = computed(() =>
  (category.value === "Replay"
    ? sdk.replay
        .getSessions()
        .map((session) => ({ id: session.id, label: session.name }))
    : findings.value
  ).filter((item) =>
    item.label.toLowerCase().includes(query.value.toLowerCase()),
  ),
);
const choices = computed(() =>
  (category.value === "Findings"
    ? ["none", "request", "response", "both"]
    : execution.value === "draft"
      ? ["request"]
      : ["request", "response", "both"]
  ).map((value) => ({
    value,
    label: (
      {
        none: "Finding only",
        request: "Request",
        response: "Response",
        both: "Request + Response",
      } as Record<string, string>
    )[value],
  })),
);
async function loadFindings() {
  const token = generation;
  busy.value = true;
  failure.value = "";
  try {
    const result = await sdk.graphql.getFindingsByOffset({
      offset: page.value * 50,
      limit: 50,
      filter: {},
      order: { by: "ID", ordering: "DESC" },
    });
    if (token !== generation) return;
    findings.value.push(
      ...result.findingsByOffset.edges.map(({ node }) => ({
        id: node.id,
        label: `${node.title} — ${node.host}${node.path}`,
      })),
    );
    more.value = result.findingsByOffset.edges.length === 50;
    page.value++;
  } catch (cause) {
    if (token === generation) failure.value = String(cause);
  } finally {
    if (token === generation) busy.value = false;
  }
}
watch(category, () => {
  selected.value = undefined;
  parts.value = category.value === "Findings" ? "none" : "request";
  if (category.value === "Findings" && page.value === 0) void loadFindings();
});
async function loadHistory() {
  const token = generation;
  busy.value = true;
  failure.value = "";
  try {
    for (const id of remaining.slice(0, 25)) {
      if (token !== generation) return;
      const entry = sdk.replay.getEntry(id);
      if (entry.requestId === undefined) {
        remaining.shift();
        continue;
      }
      const { request } = await sdk.graphql.request({ id: entry.requestId });
      if (token !== generation) return;
      if (request !== undefined && request !== null)
        history.value.push({
          id,
          label:
            new Date(request.createdAt).toLocaleString() +
            " · " +
            request.method +
            " " +
            request.host +
            request.path +
            " · " +
            (request.response?.statusCode ?? "No response"),
        });
      remaining.shift();
    }
  } catch (cause) {
    if (token === generation) failure.value = String(cause);
  } finally {
    if (token === generation) {
      busy.value = false;
      moreHistory.value = remaining.length > 0;
    }
  }
}
watch(selected, async () => {
  if (category.value === "Replay") generation++;
  history.value = [];
  execution.value = "draft";
  remaining = [];
  moreHistory.value = false;
  parts.value = category.value === "Replay" ? "request" : "none";
  if (category.value !== "Replay" || selected.value === undefined) return;
  remaining = [
    ...(sdk.replay.getSessions().find((item) => item.id === selected.value)
      ?.entryIds ?? []),
  ].reverse();
  await loadHistory();
});
watch(execution, () => {
  if (category.value !== "Replay") return;
  parts.value = execution.value === "draft" ? "request" : "both";
  mode.value = "Snapshot";
});
async function insert() {
  if (selected.value === undefined || project.value === "") return;
  const token = generation;
  busy.value = true;
  failure.value = "";
  try {
    const current = await sdk.backend.getCurrentProjectId();
    if (current.kind === "Error" || current.value !== project.value)
      throw new Error("Project changed. Reopen the evidence picker.");
    const content =
      category.value === "Findings"
        ? await captureFinding(sdk, selected.value, parts.value, project.value)
        : await captureReplay(
            sdk,
            selected.value,
            execution.value === "draft" ? undefined : execution.value,
            parts.value,
            project.value,
          );
    let attrs: Record<string, unknown>;
    if (
      mode.value === "Live" &&
      category.value === "Replay" &&
      execution.value === "draft"
    )
      attrs = {
        sessionId: selected.value,
        projectId: project.value,
        live: true,
      };
    else {
      const result = await sdk.backend.saveEvidence(project.value, content);
      if (result.kind === "Error") throw new Error(result.error);
      attrs = { evidenceId: result.value.id, projectId: project.value };
    }
    const active = await sdk.backend.getCurrentProjectId();
    if (token !== generation) return;
    if (
      active.kind === "Error" ||
      active.value !== project.value ||
      JSON.stringify(props.editor.getJSON()) !== baseline
    )
      throw new Error(
        "The note or project changed. Reopen the evidence picker.",
      );
    if (props.editor.isDestroyed) throw new Error("The note editor was closed");
    const chain = props.editor.chain().focus();
    if (props.range !== undefined) chain.deleteRange(props.range);
    chain.insertContent({ type: "evidence", attrs }).run();
    emit("close");
  } catch (cause) {
    failure.value = String(cause);
  } finally {
    busy.value = false;
  }
}
onMounted(async () => {
  const result = await sdk.backend.getCurrentProjectId();
  if (result.kind === "Success" && result.value !== undefined)
    project.value = result.value;
  else
    failure.value =
      result.kind === "Error" ? result.error : "No active project";
  if (category.value === "Findings") await loadFindings();
});
</script>
<template>
  <Dialog
    append-to="self"
    :visible="true"
    modal
    header="Insert evidence"
    :style="{ width: '640px', maxWidth: '95vw' }"
    @update:visible="emit('close')"
  >
    <div class="npp-form">
      <Select
        v-model="category"
        :disabled="busy"
        append-to="self"
        :options="['Replay', 'Findings']"
        aria-label="Evidence category"
      />
      <InputText
        v-model="query"
        placeholder="Search loaded sources…"
        aria-label="Search sources"
      />
      <Select
        v-model="selected"
        :disabled="busy"
        append-to="self"
        :options="items"
        option-label="label"
        option-value="id"
        placeholder="Select a source"
        aria-label="Source"
      />
      <Button
        v-if="category === 'Findings' && (more || page === 0)"
        :label="page === 0 ? 'Load findings' : 'Load more findings'"
        :disabled="busy"
        @click="loadFindings"
      />
      <Select
        v-if="category === 'Replay' && selected"
        v-model="execution"
        :disabled="busy"
        append-to="self"
        :options="[{ id: 'draft', label: 'Current draft' }, ...history]"
        option-label="label"
        option-value="id"
        aria-label="Execution"
      />
      <Button
        v-if="category === 'Replay' && moreHistory"
        label="Load more executions"
        :disabled="busy"
        @click="loadHistory"
      />
      <Select
        v-model="parts"
        :disabled="busy"
        append-to="self"
        :options="choices"
        option-label="label"
        option-value="value"
        aria-label="Include request, response, both, or no HTTP evidence"
      />
      <Select
        v-if="category === 'Replay' && execution === 'draft'"
        v-model="mode"
        :disabled="busy"
        append-to="self"
        :options="['Snapshot', 'Live']"
        aria-label="Snapshot or live reference"
      />
      <p v-if="busy" role="status">Loading…</p>
      <p v-if="failure" role="alert">{{ failure }}</p>
      <p>
        Snapshots preserve evidence. Live references follow the current Replay
        draft. Drafts have no response.
      </p>
      <Button
        label="Insert evidence"
        :disabled="busy || !selected || !project"
        @click="insert"
      />
    </div>
  </Dialog>
</template>
