<script setup lang="ts">
import { nodeViewProps, NodeViewWrapper } from "@tiptap/vue-3";
import Button from "primevue/button";
import type { Evidence } from "shared";
import { computed, onBeforeUnmount, ref, watch } from "vue";

import HttpEvidenceView from "./HttpEvidenceView.vue";

import type { FrontendSDK } from "@/types";
import { emitter } from "@/utils/eventBus";
import {
  bytes,
  captureFinding,
  captureReplay,
  download,
  httpText,
} from "@/utils/evidence";

const props = defineProps(nodeViewProps);
const sdk = props.extension.options.sdk as FrontendSDK;
const evidence = ref<Evidence>();
const collapsed = ref(false);
const failure = ref("");
let generation = 0;
const pieces = computed(() =>
  [
    { label: "Request" as const, raw: evidence.value?.request },
    { label: "Response" as const, raw: evidence.value?.response },
  ].filter(
    (item): item is { label: "Request" | "Response"; raw: string } =>
      item.raw !== undefined,
  ),
);
async function load() {
  const token = ++generation;
  failure.value = "";
  evidence.value = undefined;
  try {
    const attrs = props.node.attrs;
    const project = await sdk.backend.getCurrentProjectId();
    if (
      project.kind === "Error" ||
      project.value === undefined ||
      project.value !== attrs.projectId
    )
      throw new Error("Evidence belongs to another project");
    let value: Evidence;
    if (attrs.live === true)
      value = {
        ...(await captureReplay(
          sdk,
          String(attrs.sessionId),
          undefined,
          "request",
        )),
        id: "live",
        projectId: project.value,
        capturedAt: new Date().toISOString(),
      };
    else {
      const result = await sdk.backend.getEvidence(
        project.value,
        String(attrs.evidenceId),
      );
      if (result.kind === "Error") throw new Error(result.error);
      value = result.value;
    }
    if (generation === token) evidence.value = value;
  } catch (cause) {
    if (generation === token) failure.value = String(cause);
  }
}
async function refreshFinding() {
  const current = evidence.value;
  const token = generation;
  if (current?.findingId === undefined) return;
  try {
    const parts =
      current.request !== undefined
        ? current.response !== undefined
          ? "both"
          : "request"
        : current.response !== undefined
          ? "response"
          : "none";
    const result = await sdk.backend.saveEvidence(
      current.projectId,
      await captureFinding(sdk, current.findingId, parts, current.projectId),
    );
    if (result.kind === "Error") throw new Error(result.error);
    if (generation !== token) return;
    props.updateAttributes({ evidenceId: result.value.id });
  } catch (cause) {
    failure.value = String(cause);
  }
}
async function openSource() {
  try {
    const item = evidence.value;
    if (item?.sessionId === undefined) return;
    if (item.entryId !== undefined)
      await sdk.replay.showEntry(item.sessionId, item.entryId);
    else sdk.replay.openTab(item.sessionId);
    sdk.navigation.goTo("/replay");
  } catch (cause) {
    failure.value = String(cause);
  }
}
async function copy() {
  try {
    await navigator.clipboard.writeText(
      [
        evidence.value?.title,
        evidence.value?.description,
        ...pieces.value.map(
          (item) =>
            `${item.label}\n${httpText(item.raw) ?? "[Binary evidence: use Download]"}`,
        ),
      ]
        .filter(Boolean)
        .join("\n\n"),
    );
  } catch (cause) {
    failure.value = String(cause);
  }
}
watch(() => props.node.attrs, load, { immediate: true });
const refresh = () => {
  if (props.node.attrs.live === true) void load();
};
emitter.on("refreshEditors", refresh);
onBeforeUnmount(() => {
  generation++;
  emitter.off("refreshEditors", refresh);
});
</script>
<template>
  <NodeViewWrapper class="npp-evidence" contenteditable="false">
    <div class="npp-actions">
      <Button
        :icon="collapsed ? 'fas fa-chevron-right' : 'fas fa-chevron-down'"
        :aria-label="collapsed ? 'Expand evidence' : 'Collapse evidence'"
        @click="collapsed = !collapsed"
      />
      <strong>{{ evidence?.title ?? "Evidence" }}</strong>
      <span>{{ node.attrs.live ? "Live draft" : "Snapshot" }}</span>
      <Button icon="fas fa-copy" aria-label="Copy evidence" @click="copy" />
      <Button
        v-if="evidence?.sessionId"
        icon="fas fa-external-link-alt"
        aria-label="Open Replay source"
        @click="openSource"
      />
      <Button
        v-if="node.attrs.live"
        icon="fas fa-sync"
        aria-label="Refresh live draft"
        @click="load"
      />
      <Button
        v-if="evidence?.findingId"
        icon="fas fa-sync"
        aria-label="Refresh finding snapshot"
        @click="refreshFinding"
      />
      <Button
        v-if="editor.isEditable"
        icon="fas fa-times"
        aria-label="Remove evidence from note"
        @click="deleteNode"
      />
    </div>
    <p v-if="failure" role="alert">{{ failure }}</p>
    <div v-if="!collapsed && evidence">
      <small
        >{{ evidence.capturedAt }} · {{ evidence.endpoint }}
        {{ evidence.reporter }}</small
      >
      <p style="white-space: pre-wrap">{{ evidence.description }}</p>
      <section v-for="item in pieces" :key="item.label">
        <div class="npp-actions">
          <strong>{{ item.label }}</strong
          ><Button
            class="npp-icon-button"
            icon="fas fa-download"
            :aria-label="`Download original ${item.label.toLowerCase()}`"
            :title="`Download original ${item.label.toLowerCase()}`"
            @click="
              download(
                bytes(item.raw),
                `${evidence.id}-${item.label.toLowerCase()}.http`,
              )
            "
          />
        </div>
        <HttpEvidenceView
          v-if="httpText(item.raw) !== undefined"
          :sdk="sdk"
          :kind="item.label"
          :text="httpText(item.raw) ?? ''"
        />
        <p v-else>Binary content. Download the original bytes to inspect it.</p>
      </section>
      <p v-if="evidence.response === undefined && evidence.kind === 'replay'">
        No response included. Drafts have no response; historical responses may
        be absent or excluded.
      </p>
    </div>
  </NodeViewWrapper>
</template>
