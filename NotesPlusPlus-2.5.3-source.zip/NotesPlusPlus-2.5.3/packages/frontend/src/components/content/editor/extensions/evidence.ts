import { Node } from "@tiptap/core";
import { VueNodeViewRenderer } from "@tiptap/vue-3";

import EvidenceCard from "../EvidenceCard.vue";

import type { FrontendSDK } from "@/types";

export function evidenceExtension(sdk: FrontendSDK) {
  return Node.create({
    name: "evidence",
    group: "block",
    atom: true,
    draggable: true,
    addOptions: () => ({ sdk }),
    addAttributes: () => ({
      evidenceId: { default: "" },
      projectId: { default: "" },
      sessionId: { default: "" },
      live: { default: false },
    }),
    // Evidence can only be inserted through trusted JSON, never pasted HTML.
    parseHTML: () => [],
    renderHTML: () => ["div", {}, "[Notes++ evidence]"],
    addNodeView: () => VueNodeViewRenderer(EvidenceCard),
  });
}
