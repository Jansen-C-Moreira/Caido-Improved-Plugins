import { EditorState, StateEffect } from "@codemirror/state";
import { Mention } from "@tiptap/extension-mention";

import { type FrontendSDK } from "@/types";
import { emitter } from "@/utils/eventBus";
import { fetchReplaySessionContent } from "@/utils/replay";

const styleId = "embedded-replay-editor-style";
if (!document.getElementById(styleId)) {
  const style = document.createElement("style");
  style.id = styleId;
  style.textContent = `
    .embedded-replay-editor {
      display: inline-block;
      overflow: auto;
      margin: 12px 0;
      border: 2px solid var(--color-surface-600, #444);
      border-radius: 6px;
      cursor: pointer;
      width: 100%;
      min-height: 50px;
      max-height: 300px;
      position: relative;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      transition: box-shadow 0.2s ease, border-color 0.2s ease;
    }
    .embedded-replay-editor:hover {
      border-color: var(--color-primary-500, #6366f1);
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
    }
    .embedded-replay-label {
      position: absolute;
      top: 4px;
      right: 38px;
      background: var(--color-surface-800, #262626);
      color: var(--color-surface-200, #e5e5e5);
      font-size: 12px;
      padding: 3px 8px;
      border-radius: 4px;
      z-index: 10;
      font-weight: 500;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      cursor: pointer;
      transition: background 0.2s ease, color 0.2s ease;
    }
    .embedded-replay-editor:hover .embedded-replay-label {
      background: var(--color-primary-500, #6366f1);
      color: var(--color-surface-100, #fff);
    }
    .embedded-replay-remove {
      position: absolute;
      top: 4px;
      right: 4px;
      z-index: 11;
      width: 26px;
      height: 26px;
      display: grid;
      place-items: center;
      border: 1px solid var(--color-surface-500, #666);
      border-radius: 4px;
      color: var(--color-surface-200, #e5e5e5);
      background: var(--color-surface-800, #262626);
      cursor: pointer;
    }
    .embedded-replay-remove:hover,
    .embedded-replay-remove:focus-visible {
      color: #fff;
      background: #a12b35;
      outline: 2px solid var(--color-primary-500, #6366f1);
    }
  `;
  document.head.appendChild(style);
}

export const createSessionMention = (sdk: FrontendSDK) => {
  return Mention.extend({
    addNodeView() {
      return (node) => {
        const container = document.createElement("div");
        container.className = "embedded-replay-editor";

        const label = document.createElement("div");
        label.className = "embedded-replay-label";
        label.textContent = `Live Replay: ${node.node.attrs.label}`;
        container.appendChild(label);

        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "embedded-replay-remove";
        remove.title = "Remove request from note";
        remove.setAttribute("aria-label", "Remove request from note");
        remove.contentEditable = "false";
        const icon = document.createElement("i");
        icon.className = "fas fa-times";
        icon.setAttribute("aria-hidden", "true");
        remove.appendChild(icon);
        remove.addEventListener("mousedown", (event) => {
          event.preventDefault();
          event.stopPropagation();
        });
        remove.addEventListener("dblclick", (event) => event.stopPropagation());
        remove.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          if (!node.editor.isEditable) return;
          const position = node.getPos();
          if (position === undefined) return;
          node.editor.commands.deleteRange({
            from: position,
            to: position + node.node.nodeSize,
          });
        });
        if (node.editor.isEditable) container.appendChild(remove);

        const editorWrapper = document.createElement("div");
        editorWrapper.style.width = "100%";
        editorWrapper.style.height = "100%";
        container.appendChild(editorWrapper);
        const controls = document.createElement("div");
        controls.style.cssText =
          "display:flex;gap:8px;padding:6px;margin-top:30px";
        container.insertBefore(controls, editorWrapper);
        const collapse = document.createElement("button");
        collapse.type = "button";
        collapse.textContent = "Collapse";
        collapse.setAttribute("aria-label", "Collapse live request");
        collapse.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          editorWrapper.hidden = !editorWrapper.hidden;
          collapse.textContent = editorWrapper.hidden ? "Expand" : "Collapse";
        });
        const copy = document.createElement("button");
        copy.type = "button";
        copy.textContent = "Copy";
        copy.setAttribute("aria-label", "Copy live request");
        let displayed = "";
        copy.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          void navigator.clipboard.writeText(displayed).catch(() =>
            sdk.window.showToast("Could not copy request", {
              variant: "error",
            }),
          );
        });
        controls.append(collapse, copy);

        let destroyed = false;
        let generation = 0;
        const loadSessionData = async (sessionId: string): Promise<void> => {
          const currentGeneration = ++generation;
          try {
            const sessionContent = await fetchReplaySessionContent(
              sdk,
              sessionId,
            );
            if (destroyed || generation !== currentGeneration) return;
            displayed = sessionContent;
            const requestEditor = sdk.ui.httpRequestEditor();
            const editorElement = requestEditor.getElement();
            editorElement.style.width = "100%";
            editorElement.style.height = "100%";

            editorWrapper.innerHTML = "";
            editorWrapper.appendChild(editorElement);

            requestAnimationFrame(() => {
              if (destroyed || generation !== currentGeneration) return;
              try {
                const view = requestEditor.getEditorView();
                if (view?.state?.doc) {
                  view.dispatch({
                    effects: StateEffect.appendConfig.of(
                      EditorState.readOnly.of(true),
                    ),
                    changes: {
                      from: 0,
                      to: view.state.doc.length,
                      insert: sessionContent,
                    },
                  });
                }
              } catch (err) {
                console.error("Couldn't set editor content:", err);
              }
            });
          } catch (error) {
            console.error("Error fetching session data:", error);
            if (!destroyed && generation === currentGeneration)
              editorWrapper.textContent =
                error instanceof Error
                  ? error.message
                  : "Error loading Replay data";
          }
        };

        loadSessionData(node.node.attrs.id);

        const refresh = () => {
          void loadSessionData(node.node.attrs.id);
        };
        emitter.on("refreshEditors", refresh);

        container.addEventListener("dblclick", () => {
          sdk.replay.openTab(node.node.attrs.id);
          sdk.navigation.goTo("/replay");
        });

        return {
          dom: container,
          stopEvent: (event) =>
            event.target instanceof globalThis.Node &&
            (remove.contains(event.target) || controls.contains(event.target)),
          destroy: () => {
            destroyed = true;
            emitter.off("refreshEditors", refresh);
          },
        };
      };
    },
  });
};
