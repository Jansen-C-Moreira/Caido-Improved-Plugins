import { mergeAttributes } from "@tiptap/core";
import { Image } from "@tiptap/extension-image";

export const CustomImage = Image.extend({
  name: "image",

  addAttributes() {
    return {
      ...this.parent?.(),
      src: {
        default: null,
      },
      alt: {
        default: null,
      },
      title: {
        default: null,
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: "img[src]",
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    const src: unknown = HTMLAttributes.src;
    if (
      typeof src !== "string" ||
      !/^data:image\/(png|jpeg|gif|webp);base64,[a-z0-9+/=\s]+$/i.test(src)
    ) {
      return ["span", { class: "text-surface-400" }, "[Remote image blocked]"];
    }
    return [
      "img",
      mergeAttributes(this.options.HTMLAttributes, HTMLAttributes),
    ];
  },
});
