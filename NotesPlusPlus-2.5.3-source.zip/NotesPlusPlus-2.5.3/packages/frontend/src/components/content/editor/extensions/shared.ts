import { Placeholder } from "@tiptap/extension-placeholder";
import {
  Table,
  TableCell,
  TableHeader,
  TableRow,
} from "@tiptap/extension-table";
import { StarterKit } from "@tiptap/starter-kit";

import { ArrowKeysFix } from "./arrows-fix";
import { CustomImage } from "./custom-image";
import { evidenceExtension } from "./evidence";
import { Font, Highlight, safeLink } from "./format";
import { MarkdownHeading } from "./markdown-heading";
import MarkdownStyling from "./markdown-styling";
import { createFileMention } from "./mentions/mention-file";
import { createSessionMention } from "./mentions/mention-request";
import createSuggestion from "./mentions/suggestion";
import { ReminderNode } from "./reminder-node";
import { Search } from "./search";
import { SlashCommands } from "./slash-commands";

import type { FrontendSDK } from "@/types";

export function editorExtensions(sdk: FrontendSDK) {
  return [
    StarterKit.configure({
      heading: false,
      link: { openOnClick: false, autolink: false, isAllowedUri: safeLink },
    }),
    MarkdownHeading,
    MarkdownStyling,
    ArrowKeysFix,
    Font,
    Highlight,
    // @ts-expect-error Existing suggestion popup uses undefined for the client rectangle.
    createSessionMention(sdk).configure({ suggestion: createSuggestion(sdk) }),
    createFileMention(sdk),
    evidenceExtension(sdk),
    ReminderNode,
    Search.configure({
      searchResultClass: "search-result",
      disableRegex: true,
    }),
    Placeholder.configure({ placeholder: "Write something…" }),
    CustomImage.configure({
      allowBase64: true,
      HTMLAttributes: { class: "caido-image" },
    }),
    Table.configure({
      resizable: true,
      HTMLAttributes: { class: "notes-table" },
    }),
    TableRow,
    TableHeader,
    TableCell,
    SlashCommands.configure({ sdk }),
  ];
}
