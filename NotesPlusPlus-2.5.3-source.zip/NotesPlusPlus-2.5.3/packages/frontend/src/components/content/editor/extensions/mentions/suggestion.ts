import { type Editor } from "@tiptap/core";
import { VueRenderer } from "@tiptap/vue-3";
import tippy, { type Instance, type Props } from "tippy.js";

import EvidencePicker from "../../EvidencePicker.vue";

//@ts-expect-error - Vue component import throws error here
import ReferenceList from "./List.vue";

import { type FrontendSDK } from "@/types";
import { popup } from "@/utils/popup";

interface SessionItem {
  id: string;
  label: string;
}

interface SuggestionProps {
  editor: Editor;
  clientRect?: (() => DOMRect | undefined) | undefined;
  event?: KeyboardEvent;
  range?: { from: number; to: number };
  command: (attrs: SessionItem) => void;
  items: SessionItem[];
  query: string;
}

export default function createSuggestion(sdk: FrontendSDK) {
  return {
    items: () => [
      { id: "replay", label: "Replay — draft or execution" },
      { id: "findings", label: "Findings — captured evidence" },
    ],
    command: ({
      editor,
      range,
      props,
    }: {
      editor: Editor;
      range: { from: number; to: number };
      props: SessionItem;
    }) => popup(sdk, EvidencePicker, { editor, range, initial: props.id }),

    render: () => {
      let component: VueRenderer;
      let popup: Instance<Props> | undefined = undefined;

      return {
        onStart: (props: SuggestionProps) => {
          component = new VueRenderer(ReferenceList, {
            props,
            editor: props.editor,
          });

          if (!props.clientRect) {
            return;
          }

          const getReference = () => {
            const rect = props.clientRect?.();
            return rect || new DOMRect(0, 0, 0, 0);
          };

          // @ts-expect-error - Couldn't get tippy types working
          popup = tippy(document.body, {
            getReferenceClientRect: getReference,
            appendTo: () => document.body,
            content: component.element,
            showOnCreate: true,
            interactive: true,
            trigger: "manual",
            placement: "bottom-start",
          });
        },

        onUpdate(props: SuggestionProps) {
          component.updateProps(props);

          if (!props.clientRect || !popup) {
            return;
          }

          const getReference = () => {
            const rect = props.clientRect?.();
            return rect || new DOMRect(0, 0, 0, 0);
          };

          popup.setProps({
            getReferenceClientRect: getReference,
          });
        },

        onKeyDown(props: { event: KeyboardEvent }) {
          if (props.event.key === "Escape" && popup) {
            popup.hide();
            return true;
          }

          return component.ref?.onKeyDown(props);
        },

        onExit() {
          if (popup) {
            popup.destroy();
          }
          component.destroy();
        },
      };
    },
  };
}
