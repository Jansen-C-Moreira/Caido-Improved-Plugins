<script setup lang="ts">
import { Editor as CoreEditor, type Editor } from "@tiptap/core";
import {
  Table,
  TableCell,
  TableHeader,
  TableRow,
} from "@tiptap/extension-table";
import { StarterKit } from "@tiptap/starter-kit";
import Button from "primevue/button";
import Dialog from "primevue/dialog";
import InputText from "primevue/inputtext";
import Select from "primevue/select";
import Textarea from "primevue/textarea";
import { Markdown } from "tiptap-markdown";
import { computed, onBeforeUnmount, onMounted, ref } from "vue";

import EvidencePicker from "./EvidencePicker.vue";
import {
  Font,
  fonts,
  Highlight,
  safeLink,
  sanitizeHTML,
  sizes,
} from "./extensions/format";

import { useSDK } from "@/plugins/sdk";
import { popup } from "@/utils/popup";

const props = defineProps<{ editor: Editor }>();
const sdk = useSDK();
const family = ref("inherit");
const size = ref("16px");
const heading = ref(0);
function selection() {
  heading.value = Number(props.editor.getAttributes("heading").level ?? 0);
  const font = props.editor.getAttributes("font");
  family.value = fonts.includes(font.family) ? font.family : "inherit";
  size.value = sizes.includes(font.size) ? font.size : "16px";
}
onMounted(() => {
  props.editor.on("selectionUpdate", selection);
  props.editor.on("transaction", selection);
  selection();
});
onBeforeUnmount(() => {
  props.editor.off("selectionUpdate", selection);
  props.editor.off("transaction", selection);
});
const markdown = ref("");
const showMarkdown = ref(false);
const showLink = ref(false);
const link = ref("");
const failure = ref("");
const marks = [
  { name: "bold", icon: "bold" },
  { name: "italic", icon: "italic" },
  { name: "underline", icon: "underline" },
  { name: "strike", icon: "strikethrough" },
  { name: "highlight", icon: "highlighter" },
  { name: "code", icon: "code" },
];
const preview = computed(() => {
  const editor = new CoreEditor({
    extensions: [
      StarterKit,
      Font,
      Highlight,
      Table,
      TableRow,
      TableHeader,
      TableCell,
      Markdown.configure({ html: false }),
    ],
    content: markdown.value,
  });
  const html = sanitizeHTML(editor.getHTML());
  editor.destroy();
  return html;
});
function setHeading() {
  if (heading.value === 0) props.editor.chain().focus().setParagraph().run();
  else
    props.editor
      .chain()
      .focus()
      .setMarkdownHeading({ level: heading.value as 1 | 2 | 3 | 4 | 5 | 6 })
      .run();
}
function setLink() {
  if (!safeLink(link.value)) {
    failure.value = "Use an https://, http://, or mailto: URL.";
    return;
  }
  props.editor.chain().focus().setLink({ href: link.value }).run();
  showLink.value = false;
}
</script>
<template>
  <div
    class="npp-toolbar"
    role="toolbar"
    aria-label="Note formatting"
    @mousedown.prevent
  >
    <Select
      v-model="heading"
      append-to="self"
      :options="
        [0, 1, 2, 3, 4, 5, 6].map((level) => ({
          label: level === 0 ? 'Paragraph' : `Heading ${level}`,
          value: level,
        }))
      "
      option-label="label"
      option-value="value"
      aria-label="Text heading"
      @update:model-value="setHeading"
    />
    <Select
      v-model="family"
      append-to="self"
      :options="fonts"
      aria-label="Font family"
      @update:model-value="
        editor.chain().focus().setMark('font', { family, size }).run()
      "
    />
    <Select
      v-model="size"
      append-to="self"
      :options="sizes"
      aria-label="Font size"
      @update:model-value="
        editor.chain().focus().setMark('font', { family, size }).run()
      "
    />
    <Button
      v-for="mark in marks"
      :key="mark.name"
      :icon="`fas fa-${mark.icon}`"
      :aria-label="mark.name"
      :title="mark.name"
      :aria-pressed="editor.isActive(mark.name)"
      @click="editor.chain().focus().toggleMark(mark.name).run()"
    />
    <Button
      icon="fas fa-list-ul"
      aria-label="Bullet list"
      title="Bullet list"
      @click="editor.chain().focus().toggleBulletList().run()"
    />
    <Button
      icon="fas fa-list-ol"
      aria-label="Numbered list"
      title="Numbered list"
      @click="editor.chain().focus().toggleOrderedList().run()"
    />
    <Button
      icon="fas fa-quote-right"
      aria-label="Quote"
      title="Quote"
      @click="editor.chain().focus().toggleBlockquote().run()"
    />
    <Button
      icon="fas fa-file-code"
      aria-label="Code block"
      title="Code block"
      @click="editor.chain().focus().toggleCodeBlock().run()"
    />
    <Button
      icon="fas fa-link"
      aria-label="Insert link"
      title="Insert link"
      @click="
        showLink = true;
        failure = '';
      "
    />
    <Button
      icon="fas fa-unlink"
      aria-label="Remove link"
      title="Remove link"
      @click="editor.chain().focus().unsetLink().run()"
    />
    <Button
      icon="fas fa-table"
      aria-label="Insert table"
      title="Insert table"
      @click="
        editor
          .chain()
          .focus()
          .insertTable({ rows: 3, cols: 3, withHeaderRow: true })
          .run()
      "
    />
    <Button
      icon="fas fa-at"
      aria-label="Insert evidence"
      title="Insert evidence"
      @click="popup(sdk, EvidencePicker, { editor })"
    />
    <Button label="Markdown" @click="showMarkdown = true" />
    <Button
      icon="fas fa-undo"
      aria-label="Undo"
      title="Undo"
      @click="editor.chain().focus().undo().run()"
    />
    <Button
      icon="fas fa-redo"
      aria-label="Redo"
      title="Redo"
      @click="editor.chain().focus().redo().run()"
    />
  </div>
  <Dialog
    v-model:visible="showLink"
    append-to="self"
    modal
    header="Insert link"
  >
    <InputText
      v-model="link"
      placeholder="https://example.com"
      aria-label="Link URL"
    />
    <p role="alert">{{ failure }}</p>
    <Button label="Apply" @click="setLink" />
  </Dialog>
  <Dialog
    v-model:visible="showMarkdown"
    append-to="self"
    modal
    header="Insert Markdown"
    :style="{ width: '700px', maxWidth: '95vw' }"
  >
    <Textarea
      v-model="markdown"
      rows="10"
      :style="{ width: '100%' }"
      aria-label="Markdown source"
    />
    <h3>Preview</h3>
    <!-- Preview is rebuilt by sanitizeHTML from a fixed allowlist. -->
    <!-- eslint-disable-next-line vue/no-v-html -->
    <div class="npp-preview" v-html="preview"></div>
    <p>
      Raw HTML and remote images are excluded. Use the toolbar for additional
      formatting.
    </p>
    <Button
      label="Insert"
      @click="
        editor.chain().focus().insertContent(preview).run();
        showMarkdown = false;
        markdown = '';
      "
    />
  </Dialog>
</template>
