<script setup lang="ts">
import { EditorState, StateEffect } from "@codemirror/state";
import { EditorView } from "@codemirror/view";
import { onBeforeUnmount, onMounted, ref, watch } from "vue";

import type { FrontendSDK } from "@/types";

const props = defineProps<{
  kind: "Request" | "Response";
  text: string;
  sdk: FrontendSDK;
}>();
const host = ref<HTMLElement>();
let view: EditorView | undefined;

function setText(value: string) {
  view?.dispatch({
    changes: { from: 0, to: view.state.doc.length, insert: value },
  });
}

onMounted(() => {
  const editor =
    props.kind === "Request"
      ? props.sdk.ui.httpRequestEditor()
      : props.sdk.ui.httpResponseEditor();
  host.value?.appendChild(editor.getElement());
  view = editor.getEditorView();
  view.dispatch({
    effects: StateEffect.appendConfig.of([
      EditorState.readOnly.of(true),
      EditorView.editable.of(false),
      EditorView.lineWrapping,
    ]),
  });
  setText(props.text);
});
watch(() => props.text, setText);
onBeforeUnmount(() => view?.destroy());
</script>

<template>
  <div
    ref="host"
    class="npp-http-view"
    :aria-label="`${kind} evidence, read only`"
  />
</template>
