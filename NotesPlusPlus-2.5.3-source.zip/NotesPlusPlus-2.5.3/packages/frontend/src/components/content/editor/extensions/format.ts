import { Mark } from "@tiptap/core";

export const fonts = ["inherit", "sans-serif", "serif", "monospace"];
export const sizes = ["12px", "14px", "16px", "20px", "24px", "32px"];
export const Highlight = Mark.create({
  name: "highlight",
  parseHTML: () => [{ tag: "mark" }],
  renderHTML: () => ["mark", {}, 0],
});
export const Font = Mark.create({
  name: "font",
  addAttributes: () => ({
    family: { default: "inherit" },
    size: { default: "16px" },
  }),
  parseHTML: () => [
    {
      tag: "span",
      getAttrs: (element) => {
        const family = element.style.fontFamily;
        const size = element.style.fontSize;
        if (!fonts.includes(family) && !sizes.includes(size)) return false;
        return {
          family: fonts.includes(family) ? family : "inherit",
          size: sizes.includes(size) ? size : "16px",
        };
      },
    },
  ],
  renderHTML: ({ mark }) => [
    "span",
    {
      style: `font-family:${fonts.includes(mark.attrs.family) ? mark.attrs.family : "inherit"};font-size:${sizes.includes(mark.attrs.size) ? mark.attrs.size : "16px"}`,
    },
    0,
  ],
});

export function safeLink(value: string): boolean {
  return (
    /^(https?:\/\/|mailto:)/i.test(value) &&
    !Array.from(value).some((char) => char.charCodeAt(0) <= 32)
  );
}

/** Inert parsing; rebuild only allowlisted elements and attributes. */
export function sanitizeHTML(html: string): string {
  const template = document.createElement("template");
  template.innerHTML = html;
  const allowed = new Set([
    "P",
    "BR",
    "STRONG",
    "B",
    "EM",
    "I",
    "U",
    "S",
    "DEL",
    "MARK",
    "SPAN",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "UL",
    "OL",
    "LI",
    "BLOCKQUOTE",
    "PRE",
    "CODE",
    "TABLE",
    "TBODY",
    "TR",
    "TD",
    "TH",
    "HR",
    "A",
  ]);
  function clean(parent: ParentNode) {
    for (const element of Array.from(parent.children)) {
      if (
        [
          "SCRIPT",
          "STYLE",
          "IFRAME",
          "OBJECT",
          "SVG",
          "MATH",
          "IMG",
          "LINK",
          "META",
        ].includes(element.tagName)
      ) {
        element.remove();
        continue;
      }
      clean(element);
      if (!allowed.has(element.tagName)) {
        element.replaceWith(...Array.from(element.childNodes));
        continue;
      }
      const href = element.getAttribute("href") ?? "";
      const family = (element as HTMLElement).style.fontFamily;
      const size = (element as HTMLElement).style.fontSize;
      for (const attribute of Array.from(element.attributes))
        element.removeAttribute(attribute.name);
      if (element.tagName === "A" && safeLink(href))
        element.setAttribute("href", href);
      if (element.tagName === "SPAN") {
        if (fonts.includes(family))
          (element as HTMLElement).style.fontFamily = family;
        if (sizes.includes(size))
          (element as HTMLElement).style.fontSize = size;
      }
    }
  }
  clean(template.content);
  return template.innerHTML;
}
