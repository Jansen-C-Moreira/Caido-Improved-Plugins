<script setup lang="ts">
import Button from "primevue/button";
import Dialog from "primevue/dialog";
import Select from "primevue/select";
import type { Note, NoteContent } from "shared";
import { computed, onBeforeUnmount, onMounted, ref, watch } from "vue";

import SearchNoteViewer from "./SearchNoteViewer.vue";

import { useSDK } from "@/plugins/sdk";
import { emitter } from "@/utils/eventBus";
import { download } from "@/utils/evidence";

const props = defineProps<{
  projectId: string;
  sessionId: string;
  entryId?: string;
  title: string;
}>();
const emit = defineEmits<{ close: [] }>();
const sdk = useSDK();
const scope = ref("Session note");
const note = ref<Note>();
const content = ref<NoteContent>({ type: "doc", content: [] });
const dirty = ref(false);
const busy = ref(false);
const ready = ref(false);
const failure = ref("");
let generation = 0;
const target = computed(() => ({
  sessionId: props.sessionId,
  entryId: scope.value === "Execution note" ? props.entryId : undefined,
}));
async function load() {
  const token = ++generation;
  ready.value = false;
  busy.value = true;
  failure.value = "";
  try {
    const result = await sdk.backend.getReplayNote(
      props.projectId,
      target.value,
    );
    if (generation !== token) return;
    if (result.kind === "Error") throw new Error(result.error);
    note.value = result.value;
    content.value = result.value?.content ?? { type: "doc", content: [] };
    dirty.value = false;
    ready.value = true;
  } catch (cause) {
    if (generation === token) failure.value = String(cause);
  } finally {
    if (generation === token) busy.value = false;
  }
}
async function save() {
  busy.value = true;
  failure.value = "";
  const snapshot = JSON.parse(JSON.stringify(content.value)) as NoteContent;
  try {
    const result = await sdk.backend.saveReplayNote(
      props.projectId,
      target.value,
      snapshot,
      note.value?.revision,
      note.value?.id,
    );
    if (result.kind === "Error") throw new Error(result.error);
    note.value = result.value;
    dirty.value = JSON.stringify(content.value) !== JSON.stringify(snapshot);
  } catch (cause) {
    failure.value = String(cause);
  } finally {
    busy.value = false;
  }
}
function close() {
  if (dirty.value) {
    failure.value = "Save your changes or download your draft before closing.";
    return;
  }
  emit("close");
}
function recover() {
  download(
    JSON.stringify(content.value, undefined, 2),
    `Replay-${props.sessionId}-draft.json`,
    "application/json",
  );
}
function openNote() {
  if (note.value === undefined) return;
  emitter.emit("openNote", {
    path: note.value.path,
    projectId: props.projectId,
  });
  sdk.navigation.goTo("/notes");
  emit("close");
}
function unload(event: BeforeUnloadEvent) {
  if (dirty.value) {
    event.preventDefault();
    event.returnValue = "";
  }
}
const change = sdk.backend.onEvent("notes++:noteChange", (project) => {
  if (project !== props.projectId || busy.value) return;
  if (dirty.value)
    failure.value =
      "Notes changed in another editor. Your draft is preserved; saving will check for conflicts.";
  else void load();
});
watch(scope, load);
onMounted(() => {
  window.addEventListener("beforeunload", unload);
  void load();
});
onBeforeUnmount(() => {
  generation++;
  change.stop();
  window.removeEventListener("beforeunload", unload);
});
</script>
<template>
  <Dialog
    append-to="self"
    :visible="true"
    modal
    :header="`Notes — ${title}`"
    :style="{ width: '900px', maxWidth: '95vw' }"
    :closable="!dirty"
    :close-on-escape="!dirty"
    @update:visible="close"
  >
    <div class="npp-form">
      <Select
        v-model="scope"
        append-to="self"
        :options="
          entryId ? ['Session note', 'Execution note'] : ['Session note']
        "
        :disabled="dirty || busy"
        aria-label="Annotation scope"
      />
      <small
        >Replay {{ sessionId
        }}<template v-if="scope === 'Execution note'">
          · Execution {{ entryId }}</template
        >. This target stays fixed while you edit.</small
      >
      <SearchNoteViewer
        v-if="ready"
        :content="content"
        @save="
          content = $event;
          dirty = true;
        "
      />
      <p v-if="failure" role="alert">{{ failure }}</p>
      <div class="npp-actions">
        <Button
          label="Save"
          :disabled="!dirty || busy || !ready"
          @click="save"
        />
        <Button
          v-if="note"
          label="Open in Notes++"
          :disabled="dirty || busy"
          @click="openNote"
        />
        <Button v-if="dirty" label="Download draft" @click="recover" />
        <Button
          v-if="dirty"
          label="Discard draft and reload"
          :disabled="busy"
          @click="load"
        />
        <Button label="Close" :disabled="dirty || busy" @click="close" />
      </div>
    </div>
  </Dialog>
</template>
