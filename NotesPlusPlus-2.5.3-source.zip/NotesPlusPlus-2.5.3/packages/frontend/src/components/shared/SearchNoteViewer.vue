<script setup lang="ts">
import { type Editor, EditorContent, useEditor } from "@tiptap/vue-3";
import type { NoteContent } from "shared";
import { onUnmounted, toRaw, watch } from "vue";

import { sanitizeHTML } from "@/components/content/editor/extensions/format";
import { editorExtensions } from "@/components/content/editor/extensions/shared";
import Toolbar from "@/components/content/editor/Toolbar.vue";
import { useSDK } from "@/plugins/sdk";
import { injectEditorStyles } from "@/utils/injectEditorStyles";

injectEditorStyles();

const sdk = useSDK();

const props = defineProps<{
  content: NoteContent;
}>();

const emit = defineEmits<{
  save: [content: NoteContent];
}>();

function saveContent(editor: Editor) {
  emit("save", editor.getJSON() as NoteContent);
}

const editor = useEditor({
  content: "",
  extensions: editorExtensions(sdk),
  editorProps: {
    transformPastedHTML: sanitizeHTML,
    attributes: {
      class:
        "mx-auto focus:outline-none font-mono dark:text-surface-100 h-full",
    },
  },
  onUpdate: ({ editor }) => {
    saveContent(editor as Editor);
  },
  onCreate: ({ editor }) => {
    if (props.content) {
      const rawContent = JSON.parse(JSON.stringify(toRaw(props.content)));
      editor.commands.setContent(rawContent, { emitUpdate: false });
    }
  },
});

watch(
  () => props.content,
  (newContent) => {
    if (editor.value && newContent) {
      const rawContent = JSON.parse(JSON.stringify(toRaw(newContent)));
      const currentJSON = JSON.stringify(editor.value.getJSON());
      const newJSON = JSON.stringify(rawContent);
      if (currentJSON !== newJSON) {
        editor.value.commands.setContent(rawContent, { emitUpdate: false });
      }
    }
  },
);

onUnmounted(() => {
  editor.value?.destroy();
});
</script>

<template>
  <div class="flex-1 overflow-y-auto min-h-0 p-2">
    <Toolbar v-if="editor" :editor="editor" />
    <editor-content
      :editor="editor"
      spellcheck="false"
      autocorrect="off"
      autocapitalize="off"
      class="editor-wrapper"
    />
  </div>
</template>
