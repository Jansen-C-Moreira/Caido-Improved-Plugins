import type { Evidence } from "shared";

import type { FrontendSDK } from "@/types";

export type Capture = Omit<Evidence, "id" | "projectId" | "capturedAt">;
export type Parts = "request" | "response" | "both" | "none";
export function bytes(raw: string): Uint8Array<ArrayBuffer> {
  return Uint8Array.from(atob(raw), (char) => char.charCodeAt(0));
}
export function httpText(raw: string): string | undefined {
  const data = bytes(raw);
  if (data.some((byte) => byte < 32 && ![9, 10, 13].includes(byte)))
    return undefined;
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(data);
  } catch {
    return undefined;
  }
}
export function download(
  data: BlobPart,
  name: string,
  type = "application/octet-stream",
) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
async function requestEvidence(
  sdk: FrontendSDK,
  requestId: string,
  parts: Parts,
  projectId: string,
): Promise<Partial<Capture>> {
  if (parts === "none") return { requestId };
  const result = await sdk.backend.getHttpEvidence(projectId, requestId, parts);
  if (result.kind === "Error") throw new Error(result.error);
  return result.value;
}
export async function captureReplay(
  sdk: FrontendSDK,
  sessionId: string,
  entryId: string | undefined,
  parts: Parts,
  projectId?: string,
): Promise<Capture> {
  const title =
    sdk.replay.getSessions().find((session) => session.id === sessionId)
      ?.name ?? `Replay ${sessionId}`;
  if (entryId !== undefined) {
    if (projectId === undefined)
      throw new Error("The source project is required");
    const entry = sdk.replay.getEntry(entryId);
    if (entry.sessionId !== sessionId || entry.requestId === undefined)
      throw new Error("This history entry has no sent HTTP request");
    return {
      kind: "replay",
      title,
      sessionId,
      entryId,
      ...(await requestEvidence(sdk, entry.requestId, parts, projectId)),
    };
  }
  if (parts !== "request")
    throw new Error(
      "Drafts have no response. Select a historical execution instead.",
    );
  const { replaySession } = await sdk.graphql.replaySessionEntries({
    id: sessionId,
  });
  const entry = replaySession?.activeEntry;
  if (entry?.__typename !== "ReplayEntryHttp")
    throw new Error("No HTTP draft available");
  return {
    kind: "replay",
    title,
    sessionId,
    request: entry.draft?.raw ?? entry.raw,
  };
}
export async function captureFinding(
  sdk: FrontendSDK,
  findingId: string,
  parts: Parts,
  projectId: string,
): Promise<Capture> {
  const { finding } = await sdk.graphql.getFinding({ id: findingId });
  if (finding === undefined || finding === null)
    throw new Error("Finding unavailable");
  return {
    kind: "finding",
    findingId,
    title: finding.title,
    description: finding.description ?? "",
    reporter: finding.reporter,
    endpoint: `${finding.host}${finding.path}`,
    ...(parts === "none"
      ? { requestId: finding.request.id }
      : await requestEvidence(sdk, finding.request.id, parts, projectId)),
  };
}
