import { Classic } from "@caido/primevue";
import PrimeVue from "primevue/config";
import { type Component, createApp } from "vue";

import { SDKPlugin } from "@/plugins/sdk";
import type { FrontendSDK } from "@/types";

export function popup(
  sdk: FrontendSDK,
  component: Component,
  props: Record<string, unknown>,
) {
  const host = document.createElement("div");
  host.className = "notesplusplus-popup";
  document.body.append(host);
  const app = createApp(component, {
    ...props,
    onClose: () => {
      app.unmount();
      host.remove();
    },
  });
  app.use(PrimeVue, { unstyled: true, pt: Classic });
  app.use(SDKPlugin, sdk);
  app.mount(host);
}
