import type { Folder, Note } from "shared";

import type { FrontendSDK } from "@/types";
import { exportContext, serializeMarkdown } from "@/utils/markdownExport";

export function safeFilename(name: string): string {
  const clean = name
    .replace(/[<>:"/\\|?*]/g, "_")
    .split("")
    .map((char) => (char.charCodeAt(0) < 32 ? "_" : char))
    .join("")
    .replace(/[. ]+$/g, "")
    .slice(0, 100);
  return clean === "" ||
    /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(clean)
    ? `_${clean || "note"}`
    : clean;
}
function crc32(data: Uint8Array): number {
  let crc = 0xffffffff;
  for (const byte of data) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++)
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}
/** ZIP STORE format with UTF-8 names. */
export function zip(
  files: Map<string, Uint8Array<ArrayBuffer>>,
): Uint8Array<ArrayBuffer> {
  const chunks: Uint8Array<ArrayBuffer>[] = [];
  const central: Uint8Array<ArrayBuffer>[] = [];
  let offset = 0;
  for (const [name, data] of files) {
    const filename = new TextEncoder().encode(name);
    const crc = crc32(data);
    const local = new Uint8Array(30 + filename.length);
    const view = new DataView(local.buffer);
    view.setUint32(0, 0x04034b50, true);
    view.setUint16(4, 20, true);
    view.setUint16(6, 0x800, true);
    view.setUint32(14, crc, true);
    view.setUint32(18, data.length, true);
    view.setUint32(22, data.length, true);
    view.setUint16(26, filename.length, true);
    local.set(filename, 30);
    const record = new Uint8Array(46 + filename.length);
    const directory = new DataView(record.buffer);
    directory.setUint32(0, 0x02014b50, true);
    directory.setUint16(4, 20, true);
    directory.setUint16(6, 20, true);
    directory.setUint16(8, 0x800, true);
    directory.setUint32(16, crc, true);
    directory.setUint32(20, data.length, true);
    directory.setUint32(24, data.length, true);
    directory.setUint16(28, filename.length, true);
    directory.setUint32(42, offset, true);
    record.set(filename, 46);
    chunks.push(local, data);
    central.push(record);
    offset += local.length + data.length;
  }
  const size = central.reduce((sum, value) => sum + value.length, 0);
  if (files.size > 65535 || offset + size > 0xffffffff)
    throw new Error("Export exceeds ZIP format limits");
  const end = new Uint8Array(22);
  const view = new DataView(end.buffer);
  view.setUint32(0, 0x06054b50, true);
  view.setUint16(8, files.size, true);
  view.setUint16(10, files.size, true);
  view.setUint32(12, size, true);
  view.setUint32(16, offset, true);
  const result = new Uint8Array(offset + size + end.length);
  let position = 0;
  for (const chunk of [...chunks, ...central, end]) {
    result.set(chunk, position);
    position += chunk.length;
  }
  return result;
}
export async function prepareExport(
  sdk: FrontendSDK,
  tree: Folder,
  selected: Note | undefined,
  scope: "Note" | "Folder" | "Project",
) {
  const context = exportContext();
  const project = await sdk.backend.getCurrentProjectId();
  if (project.kind === "Error" || project.value === undefined)
    throw new Error("No active project");
  context.project = project.value;
  const parent =
    selected?.path.slice(0, selected.path.lastIndexOf("/") + 1) ?? "/";
  const notes: Note[] = [];
  function visit(folder: Folder) {
    for (const child of folder.children) {
      if (child.type === "folder") visit(child as Folder);
      else if (
        scope === "Project" ||
        (scope === "Folder" && child.path.startsWith(parent))
      )
        notes.push(child as Note);
    }
  }
  if (scope === "Note" && selected !== undefined) notes.push(selected);
  else visit(tree);
  const used = new Set<string>();
  for (const note of notes) {
    const original = (
      scope === "Note" ? note.name : note.path.replace(/^\//, "")
    )
      .replace(/\.json$/, "")
      .split("/")
      .map(safeFilename)
      .join("/");
    let base = original;
    let suffix = 1;
    while (used.has(base.toLowerCase())) base = `${original}-${++suffix}`;
    used.add(base.toLowerCase());
    context.assets = `${base}-assets`;
    const annotation = note.association;
    const source =
      annotation === undefined
        ? ""
        : `Replay session: ${annotation.sessionId}${annotation.entryId === undefined ? "" : ` · Execution: ${annotation.entryId}`}\n\n`;
    const markdown =
      source + (await serializeMarkdown(note.content, sdk, context));
    context.files.set(
      `${base}.md`,
      Uint8Array.from(new TextEncoder().encode(markdown)),
    );
  }
  const active = await sdk.backend.getCurrentProjectId();
  if (active.kind === "Error" || active.value !== context.project)
    throw new Error("Project changed during export. Export cancelled.");
  if (context.files.size === 0) throw new Error("No notes to export");
  const entry = [...context.files][0]!;
  const single = context.files.size === 1 && scope === "Note";
  return {
    warnings: context.warnings,
    name: single ? entry[0] : `Notes++-${scope.toLowerCase()}.zip`,
    data: single ? entry[1] : zip(context.files),
    type: single ? "text/markdown;charset=utf-8" : "application/zip",
  };
}
