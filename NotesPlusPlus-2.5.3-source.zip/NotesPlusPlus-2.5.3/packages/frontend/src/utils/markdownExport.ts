import type { Evidence, NoteContent, NoteContentItem } from "shared";

import {
  fonts,
  safeLink,
  sizes,
} from "@/components/content/editor/extensions/format";
import type { FrontendSDK } from "@/types";
import { bytes, captureReplay, httpText } from "@/utils/evidence";
import { fetchReplaySessionContent } from "@/utils/replay";

export type ExportContext = {
  files: Map<string, Uint8Array<ArrayBuffer>>;
  warnings: string[];
  cache: Map<string, Promise<string>>;
  project?: string;
  assets: string;
  clipboard: boolean;
  tableCount: number;
};
export function exportContext(clipboard = false): ExportContext {
  return {
    files: new Map(),
    warnings: [],
    cache: new Map(),
    assets: "assets",
    clipboard,
    tableCount: 0,
  };
}
const html = (text: string) =>
  text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
const escape = (text: string) =>
  html(text).replace(/([\\`*_{}[\]()#+.!|>~-])/g, "\\$1");
function backticks(text: string, minimum: number): string {
  let length = minimum;
  for (const match of text.matchAll(/`+/g))
    length = Math.max(length, match[0].length + 1);
  return "`".repeat(length);
}
export function fence(text: string, language = ""): string {
  const delimiter = backticks(text, 3);
  return `${delimiter}${/^[a-zA-Z0-9_-]*$/.test(language) ? language : ""}\n${text}\n${delimiter}\n\n`;
}
function asset(
  context: ExportContext,
  raw: Uint8Array<ArrayBuffer>,
  extension: string,
): string {
  const number = context.files.size + 1;
  context.files.set(`${context.assets}/asset-${number}.${extension}`, raw);
  return `${encodeURIComponent(context.assets.split("/").pop() ?? "assets")}/asset-${number}.${extension}`;
}
function unavailable(context: ExportContext, message: string): string {
  context.warnings.push(message);
  return `\n\n[Unavailable: ${escape(message)}]\n\n`;
}
async function cached(
  context: ExportContext,
  key: string,
  fetch: () => Promise<string>,
): Promise<string> {
  let value = context.cache.get(key);
  if (value === undefined) {
    value = fetch();
    context.cache.set(key, value);
  }
  return value;
}
function evidenceMarkdown(evidence: Evidence, context: ExportContext): string {
  let output = `\n\n### ${escape(evidence.title)}\n\nCaptured: ${escape(evidence.capturedAt)}\n\n`;
  output += `Source: ${escape([evidence.kind, evidence.sessionId, evidence.entryId, evidence.findingId].filter(Boolean).join(" / "))}\n\n`;
  if (evidence.endpoint) output += `${escape(evidence.endpoint)}\n\n`;
  if (evidence.reporter) output += `Reporter: ${escape(evidence.reporter)}\n\n`;
  if (evidence.description) output += `${escape(evidence.description)}\n\n`;
  for (const [label, raw] of [
    ["Request", evidence.request],
    ["Response", evidence.response],
  ] as const) {
    if (raw === undefined) continue;
    output += `#### ${label}\n\n`;
    const text = httpText(raw);
    if (text !== undefined) output += fence(text, "http");
    else if (context.clipboard) {
      context.warnings.push(
        `Binary ${label.toLowerCase()} requires file export to preserve original bytes`,
      );
      output += `[Binary ${label.toLowerCase()}: use file export to include original bytes]\n\n`;
    } else
      output += `[Download original ${label.toLowerCase()}](${asset(context, bytes(raw), "http")})\n\n`;
  }
  if (evidence.kind === "replay" && evidence.response === undefined)
    output += "No response included.\n\n";
  return output;
}
export async function serializeMarkdown(
  content: NoteContent,
  sdk: FrontendSDK,
  context: ExportContext,
): Promise<string> {
  async function render(node: NoteContentItem): Promise<string> {
    const attrs = node.attrs ?? {};
    if (node.type === "text") {
      let text = escape(node.text ?? "");
      for (const mark of node.marks ?? []) {
        const attributes = mark.attrs ?? {};
        switch (mark.type) {
          case "bold":
            text = `**${text}**`;
            break;
          case "italic":
            text = `*${text}*`;
            break;
          case "strike":
            text = `~~${text}~~`;
            break;
          case "underline":
            text = `<u>${text}</u>`;
            break;
          case "highlight":
            text = `<mark>${text}</mark>`;
            break;
          case "font":
            text = `<span style="font-family:${fonts.includes(String(attributes.family)) ? attributes.family : "inherit"};font-size:${sizes.includes(String(attributes.size)) ? attributes.size : "16px"}">${text}</span>`;
            break;
          case "link":
            if (safeLink(String(attributes.href)))
              text = `[${text}](<${html(String(attributes.href))}>)`;
            break;
          case "code": {
            const value = node.text ?? "";
            const ticks = backticks(value, 1);
            text = `${ticks} ${value} ${ticks}`;
            break;
          }
          default:
            context.warnings.push(`Unsupported mark: ${mark.type}`);
        }
      }
      return text;
    }
    if (node.type === "codeBlock")
      return fence(
        (node.content ?? []).map((child) => child.text ?? "").join(""),
        typeof attrs.language === "string" ? attrs.language : "",
      );
    if (node.type === "mention") {
      try {
        return (
          "\n\n" +
          fence(
            await cached(context, `live:${attrs.id}`, () =>
              fetchReplaySessionContent(sdk, String(attrs.id)),
            ),
            "http",
          )
        );
      } catch {
        return unavailable(context, `Replay ${attrs.id}`);
      }
    }
    if (node.type === "evidence") {
      try {
        if (context.project === undefined) {
          const project = await sdk.backend.getCurrentProjectId();
          if (project.kind === "Error" || project.value === undefined)
            throw new Error("No active project");
          context.project = project.value;
        }
        if (context.project !== attrs.projectId)
          throw new Error("Evidence belongs to another project");
        let evidence: Evidence;
        if (attrs.live === true) {
          const raw = await cached(
            context,
            `capture:${attrs.sessionId}`,
            async () =>
              JSON.stringify(
                await captureReplay(
                  sdk,
                  String(attrs.sessionId),
                  undefined,
                  "request",
                ),
              ),
          );
          evidence = {
            ...JSON.parse(raw),
            capturedAt: new Date().toISOString(),
          } as Evidence;
        } else {
          const result = await sdk.backend.getEvidence(
            context.project,
            String(attrs.evidenceId),
          );
          if (result.kind === "Error") throw new Error(result.error);
          evidence = result.value;
        }
        return evidenceMarkdown(evidence, context);
      } catch (cause) {
        return unavailable(context, String(cause));
      }
    }
    if (node.type === "fileMention") {
      try {
        const raw = await cached(context, `filebytes:${attrs.id}`, () =>
          sdk.backend.getFileBytes(String(attrs.id)),
        );
        if (!context.clipboard) {
          return `[${escape(String(attrs.name))}](${asset(context, bytes(raw), "bin")})\n\n`;
        }
        const text = httpText(raw);
        return text === undefined
          ? unavailable(
              context,
              `Binary file ${String(attrs.name)} requires file export`,
            )
          : fence(text);
      } catch {
        return unavailable(context, `File ${String(attrs.name)}`);
      }
    }
    if (node.type === "image") {
      const match =
        /^data:image\/(png|jpeg|gif|webp);base64,([A-Za-z0-9+/=]+)$/.exec(
          String(attrs.src),
        );
      if (match === null)
        return unavailable(context, "Blocked or unsupported image");
      const source = context.clipboard
        ? String(attrs.src)
        : asset(context, bytes(match[2]!), match[1]!);
      return `![${escape(typeof attrs.alt === "string" ? attrs.alt : "Image")}](${source})\n\n`;
    }
    if (node.type === "reminderNode")
      return `[Reminder: ${escape(typeof attrs.context === "string" ? attrs.context : "")} — ${escape(typeof attrs.reminderAt === "string" ? attrs.reminderAt : "")}]`;
    if (node.type === "table") {
      const tableNumber = ++context.tableCount;
      const blocks: string[] = [];
      const inlineTypes = new Set([
        "tableCell",
        "tableHeader",
        "paragraph",
        "text",
        "hardBreak",
      ]);
      const inlineOnly = (item: NoteContentItem): boolean =>
        inlineTypes.has(item.type) && (item.content ?? []).every(inlineOnly);
      const rows: string[][] = [];
      for (const [rowIndex, row] of (node.content ?? []).entries())
        rows.push(
          await Promise.all(
            (row.content ?? []).map(async (cell, columnIndex) => {
              const value = (await render(cell)).trim();
              if (!inlineOnly(cell)) {
                const label = `Table ${tableNumber}, row ${rowIndex + 1}, column ${columnIndex + 1}`;
                blocks.push(`#### ${label}\n\n${value}\n\n`);
                return `See ${label} below`;
              }
              return value.replace(/(?<!\\)\|/g, "\\|").replace(/\n+/g, "<br>");
            }),
          ),
        );
      if (rows.length === 0) return "";
      const width = Math.max(...rows.map((row) => row.length));
      const line = (row: string[]) =>
        `| ${Array.from({ length: width }, (_, i) => row[i] ?? "").join(" | ")} |\n`;
      return (
        line(rows[0]!) +
        line(Array.from({ length: width }, () => "---")) +
        rows.slice(1).map(line).join("") +
        "\n" +
        blocks.join("")
      );
    }
    const rendered = await Promise.all((node.content ?? []).map(render));
    const children = rendered.join("");
    switch (node.type) {
      case "doc":
        return children;
      case "paragraph":
        return `${children}\n\n`;
      case "heading":
        return `${"#".repeat(Math.min(6, Math.max(1, Number(attrs.level) || 1)))} ${children}\n\n`;
      case "hardBreak":
        return "  \n";
      case "horizontalRule":
        return "---\n\n";
      case "blockquote":
        return (
          children
            .trim()
            .split("\n")
            .map((line) => `> ${line}`)
            .join("\n") + "\n\n"
        );
      case "bulletList":
      case "orderedList": {
        const items = rendered;
        return (
          items
            .map((item, index) => {
              const prefix =
                node.type === "bulletList"
                  ? "- "
                  : `${(Number(attrs.start) || 1) + index}. `;
              return (
                prefix +
                item
                  .trim()
                  .split("\n")
                  .join("\n" + " ".repeat(prefix.length))
              );
            })
            .join("\n") + "\n\n"
        );
      }
      case "listItem":
      case "tableCell":
      case "tableHeader":
      case "tableRow":
        return children;
      default:
        context.warnings.push(`Unsupported content: ${node.type}`);
        return children || `[Unsupported content: ${escape(node.type)}]`;
    }
  }
  return (await render(content)).trim() + "\n";
}
export async function convertTipTapToMarkdown(
  content: NoteContent,
  sdk: FrontendSDK,
): Promise<string> {
  return serializeMarkdown(content, sdk, exportContext(true));
}
