import type { FrontendSDK } from "@/types";

export function currentReplayTabData(sdk: FrontendSDK) {
  const session = sdk.replay.getCurrentSession();
  return { id: session?.id ?? "", label: session?.name ?? "" };
}
