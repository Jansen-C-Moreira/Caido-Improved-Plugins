import type { NoteContent } from "shared";

export type PendingNote = {
  id?: string;
  project: string;
  path: string;
  content: NoteContent;
};

/** Immutable snapshots and one writer prevent late responses from changing another note. */
export function createSaveQueue(write: (note: PendingNote) => Promise<void>) {
  let tail = Promise.resolve();
  const pending = new Map<string, PendingNote>();
  function save(note: PendingNote): Promise<void> {
    const snapshot = structuredClone(note);
    const key = JSON.stringify([note.project, note.path]);
    pending.set(key, snapshot);
    const task = tail.then(async () => {
      await write(snapshot);
      if (pending.get(key) === snapshot) pending.delete(key);
    });
    tail = task.catch(() => {});
    return task;
  }
  return { save, pending, settled: () => tail };
}
