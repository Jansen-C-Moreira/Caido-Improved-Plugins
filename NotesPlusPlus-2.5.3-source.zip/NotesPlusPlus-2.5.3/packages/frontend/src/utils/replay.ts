import type { FrontendSDK } from "@/types";

/** Read the HTTP union member from the current SDK query, including unsent drafts. */
export async function fetchReplaySessionContent(
  sdk: FrontendSDK,
  sessionId: string,
): Promise<string> {
  const result = await sdk.graphql.replaySessionEntries({ id: sessionId });
  const entry = result.replaySession?.activeEntry;
  if (entry === undefined || entry === null)
    throw new Error("Replay session is unavailable or has no entry");
  if (entry.__typename !== "ReplayEntryHttp")
    throw new Error("Only HTTP Replay sessions can be embedded");
  const raw = entry.draft?.raw ?? entry.raw;
  if (raw.length === 0) throw new Error("The selected Replay entry is empty");
  // GraphQL Blob fields carry Base64, not the HTTP text shown in the editor.
  let binary: string;
  try {
    binary = atob(raw);
  } catch {
    throw new Error("Replay returned invalid Base64 content");
  }
  const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    // Keep each byte visible for requests containing non-UTF-8 binary bodies.
    return binary;
  }
}
