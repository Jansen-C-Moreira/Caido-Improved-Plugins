import { defineStore } from "pinia";
import {
  type Folder,
  type Note,
  type NoteContent,
  type TreeNode,
} from "shared";
import { computed, ref } from "vue";

import { useSDK } from "@/plugins/sdk";
import { useNotesRepository } from "@/repositories/notes";
import { useTreeViewStore } from "@/stores/treeView";
import { emitter } from "@/utils/eventBus";
import { createSaveQueue } from "@/utils/saveQueue";

export const useNotesStore = defineStore("notes", () => {
  const sdk = useSDK();
  const repository = useNotesRepository();

  const tree = ref<Folder | undefined>(undefined);

  const currentNotePath = ref<string | undefined>(undefined);
  const currentNote = computed(() => {
    if (!currentNotePath.value || !tree.value) return undefined;

    const node = findNode(currentNotePath.value);
    if (node && node.type === "note") {
      return node as Note;
    }
  });

  const notesHistory = ref<string[]>([]);
  const historyIndex = ref<number>(-1);
  const isSaving = ref(false);
  const saveError = ref("");
  const projectId = ref<string | undefined>();
  let writes = 0;
  let revision = 0;
  const versions = new Map<string, number>();
  const saves = createSaveQueue(async (note) => {
    const key = JSON.stringify([note.project, note.path]);
    const baseline =
      versions.get(key) ?? (findNode(note.path) as Note | undefined)?.revision;
    if (baseline === undefined)
      throw new Error("Reload this note before saving: revision unavailable");
    const result = await sdk.backend.updateNote(
      note.path,
      { content: note.content, revision: baseline, id: note.id },
      note.project,
    );
    if (result.kind === "Error") throw new Error(result.error);
    versions.set(key, result.value.revision!);
    const node = findNode(note.path) as Note | undefined;
    if (node !== undefined && note.project === projectId.value)
      node.revision = result.value.revision;
  });
  async function recoverDrafts() {
    await saves.settled();
    for (const [key, draft] of [...saves.pending]) {
      if (draft.project !== projectId.value) continue;
      const result = await sdk.backend.createNote(
        `/Recovered ${Date.now()}-${crypto.randomUUID().slice(0, 8)}.json`,
        draft.content,
        draft.project,
      );
      if (result.kind === "Error") {
        saveError.value = result.error;
        return;
      }
      saves.pending.delete(key);
      versions.delete(key);
    }
    saveError.value = "";
    await refreshTree();
  }
  window.addEventListener("beforeunload", (event) => {
    if (saves.pending.size > 0) {
      event.preventDefault();
      event.returnValue = "";
    }
  });
  async function retrySaves() {
    for (const note of [...saves.pending.values()]) {
      if (note.project === projectId.value)
        await updateNoteContent(note.path, note.content, note.id);
    }
  }
  async function waitForSaves() {
    await saves.settled();
    if (
      [...saves.pending.values()].some(
        (note) => note.project === projectId.value,
      )
    ) {
      throw new Error(
        "Save or recover pending changes before moving or deleting notes",
      );
    }
  }

  /**
   * Find a node by path
   */
  function findNode(path: string): TreeNode | undefined {
    if (!tree.value) return undefined;
    if (path === "/") return tree.value;

    const findNodeByPath = (
      currentPath: string,
      currentFolder: Folder,
    ): TreeNode | undefined => {
      if (currentFolder.path === currentPath) {
        return currentFolder;
      }

      for (const child of currentFolder.children) {
        if (child.path === currentPath) {
          return child;
        }

        if (child.type === "folder") {
          const result = findNodeByPath(currentPath, child as Folder);
          if (result) return result;
        }
      }

      return undefined;
    };

    return findNodeByPath(path, tree.value);
  }

  /**
   * Find the first note in the tree
   */
  function findFirstNote(
    folder: Folder = tree.value as Folder,
  ): string | undefined {
    if (!folder) return undefined;

    const firstNote = folder.children.find((child) => child.type === "note");
    if (firstNote) {
      return firstNote.path;
    }

    for (const child of folder.children) {
      if (child.type === "folder") {
        const notePath = findFirstNote(child as Folder);
        if (notePath) {
          return notePath;
        }
      }
    }

    return undefined;
  }

  /**
   * Initialize the store by loading the note tree
   */
  async function initialize() {
    try {
      await refreshTree();
    } catch (error) {
      sdk.window.showToast(`Error initializing notes: ${error}`, {
        variant: "error",
      });
    }
  }

  /**
   * Refresh the file tree
   */
  async function refreshTree() {
    const started = revision;
    try {
      const project = await sdk.backend.getCurrentProjectId();
      if (project.kind === "Error") throw new Error(project.error);
      const result = await repository.getTree();
      const active = await sdk.backend.getCurrentProjectId();
      if (
        active.kind === "Error" ||
        active.value !== project.value ||
        revision !== started
      )
        return;
      projectId.value = project.value;
      if (result) {
        const fetchedProject = project.value;
        function remember(folder: Folder) {
          for (const child of folder.children) {
            if (child.type === "folder") remember(child as Folder);
            else {
              const note = child as Note;
              const key = JSON.stringify([fetchedProject, note.path]);
              if (!saves.pending.has(key) && note.revision !== undefined)
                versions.set(key, note.revision);
            }
          }
        }
        remember(result);
        tree.value = structuredClone(result);
        for (const draft of saves.pending.values()) {
          if (draft.project !== projectId.value) continue;
          const node = findNode(draft.path);
          if (node?.type === "note") (node as Note).content = draft.content;
        }

        if (!currentNotePath.value) {
          const firstNotePath = findFirstNote();
          if (firstNotePath) {
            selectNote(firstNotePath);
          }
        }
      }
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      if (errorMessage.includes("No project found")) {
        return;
      }
      sdk.window.showToast(`Error loading note tree: ${error}`, {
        variant: "error",
      });
    }
  }

  /**
   * Load a specific note by path
   */
  async function loadNote(path: string) {
    try {
      const note = await repository.getNote(path);
      if (note) {
        currentNotePath.value = path;
      }
    } catch (error) {
      sdk.window.showToast(`Error loading note: ${error}`, {
        variant: "error",
      });
    }
  }

  /**
   * Create a new note
   */
  async function createNote(
    parentPath: string,
    noteName?: string,
    content: NoteContent = { type: "doc", content: [] },
  ) {
    if (!noteName) {
      noteName = await generateUntitledName(parentPath);
    }

    noteName = noteName.endsWith(".json") ? noteName : `${noteName}.json`;
    const path =
      parentPath === "/" ? `/${noteName}` : `${parentPath}/${noteName}`;

    try {
      const newNote = await repository.createNote(path, content);
      if (newNote) {
        await refreshTree();
        selectNote(path);
        return newNote;
      }
    } catch (error) {
      sdk.window.showToast(`Error creating note: ${error}`, {
        variant: "error",
      });
    }

    return undefined;
  }

  /**
   * Generate an "Untitled X" name that doesn't exist in the parent folder
   */
  async function generateUntitledName(parentPath: string): Promise<string> {
    if (!tree.value) await refreshTree();

    const parentNode = findNode(parentPath);
    if (!parentNode || parentNode.type !== "folder") {
      return "Untitled";
    }

    const parentFolder = parentNode as Folder;
    const existingNames = new Set(
      parentFolder.children
        .filter((node) => node.type === "note")
        .map((node) => node.name.replace(/\.json$/, "")),
    );

    let counter = 1;
    let newName = `Untitled ${counter}`;

    while (existingNames.has(newName)) {
      counter++;
      newName = `Untitled ${counter}`;
    }

    return newName;
  }

  /**
   * Generate a "New Folder X" name that doesn't exist in the parent folder
   */
  async function generateUntitledFolderName(
    parentPath: string,
  ): Promise<string> {
    if (!tree.value) await refreshTree();

    const parentNode = findNode(parentPath);
    if (!parentNode || parentNode.type !== "folder") {
      return "New Folder";
    }

    const parentFolder = parentNode as Folder;
    const existingNames = new Set(
      parentFolder.children
        .filter((node) => node.type === "folder")
        .map((node) => node.name),
    );

    let counter = 1;
    let newName = "New Folder";

    if (existingNames.has(newName)) {
      newName = `New Folder ${counter}`;
      while (existingNames.has(newName)) {
        counter++;
        newName = `New Folder ${counter}`;
      }
    }

    return newName;
  }

  /**
   * Create a new folder
   */
  async function createFolder(parentPath: string, name?: string) {
    let folderName = name;

    if (!folderName) {
      folderName = await generateUntitledFolderName(parentPath);
    }

    const cleanedName = folderName.replace(/[/\\]/g, "-");
    const path =
      parentPath === "/" ? `/${cleanedName}` : `${parentPath}/${cleanedName}`;

    try {
      const newFolder = await repository.createFolder(path);
      if (newFolder) {
        await refreshTree();
        return newFolder;
      }
    } catch (error) {
      sdk.window.showToast(`Error creating folder: ${error}`, {
        variant: "error",
      });
    }
    return undefined;
  }

  /**
   * Delete a note by path
   */
  async function deleteNote(path: string) {
    try {
      await waitForSaves();
      const success = await repository.deleteNote(path);
      if (success) {
        if (currentNotePath.value === path) {
          currentNotePath.value = undefined;
        }
        await refreshTree();
      }
      return success;
    } catch (error) {
      sdk.window.showToast(`Error deleting note: ${error}`, {
        variant: "error",
      });
      return false;
    }
  }

  /**
   * Save the open state of a folder and all its descendants
   */
  function saveOpenState(path: string): Map<string, boolean> {
    const treeViewStore = useTreeViewStore();
    const openStates = new Map<string, boolean>();

    if (!tree.value) return openStates;

    const node = findNode(path);
    if (!node || node.type !== "folder") return openStates;

    const saveNodeOpenState = (nodePath: string, folder: Folder) => {
      openStates.set(nodePath, treeViewStore.isNodeOpen(nodePath));

      for (const child of folder.children) {
        if (child.type === "folder") {
          saveNodeOpenState(child.path, child as Folder);
        }
      }
    };

    saveNodeOpenState(path, node as Folder);
    return openStates;
  }

  /**
   * Restore the open state of folders with path mapping
   */
  function restoreOpenState(
    oldStates: Map<string, boolean>,
    oldPrefix: string,
    newPrefix: string,
  ) {
    const treeViewStore = useTreeViewStore();

    oldStates.forEach((isOpen, oldPath) => {
      if (oldPath.startsWith(oldPrefix)) {
        const relativePath = oldPath.slice(oldPrefix.length);
        const newPath = newPrefix + relativePath;

        if (isOpen) {
          treeViewStore.openNode(newPath);
        }
      }
    });
  }

  /**
   * Rename/move a note or folder
   */
  async function moveItem(oldPath: string, newPath: string, isFolder: boolean) {
    try {
      await waitForSaves();
      if (!isFolder && !newPath.endsWith(".json")) {
        newPath += ".json";
      }

      let openStates = new Map<string, boolean>();
      if (isFolder) {
        openStates = saveOpenState(oldPath);
      }

      let currentNoteRelativePath: string | undefined = undefined;
      if (isFolder && currentNotePath.value) {
        const isExactFolder = currentNotePath.value === oldPath;
        const isInSubfolder = currentNotePath.value.startsWith(oldPath + "/");

        if (isExactFolder || isInSubfolder) {
          currentNoteRelativePath = currentNotePath.value.slice(oldPath.length);
        }
      }

      const success = await repository.moveItem(oldPath, newPath);
      if (success) {
        if (currentNotePath.value === oldPath) {
          currentNotePath.value = newPath;
        } else if (isFolder && currentNoteRelativePath !== undefined) {
          const newNotePath = newPath + currentNoteRelativePath;
          currentNotePath.value = newNotePath;

          if (
            historyIndex.value >= 0 &&
            historyIndex.value < notesHistory.value.length
          ) {
            notesHistory.value[historyIndex.value] = newNotePath;
          }
        }

        await refreshTree();

        if (isFolder) {
          restoreOpenState(openStates, oldPath, newPath);
        }
      } else {
        sdk.window.showToast(`Error occured while moving item`, {
          variant: "error",
        });
      }
      return success;
    } catch (error) {
      sdk.window.showToast(`Error moving item: ${error}`, {
        variant: "error",
      });
      return false;
    }
  }

  /**
   * Rename a note or folder
   */
  async function renameItem(path: string, newName: string) {
    try {
      if (newName.includes("/") || newName.includes("\\")) {
        throw new Error("New name cannot contain slashes");
      }

      const node = findNode(path);
      if (!node) {
        throw new Error(`Item not found: ${path}`);
      }

      const isFolder = node.type === "folder";
      const pathParts = path.split("/");
      const parentPath = pathParts.slice(0, -1).join("/") || "/";

      const finalName = isFolder
        ? newName
        : newName.endsWith(".json")
          ? newName
          : `${newName}.json`;

      const newPath =
        parentPath === "/" ? `/${finalName}` : `${parentPath}/${finalName}`;

      if (newPath === path) return true;

      return await moveItem(path, newPath.replace(/\.json$/, ""), isFolder);
    } catch (error) {
      sdk.window.showToast(`Error renaming item: ${error}`, {
        variant: "error",
      });
      return false;
    }
  }

  /**
   * Select a note by path or undefined to deselect
   */
  function selectNote(path: string | undefined) {
    if (path === currentNotePath.value) return;

    if (
      historyIndex.value >= 0 &&
      historyIndex.value < notesHistory.value.length - 1
    ) {
      notesHistory.value = notesHistory.value.slice(0, historyIndex.value + 1);
    }

    if (path !== undefined) {
      notesHistory.value.push(path);
      historyIndex.value = notesHistory.value.length - 1;
    }

    currentNotePath.value = path;
  }

  /**
   * Go back to the previous note
   */
  function goBack() {
    if (historyIndex.value <= 0) return;

    historyIndex.value--;
    const previousPath = notesHistory.value[historyIndex.value] || undefined;
    currentNotePath.value = previousPath;
  }

  /**
   * Go forward to the next note
   */
  function goForward() {
    if (historyIndex.value >= notesHistory.value.length - 1) return;

    historyIndex.value++;
    const nextPath = notesHistory.value[historyIndex.value] || undefined;
    currentNotePath.value = nextPath;
  }

  /**
   * Check if we can go back
   */
  function canGoBack() {
    return historyIndex.value > 0;
  }

  /**
   * Check if we can go forward
   */
  function canGoForward() {
    return historyIndex.value < notesHistory.value.length - 1;
  }

  /**
   * Search for notes by content or tags
   */
  async function searchNotes(query: string) {
    try {
      return await repository.searchNotes(query);
    } catch (error) {
      sdk.window.showToast(`Error searching notes: ${error}`, {
        variant: "error",
      });
      return [];
    }
  }

  /**
   * Update the content of a note
   */
  async function updateNoteContent(
    path: string,
    content: NoteContent,
    expectedId?: string,
  ) {
    revision++;
    const project = projectId.value;
    if (project === undefined) throw new Error("No active project");
    const snapshot = JSON.parse(JSON.stringify(content)) as NoteContent;
    const node = findNode(path);
    if (node?.type === "note") (node as Note).content = snapshot;
    writes++;
    isSaving.value = true;
    try {
      await saves.save({
        project,
        path,
        content: snapshot,
        id:
          expectedId ??
          saves.pending.get(JSON.stringify([project, path]))?.id ??
          (node?.type === "note" ? (node as Note).id : undefined),
      });
      if (saves.pending.size === 0) saveError.value = "";
      return true;
    } catch (error) {
      saveError.value =
        error instanceof Error
          ? error.message
          : "Unsaved changes — retry before closing";
      sdk.window.showToast(
        "Could not save note: " +
          String(error) +
          ". Changes are kept in this window.",
        { variant: "error" },
      );
      return false;
    } finally {
      isSaving.value = --writes > 0;
    }
  }

  /**
   * Delete a folder by path
   */
  async function deleteFolder(path: string) {
    try {
      await waitForSaves();
      const isCurrentNoteExactFolder = currentNotePath.value === path;
      const isCurrentNoteInSubfolder =
        currentNotePath.value && currentNotePath.value.startsWith(path + "/");

      const success = await repository.deleteFolder(path);
      if (success) {
        if (isCurrentNoteExactFolder || isCurrentNoteInSubfolder) {
          currentNotePath.value = undefined;

          const firstNotePath = findFirstNote();
          if (firstNotePath) {
            selectNote(firstNotePath);
          }
        }
        await refreshTree();
      }
      return success;
    } catch (error) {
      sdk.window.showToast(`Error deleting folder: ${error}`, {
        variant: "error",
      });
      return false;
    }
  }

  emitter.on("refreshTree", (affected) => {
    if (affected > 0) {
      refreshTree();
    }

    sdk.window.showToast(`${affected} notes were affected by the migration`, {
      variant: "info",
    });
  });

  sdk.backend.onEvent("notes++:projectChange", async () => {
    currentNotePath.value = undefined;
    projectId.value = undefined;
    tree.value = undefined;
    notesHistory.value = [];
    historyIndex.value = -1;
    await refreshTree();
  });
  emitter.on("openNote", async (target) => {
    await refreshTree();
    if (projectId.value === target.projectId) selectNote(target.path);
  });

  sdk.backend.onEvent("notes++:noteChange", async (project) => {
    if (project !== projectId.value || writes > 0) return;
    await saves.settled();
    if (saves.pending.size === 0) await refreshTree();
  });

  return {
    projectId,
    saveError,
    retrySaves,
    recoverDrafts,
    currentNotePath,
    currentNote,
    tree,
    notesHistory,
    historyIndex,
    isSaving,

    findNode,
    initialize,
    refreshTree,
    loadNote,
    createNote,
    createFolder,
    deleteNote,
    deleteFolder,
    moveItem,
    renameItem,
    selectNote,
    searchNotes,
    updateNoteContent,
    goBack,
    goForward,
    canGoBack,
    canGoForward,
  };
});
