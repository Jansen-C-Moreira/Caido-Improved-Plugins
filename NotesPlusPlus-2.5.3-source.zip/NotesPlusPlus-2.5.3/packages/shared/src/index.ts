export interface TreeNode {
  path: string;
  name: string;
  type: "note" | "folder";
  metadata: {
    createdAt: Date;
    modifiedAt: Date;
  };
}

export interface Note extends TreeNode {
  id?: string;
  revision?: number;
  association?: ReplayAssociation;
  type: "note";
  content: NoteContent;
  isLegacy?: boolean;
}

export interface Folder extends TreeNode {
  type: "folder";
  children: TreeNode[];
}

export interface NoteContent {
  type: string;
  content: NoteContentItem[];
}

export interface NoteContentItem {
  marks?: { type: string; attrs?: Record<string, unknown> }[];
  type: string;
  content?: NoteContentItem[];
  text?: string;
  attrs?: Record<string, unknown>;
}

export type ReplayAssociation = { sessionId: string; entryId?: string };
export type Evidence = {
  id: string;
  projectId: string;
  capturedAt: string;
  kind: "replay" | "finding";
  title: string;
  sessionId?: string;
  entryId?: string;
  findingId?: string;
  requestId?: string;
  responseId?: string;
  request?: string;
  response?: string;
  description?: string;
  reporter?: string;
  endpoint?: string;
};

export interface NoteModalSaveData {
  content: string;
  attachContext: boolean;
  notePath: string;
}

export interface Reminder {
  id: string;
  notePath: string;
  context: string;
  reminderAt: string;
  createdAt: string;
  triggered: boolean;
  dismissed: boolean;
}

export type Result<T> =
  | { kind: "Error"; error: string }
  | { kind: "Success"; value: T };

export function ok<T>(value: T): Result<T> {
  return { kind: "Success", value };
}

export function error<T>(error: string): Result<T> {
  return { kind: "Error", error };
}
