import { Buffer } from "buffer";

import type { NoteContent } from "shared";

/** Bound documents and reject dangerous attribute keys before persistence/rendering. */
export function validateContent(value: unknown): asserts value is NoteContent {
  const serialized = JSON.stringify(value);
  if (
    serialized === undefined ||
    Buffer.byteLength(serialized, "utf8") > 10 * 1024 * 1024
  ) {
    throw new Error("Note content exceeds 10 MB");
  }
  let count = 0;
  function visit(value: unknown, depth: number): void {
    if (++count > 100000 || depth > 64) throw new Error("Note is too complex");
    if (typeof value !== "object" || value === null) return;
    for (const [key, child] of Object.entries(value)) {
      if (["__proto__", "constructor", "prototype"].includes(key))
        throw new Error("Unsafe note attribute");
      visit(child, depth + 1);
    }
  }
  visit(value, 0);
  if (
    typeof value !== "object" ||
    value === null ||
    !("type" in value) ||
    value.type !== "doc" ||
    !("content" in value) ||
    !Array.isArray(value.content)
  ) {
    throw new Error("Invalid note document");
  }
  const nodes = new Set([
    "doc",
    "paragraph",
    "text",
    "heading",
    "hardBreak",
    "horizontalRule",
    "blockquote",
    "bulletList",
    "orderedList",
    "listItem",
    "codeBlock",
    "table",
    "tableRow",
    "tableCell",
    "tableHeader",
    "image",
    "mention",
    "fileMention",
    "reminderNode",
    "evidence",
  ]);
  const marks = new Set([
    "bold",
    "italic",
    "strike",
    "code",
    "underline",
    "highlight",
    "font",
    "link",
  ]);
  function documentNode(input: unknown): void {
    if (input === null || typeof input !== "object")
      throw new Error("Invalid document node");
    const node = input as Record<string, unknown>;
    if (typeof node.type !== "string" || !nodes.has(node.type))
      throw new Error("Unsupported document node");
    if (node.text !== undefined && typeof node.text !== "string")
      throw new Error("Invalid text");
    if (node.marks !== undefined) {
      if (!Array.isArray(node.marks)) throw new Error("Invalid text marks");
      for (const input of node.marks) {
        if (input === null || typeof input !== "object")
          throw new Error("Invalid text mark");
        const mark = input as Record<string, unknown>;
        if (typeof mark.type !== "string" || !marks.has(mark.type))
          throw new Error("Unsupported text mark");
        const attrs = mark.attrs as Record<string, unknown> | undefined;
        if (
          mark.type === "link" &&
          (typeof attrs?.href !== "string" ||
            !/^(https?:\/\/|mailto:)/i.test(attrs.href) ||
            Array.from(attrs.href).some((char) => char.charCodeAt(0) <= 32))
        )
          throw new Error("Unsafe link URL");
        if (
          mark.type === "font" &&
          (!["inherit", "sans-serif", "serif", "monospace"].includes(
            String(attrs?.family),
          ) ||
            !["12px", "14px", "16px", "20px", "24px", "32px"].includes(
              String(attrs?.size),
            ))
        )
          throw new Error("Unsupported font style");
      }
    }
    if (node.content !== undefined) {
      if (!Array.isArray(node.content)) throw new Error("Invalid child nodes");
      node.content.forEach(documentNode);
    }
  }
  documentNode(value);
}
