import { Buffer } from "buffer";
import { randomUUID } from "crypto";
import * as fs from "fs";
import path from "path";

import type { SDK } from "caido:plugin";
import type {
  Evidence,
  Folder,
  Note,
  NoteContent,
  ReplayAssociation,
  Result,
} from "shared";
import { error, ok } from "shared";
import { z } from "zod";

import type { BackendEvents } from "../types/events";
import { writeJsonAtomic } from "../utils/atomic";
import { ensureProjectDirectory } from "../utils/fileSystem";
import { identity } from "../utils/identity";
import { getNoteRootPath } from "../utils/paths";
import { assertNoLinks, resolveNotePath } from "../utils/safePath";

import { createNote, getTree, updateNote } from "./note";

const id = z.string().regex(/^[a-zA-Z0-9_-]{1,128}$/);
const association = z.object({ sessionId: id, entryId: id.optional() });
const raw = z
  .string()
  .max(14 * 1024 * 1024)
  .regex(/^[A-Za-z0-9+/]*={0,2}$/)
  .refine(
    (value) =>
      value.length % 4 === 0 &&
      Buffer.from(value, "base64").toString("base64") === value,
    "Invalid Base64",
  )
  .optional();
const schema = z.object({
  kind: z.enum(["replay", "finding"]),
  title: z.string().max(10000),
  sessionId: id.optional(),
  entryId: id.optional(),
  findingId: id.optional(),
  requestId: id.optional(),
  responseId: id.optional(),
  request: raw,
  response: raw,
  description: z.string().max(1000000).optional(),
  reporter: z.string().max(10000).optional(),
  endpoint: z.string().max(10000).optional(),
});

// GraphQL Blob scalars are not a byte transport contract. Read both sides of
// the stored exchange together and encode the original bytes exactly once.
export async function getHttpEvidence(
  sdk: SDK,
  projectId: string,
  requestId: string,
  parts: "request" | "response" | "both",
): Promise<Result<Partial<Evidence>>> {
  try {
    id.parse(requestId);
    z.enum(["request", "response", "both"]).parse(parts);
    const project = await ensureProjectDirectory(sdk, projectId);
    if (project.kind === "Error") return project;
    const exchange = await sdk.requests.get(requestId);
    const active = await ensureProjectDirectory(sdk, projectId);
    if (active.kind === "Error") return active;
    if (exchange === undefined) return error("The sent request is unavailable");
    const request =
      parts !== "response" ? exchange.request.getRaw().toBytes() : undefined;
    const response =
      parts !== "request" ? exchange.response?.getRaw().toBytes() : undefined;
    if ((request?.length ?? 0) + (response?.length ?? 0) > 10 * 1024 * 1024)
      return error("Evidence exceeds 10 MB of raw data");
    return ok({
      requestId: exchange.request.getId(),
      responseId: exchange.response?.getId(),
      endpoint: `${exchange.request.getMethod()} ${exchange.request.getUrl()}`,
      request:
        request === undefined
          ? undefined
          : Buffer.from(request).toString("base64"),
      response:
        response === undefined
          ? undefined
          : Buffer.from(response).toString("base64"),
    });
  } catch (cause) {
    return error(
      cause instanceof z.ZodError
        ? "Invalid HTTP evidence selection"
        : String(cause),
    );
  }
}

export async function saveEvidence(
  sdk: SDK,
  projectId: string,
  input: Omit<Evidence, "id" | "projectId" | "capturedAt">,
): Promise<Result<Evidence>> {
  try {
    const project = await ensureProjectDirectory(sdk, projectId);
    if (project.kind === "Error") return project;
    const value = schema.parse(input);
    if (
      Buffer.from(value.request ?? "", "base64").length +
        Buffer.from(value.response ?? "", "base64").length >
        10 * 1024 * 1024 ||
      Buffer.byteLength(JSON.stringify(value), "utf8") > 14 * 1024 * 1024
    )
      return error("Evidence exceeds 10 MB of raw data");
    const evidence: Evidence = {
      ...value,
      id: randomUUID(),
      projectId,
      capturedAt: new Date().toISOString(),
    };
    const target = path.join(
      getNoteRootPath(projectId),
      ".notesplusplus-metadata",
      "evidence",
      `${evidence.id}.json`,
    );
    assertNoLinks(target);
    writeJsonAtomic(target, evidence);
    return ok(evidence);
  } catch (cause) {
    return error(
      cause instanceof z.ZodError
        ? `Invalid evidence: ${[...new Set(cause.issues.map((issue) => issue.path.join(".")))].join(", ")}. Reopen the picker and capture the source again.`
        : String(cause),
    );
  }
}

export async function getEvidence(
  sdk: SDK,
  projectId: string,
  evidenceId: string,
): Promise<Result<Evidence>> {
  try {
    id.parse(evidenceId);
    const project = await ensureProjectDirectory(sdk, projectId);
    if (project.kind === "Error") return project;
    const target = path.join(
      getNoteRootPath(projectId),
      ".notesplusplus-metadata",
      "evidence",
      `${evidenceId}.json`,
    );
    assertNoLinks(target);
    if (fs.statSync(target).size > 15 * 1024 * 1024)
      return error("Evidence exceeds size limit");
    return ok(JSON.parse(fs.readFileSync(target, "utf8")) as Evidence);
  } catch (cause) {
    return error(`Evidence unavailable: ${String(cause)}`);
  }
}

function flatten(folder: Folder): Note[] {
  return folder.children.flatMap((child) =>
    child.type === "note" ? [child as Note] : flatten(child as Folder),
  );
}

export async function getReplayNote(
  sdk: SDK,
  projectId: string,
  target: ReplayAssociation,
): Promise<Result<Note | undefined>> {
  try {
    association.parse(target);
    const project = await ensureProjectDirectory(sdk, projectId);
    if (project.kind === "Error") return project;
    const tree = await getTree(sdk);
    if (tree.kind === "Error") return tree;
    const active = await ensureProjectDirectory(sdk, projectId);
    if (active.kind === "Error") return active;
    return ok(
      flatten(tree.value).find(
        (note) =>
          note.association?.sessionId === target.sessionId &&
          note.association?.entryId === target.entryId,
      ),
    );
  } catch (cause) {
    return error(String(cause));
  }
}

// Serialize first saves: two clients cannot create duplicate annotations.
let writes: Promise<unknown> = Promise.resolve();
export async function saveReplayNote(
  sdk: SDK<Record<string, never>, BackendEvents>,
  projectId: string,
  target: ReplayAssociation,
  content: NoteContent,
  revision?: number,
  noteId?: string,
): Promise<Result<Note>> {
  const task = writes.then(async (): Promise<Result<Note>> => {
    try {
      // Optional RPC arguments may arrive as null after serialization.
      revision = revision ?? undefined;
      noteId = noteId ?? undefined;
      association.parse(target);
      const existing = await getReplayNote(sdk, projectId, target);
      if (existing.kind === "Error") return existing;
      if (existing.value !== undefined) {
        if (noteId !== undefined && noteId !== existing.value.id)
          return error(
            "Conflict: this annotation was replaced. Recover your draft before reloading.",
          );
        if (revision === undefined)
          return error(
            "Conflict: an annotation was created in another editor. Recover your draft before reloading.",
          );
        return updateNote(
          sdk,
          existing.value.path,
          { content, revision, id: existing.value.id },
          projectId,
        );
      }
      if (revision !== undefined)
        return error(
          "The annotation was deleted. Recover your draft before reloading.",
        );
      const note = await createNote(
        sdk,
        `/Replay Notes/Replay ${target.sessionId}/${target.entryId === undefined ? "Session" : `Execution ${target.entryId}`}-${randomUUID().slice(0, 8)}.json`,
        content,
        projectId,
      );
      if (note.kind === "Error") return note;
      const file = resolveNotePath(getNoteRootPath(projectId), note.value.path);
      const document = JSON.parse(fs.readFileSync(file, "utf8"));
      document.notesplusplus = { ...identity(file), association: target };
      writeJsonAtomic(file, document);
      sdk.api.send("notes++:noteChange", projectId);
      return ok({ ...note.value, association: target });
    } catch (cause) {
      return error(String(cause));
    }
  });
  writes = task.catch(() => {});
  return task;
}
