import * as fs from "fs";
import path from "path";

import type { SDK } from "caido:plugin";
import type { Folder, Note, NoteContent, Result, TreeNode } from "shared";
import { error, ok } from "shared";

import {
  createNoteSchema,
  deleteNoteSchema,
  getNoteSchema,
  moveItemSchema,
  searchNotesSchema,
  updateNoteSchema,
} from "../schemas/note";
import type { BackendEvents } from "../types/events";
import {
  createDirectory,
  deleteFile,
  directoryExists,
  ensureJsonExtension,
  ensureProjectDirectory,
  fileExists,
  getNameFromPath,
  move,
  normalizePath,
  readFile,
  writeFile,
} from "../utils/fileSystem";
import { identity } from "../utils/identity";
import { getNoteRootPath } from "../utils/paths";
import { resolveNotePath } from "../utils/safePath";

/**
 * Get entire folder structure as a tree
 */
export async function getTree(sdk: SDK): Promise<Result<Folder>> {
  try {
    const projectIDResult = await ensureProjectDirectory(sdk);
    if (projectIDResult.kind === "Error") {
      return error(projectIDResult.error);
    }

    const projectID = projectIDResult.value;
    const rootPath = getNoteRootPath(projectID);
    if (!directoryExists(rootPath)) {
      createDirectory(rootPath);
      return ok({
        path: "/",
        name: "Root",
        type: "folder",
        children: [],
        metadata: {
          createdAt: new Date(),
          modifiedAt: new Date(),
        },
      });
    }

    return ok(buildFolderTree(rootPath, "/"));
  } catch (err) {
    sdk.console.error(`Error getting tree: ${err}`);
    return error(err instanceof Error ? err.message : String(err));
  }
}

/**
 * Get a specific note
 */
export async function getNote(
  sdk: SDK,
  notePath: string,
): Promise<Result<Note>> {
  try {
    getNoteSchema.parse({ path: notePath });

    const projectIDResult = await ensureProjectDirectory(sdk);
    if (projectIDResult.kind === "Error") {
      return error(projectIDResult.error);
    }

    const projectID = projectIDResult.value;
    const rootPath = getNoteRootPath(projectID);
    const fullPath = resolveNotePath(rootPath, ensureJsonExtension(notePath));

    if (!fileExists(fullPath)) {
      return error(`Note not found at path: ${notePath}`);
    }

    const content = readFile(fullPath);
    const name = getNameFromPath(notePath);

    const stats = fs.statSync(fullPath);

    return ok({
      path: ensureJsonExtension(notePath),
      ...identity(fullPath),
      name,
      type: "note",
      content,
      metadata: {
        createdAt: stats.birthtime,
        modifiedAt: stats.mtime,
      },
    });
  } catch (err) {
    sdk.console.error(`Error getting note: ${err}`);
    return error(err instanceof Error ? err.message : String(err));
  }
}

/**
 * Create a new note
 */
export async function createNote(
  sdk: SDK,
  notePath: string,
  content: NoteContent,
  expectedProjectId?: string,
): Promise<Result<Note>> {
  try {
    createNoteSchema.parse({ path: notePath, content });

    const projectIDResult = await ensureProjectDirectory(
      sdk,
      expectedProjectId,
    );
    if (projectIDResult.kind === "Error") {
      return error(projectIDResult.error);
    }

    const projectID = projectIDResult.value;
    const pathWithExtension = ensureJsonExtension(notePath);
    const rootPath = getNoteRootPath(projectID);
    const fullPath = resolveNotePath(rootPath, pathWithExtension);

    const dirPath = path.dirname(fullPath);
    if (!directoryExists(dirPath)) {
      createDirectory(dirPath);
    }

    if (fileExists(fullPath)) {
      return error(`Note already exists at path: ${notePath}`);
    }

    writeFile(fullPath, content);

    const stats = fs.statSync(fullPath);
    const name = getNameFromPath(notePath);

    return ok({
      path: pathWithExtension,
      ...identity(fullPath),
      name,
      type: "note",
      content,
      metadata: {
        createdAt: stats.birthtime,
        modifiedAt: stats.mtime,
      },
    });
  } catch (err) {
    sdk.console.error(`Error creating note: ${err}`);
    return error(err instanceof Error ? err.message : String(err));
  }
}

/**
 * Update an existing note
 */
export async function updateNote(
  sdk: SDK<Record<string, never>, BackendEvents>,
  notePath: string,
  updates: Partial<Note>,
  expectedProjectId?: string,
): Promise<Result<Note>> {
  try {
    updateNoteSchema.parse({ path: notePath, updates });

    const projectIDResult = await ensureProjectDirectory(
      sdk,
      expectedProjectId,
    );
    if (projectIDResult.kind === "Error") {
      return error(projectIDResult.error);
    }

    const projectID = projectIDResult.value;
    const pathWithExtension = ensureJsonExtension(notePath);
    const rootPath = getNoteRootPath(projectID);
    const fullPath = resolveNotePath(rootPath, pathWithExtension);

    if (!fileExists(fullPath)) {
      return error(`Note not found at path: ${notePath}`);
    }

    const current = identity(fullPath);
    if (updates.id !== undefined && updates.id !== current.id)
      return error(
        "Conflict: this path now belongs to a different note. Recover your draft before reloading.",
      );
    if (updates.revision !== undefined && updates.revision !== current.revision)
      return error(
        "Conflict: this note changed in another editor. Recover your draft before reloading.",
      );
    const existingContent = readFile(fullPath);
    const updatedContent = updates.content ?? existingContent;

    writeFile(fullPath, updatedContent);
    sdk.api.send("notes++:noteChange", projectID);

    const stats = fs.statSync(fullPath);
    const name = getNameFromPath(notePath);

    return ok({
      path: pathWithExtension,
      name,
      type: "note",
      content: updatedContent,
      ...identity(fullPath),
      metadata: {
        createdAt: stats.birthtime,
        modifiedAt: stats.mtime,
      },
    });
  } catch (err) {
    sdk.console.error(`Error updating note: ${err}`);
    return error(err instanceof Error ? err.message : String(err));
  }
}

/**
 * Delete a note
 */
export async function deleteNote(
  sdk: SDK,
  notePath: string,
): Promise<Result<boolean>> {
  try {
    deleteNoteSchema.parse({ path: notePath });

    const projectIDResult = await ensureProjectDirectory(sdk);
    if (projectIDResult.kind === "Error") {
      return error(projectIDResult.error);
    }

    const projectID = projectIDResult.value;
    const pathWithExtension = ensureJsonExtension(notePath);

    const rootPath = getNoteRootPath(projectID);
    const fullPath = resolveNotePath(rootPath, pathWithExtension);

    if (!fileExists(fullPath)) {
      return error(`Note not found at path: ${notePath}`);
    }

    deleteFile(fullPath);

    return ok(true);
  } catch (err) {
    sdk.console.error(`Error deleting note: ${err}`);
    return error(err instanceof Error ? err.message : String(err));
  }
}

/**
 * Move a note or folder to a new location
 */
export async function moveItem(
  sdk: SDK,
  oldPath: string,
  newPath: string,
): Promise<Result<boolean>> {
  try {
    moveItemSchema.parse({ oldPath, newPath });

    const projectIDResult = await ensureProjectDirectory(sdk);
    if (projectIDResult.kind === "Error") {
      return error(projectIDResult.error);
    }

    const projectID = projectIDResult.value;
    const rootPath = getNoteRootPath(projectID);

    const isNote =
      oldPath.endsWith(".json") ||
      !directoryExists(resolveNotePath(rootPath, oldPath));

    // Add .json extension if needed for notes
    const sourcePathWithExt = isNote ? ensureJsonExtension(oldPath) : oldPath;
    const targetPathWithExt = isNote ? ensureJsonExtension(newPath) : newPath;

    const sourcePath = resolveNotePath(rootPath, sourcePathWithExt);
    const targetPath = resolveNotePath(rootPath, targetPathWithExt);

    if (
      (isNote && !fileExists(sourcePath)) ||
      (!isNote && !directoryExists(sourcePath))
    ) {
      return error(`Source path not found: ${oldPath}`);
    }

    if (
      targetPath === sourcePath ||
      targetPath.startsWith(sourcePath + path.sep)
    ) {
      return error("Cannot move an item into itself or its descendants");
    }

    const targetDir = path.dirname(targetPath);
    if (!directoryExists(targetDir)) {
      createDirectory(targetDir);
    }

    if (
      (isNote && fileExists(targetPath)) ||
      (!isNote && directoryExists(targetPath))
    ) {
      return error(`Target path already exists: ${newPath}`);
    }

    move(sourcePath, targetPath);
    return ok(true);
  } catch (err) {
    sdk.console.error(`Error moving item: ${err}`);
    return error(err instanceof Error ? err.message : String(err));
  }
}

/**
 * Search notes by content
 */
export async function searchNotes(
  sdk: SDK,
  query: string,
): Promise<Result<Note[]>> {
  try {
    searchNotesSchema.parse({ query });

    const projectIDResult = await ensureProjectDirectory(sdk);
    if (projectIDResult.kind === "Error") {
      return error(projectIDResult.error);
    }

    const projectID = projectIDResult.value;
    const results: Note[] = [];
    const rootPath = getNoteRootPath(projectID);
    const lowercaseQuery = query.toLowerCase();

    const searchInDirectory = (
      dirPath: string,
      relativePath: string = "",
    ): void => {
      const entries = fs.readdirSync(dirPath);

      for (const entry of entries) {
        if (entry.startsWith(".notesplusplus-")) continue;
        const fullPath = resolveNotePath(dirPath, entry);
        const normalizedEntry = normalizePath(entry);
        const normalizedRelativePath = relativePath
          ? normalizePath(relativePath)
          : "";
        const entryPath = normalizePath(
          path.join(normalizedRelativePath, normalizedEntry),
        );

        if (directoryExists(fullPath)) {
          searchInDirectory(fullPath, entryPath);
        } else if (entry.endsWith(".json") && fileExists(fullPath)) {
          const name = getNameFromPath(normalizedEntry);

          const nameMatch = name.toLowerCase().includes(lowercaseQuery);
          const pathMatch = entryPath.toLowerCase().includes(lowercaseQuery);

          if (nameMatch || pathMatch) {
            try {
              const content = readFile(fullPath);
              const stats = fs.statSync(fullPath);

              results.push({
                ...identity(fullPath),
                path: normalizePath(entryPath),
                name,
                type: "note",
                content,
                metadata: {
                  createdAt: stats.birthtime,
                  modifiedAt: stats.mtime,
                },
              });

              continue;
            } catch (err) {
              sdk.console.error(
                `Error reading file during search: ${fullPath}`,
              );
              continue;
            }
          }
        }
      }
    };

    searchInDirectory(rootPath);
    return ok(results);
  } catch (err) {
    sdk.console.error(`Error searching notes: ${err}`);
    return error(err instanceof Error ? err.message : String(err));
  }
}

/**
 * Helper function to build folder tree from filesystem
 */
function buildFolderTree(dirPath: string, relativePath: string): Folder {
  const entries = fs.readdirSync(dirPath);
  const children: TreeNode[] = [];
  const dirStat = fs.statSync(dirPath);

  for (const entry of entries) {
    if (entry.startsWith(".notesplusplus-")) continue;
    const fullPath = resolveNotePath(dirPath, entry);
    const normalizedEntry = normalizePath(entry);
    const normalizedRelativePath = normalizePath(relativePath);
    const entryRelativePath = normalizePath(
      path.join(normalizedRelativePath, normalizedEntry),
    );

    if (directoryExists(fullPath)) {
      children.push(buildFolderTree(fullPath, entryRelativePath));
    } else if (entry.endsWith(".json") && fileExists(fullPath)) {
      try {
        const content = readFile(fullPath);
        const name = getNameFromPath(normalizedEntry);
        const stats = fs.statSync(fullPath);

        const noteObj: Note = {
          ...identity(fullPath),
          path: normalizePath(entryRelativePath),
          name,
          type: "note",
          content,
          metadata: {
            createdAt: stats.birthtime,
            modifiedAt: stats.mtime,
          },
        };

        children.push(noteObj);
      } catch (err) {
        // Skip files that can't be read
      }
    }
  }

  return {
    path: normalizePath(relativePath),
    name: path.basename(relativePath) || "Root",
    type: "folder",
    children,
    metadata: {
      createdAt: dirStat.birthtime,
      modifiedAt: dirStat.mtime,
    },
  };
}
