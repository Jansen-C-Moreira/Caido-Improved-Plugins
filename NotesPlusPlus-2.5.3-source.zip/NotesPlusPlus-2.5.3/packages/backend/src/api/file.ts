import { Buffer } from "buffer";
import * as fs from "fs";

import type { SDK } from "caido:plugin";

import { assertNoLinks } from "../utils/safePath";

const MAX_FILE_BYTES = 5 * 1024 * 1024;

export async function getFileContent(
  sdk: SDK,
  fileId: string,
): Promise<string> {
  return Buffer.from(await getFileBytes(sdk, fileId), "base64").toString(
    "utf8",
  );
}

export async function getFileBytes(sdk: SDK, fileId: string): Promise<string> {
  if (typeof fileId !== "string" || fileId.length === 0)
    throw new Error("Invalid hosted file ID");
  const file = (await sdk.hostedFile.getAll()).find(
    (file) => file.id === fileId,
  );
  if (file === undefined) throw new Error("Hosted file not found");
  assertNoLinks(file.path);
  const stats = fs.statSync(file.path);
  if (!stats.isFile() || stats.size > MAX_FILE_BYTES) {
    throw new Error("Only regular hosted files up to 5 MB can be embedded");
  }
  return Buffer.from(fs.readFileSync(file.path)).toString("base64");
}
