import { randomUUID } from "crypto";
import * as fs from "fs";
import path from "path";

import { assertNoLinks } from "./safePath";

export function writeJsonAtomic(target: string, value: unknown): void {
  assertNoLinks(target);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  const temp = path.join(
    path.dirname(target),
    `.notesplusplus-${randomUUID()}.tmp`,
  );
  try {
    fs.writeFileSync(temp, JSON.stringify(value, undefined, 2));
    fs.renameSync(temp, target);
  } finally {
    fs.rmSync(temp, { force: true });
  }
}
