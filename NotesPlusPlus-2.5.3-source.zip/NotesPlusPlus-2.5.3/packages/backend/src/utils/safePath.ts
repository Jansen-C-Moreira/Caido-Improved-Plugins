import * as fs from "fs";
import path from "path";

const trustedRoots: string[] = [];

/** The Caido-managed plugin directory is trusted; inspect links below it. */
export function configureTrustedRoot(root: string): void {
  const absolute = path.resolve(root);
  if (!trustedRoots.includes(absolute)) trustedRoots.push(absolute);
}

/** Caido exposes Dirent checks, but not lstat/realpath. Reject existing links. */
export function assertNoLinks(target: string): void {
  const absolute = path.resolve(target);
  const root =
    trustedRoots
      .filter(
        (trusted) =>
          absolute === trusted || absolute.startsWith(trusted + path.sep),
      )
      .sort((a, b) => b.length - a.length)[0] ?? path.parse(absolute).root;
  if (absolute === root) return;
  let parent = root;
  for (const segment of absolute
    .slice(root.length)
    .split(path.sep)
    .filter(Boolean)) {
    const entry = fs
      .readdirSync(parent, { withFileTypes: true })
      .find((entry) =>
        path.sep === "\\"
          ? entry.name.toLowerCase() === segment.toLowerCase()
          : entry.name === segment,
      );
    if (entry === undefined) return;
    if (entry.isSymbolicLink())
      throw new Error("Symbolic links are not supported for notes");
    parent = path.join(parent, segment);
  }
}

/** UI paths have one leading slash; they are never host absolute paths. */
export function validateNotePath(input: string): string {
  if (
    typeof input !== "string" ||
    input.length === 0 ||
    input.startsWith("//")
  ) {
    throw new Error("Invalid note path");
  }
  const relative = input.replace(/^\//, "");
  const segments = relative.split("/");
  if (
    segments.some(
      (segment) =>
        segment.length === 0 ||
        segment === "." ||
        segment === ".." ||
        /[\\<>:"|?*]/.test(segment) ||
        [...segment].some((character) => character.charCodeAt(0) < 32) ||
        /[. ]$/.test(segment) ||
        /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(segment) ||
        segment.toLowerCase().startsWith(".notesplusplus-"),
    )
  ) {
    throw new Error("Invalid or reserved note path");
  }
  return relative;
}

export function resolveNotePath(root: string, input: string): string {
  const target = path.resolve(root, validateNotePath(input));
  if (!target.startsWith(path.resolve(root) + path.sep)) {
    throw new Error("Path must stay inside the notes directory");
  }
  assertNoLinks(target);
  return target;
}
