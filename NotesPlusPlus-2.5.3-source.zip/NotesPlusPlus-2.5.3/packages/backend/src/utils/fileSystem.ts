import * as fs from "fs";
import path from "path";

import type { SDK } from "caido:plugin";
import type { NoteContent, Result } from "shared";
import { error, ok } from "shared";

import { validateContent } from "../schemas/content";

import { writeJsonAtomic } from "./atomic";
import { identity } from "./identity";
import { getNoteRootPath } from "./paths";
import { assertNoLinks, validateNotePath } from "./safePath";

/**
 * Normalize path to use forward slashes for application use
 */
export function normalizePath(filepath: string): string {
  return filepath.split(path.sep).join("/");
}

/**
 * Convert application path (with forward slashes) to system path
 */
export function toSystemPath(filepath: string): string {
  return filepath.split("/").join(path.sep);
}

/**
 * Copy a file using readFile and writeFile
 */
export function copyFile(source: string, destination: string): void {
  const content = fs.readFileSync(toSystemPath(source));
  fs.writeFileSync(toSystemPath(destination), content);
}

/**
 * Rename a file by copying it to the new location and removing the old one
 */
export function moveFile(source: string, destination: string): void {
  assertNoLinks(source);
  assertNoLinks(destination);
  fs.renameSync(toSystemPath(source), toSystemPath(destination));
}

/**
 * Delete a file
 */
export function deleteFile(filepath: string): void {
  fs.rmSync(toSystemPath(filepath));
}

/**
 * Copy a directory recursively
 */
export function copyDirectory(source: string, destination: string): void {
  fs.mkdirSync(toSystemPath(destination), { recursive: true });
  const entries = fs.readdirSync(toSystemPath(source));

  for (const entry of entries) {
    const sourcePath = path.join(source, entry);
    const destPath = path.join(destination, entry);

    if (fs.statSync(toSystemPath(sourcePath)).isDirectory()) {
      copyDirectory(sourcePath, destPath);
    } else {
      copyFile(sourcePath, destPath);
    }
  }
}

/**
 * Move a directory by copying it to the new location and removing the old one
 */
export function moveDirectory(source: string, destination: string): void {
  assertNoLinks(source);
  assertNoLinks(destination);
  fs.renameSync(toSystemPath(source), toSystemPath(destination));
}

/**
 * Move a file or directory
 */
export function move(source: string, destination: string): void {
  if (fs.statSync(toSystemPath(source)).isDirectory()) {
    moveDirectory(source, destination);
  } else {
    moveFile(source, destination);
  }
}

/**
 * Check if a directory exists
 */
export function directoryExists(filepath: string): boolean {
  try {
    return fs.statSync(toSystemPath(filepath)).isDirectory();
  } catch (error) {
    return false;
  }
}

/**
 * Check if a file exists
 */
export function fileExists(filepath: string): boolean {
  try {
    return fs.statSync(toSystemPath(filepath)).isFile();
  } catch (error) {
    return false;
  }
}

/**
 * Create a directory
 */
export function createDirectory(filepath: string): void {
  assertNoLinks(filepath);
  fs.mkdirSync(toSystemPath(filepath), { recursive: true });
}

/**
 * Write content to a file
 */
export function writeFile(filepath: string, content: NoteContent): void {
  const dirPath = path.dirname(filepath);
  if (!directoryExists(dirPath)) {
    createDirectory(dirPath);
  }
  validateContent(content);
  const previous = fileExists(filepath) ? identity(filepath) : undefined;
  writeJsonAtomic(toSystemPath(filepath), {
    ...content,
    notesplusplus:
      previous === undefined
        ? undefined
        : { ...previous, revision: previous.revision + 1 },
  });
}

/**
 * Read content from a file
 */
export function readFile(filepath: string): NoteContent {
  assertNoLinks(filepath);
  if (fs.statSync(filepath).size > 10 * 1024 * 1024)
    throw new Error("Note exceeds 10 MB");
  const content: unknown = JSON.parse(
    fs.readFileSync(toSystemPath(filepath), "utf8"),
  );
  validateContent(content);
  const { notesplusplus: _metadata, ...document } = content as NoteContent & {
    notesplusplus?: unknown;
  };
  return document;
}

/**
 * Create project root directory
 */
export async function ensureProjectDirectory(
  sdk: SDK,
  projectID?: string,
): Promise<Result<string>> {
  let rootPath: string | undefined;
  try {
    const project = await sdk.projects.getCurrent();
    const current = project?.getId();
    if (projectID !== undefined && projectID !== current) {
      return error("Project changed before the note could be saved");
    }
    projectID = current;

    if (!projectID) {
      sdk.console.log("No project found, cannot create notes directory");
      return error("No project found");
    }

    rootPath = getNoteRootPath(projectID);
    createDirectory(rootPath);
    sdk.console.log(`Ensured notes directory at: ${rootPath}`);
    return ok(projectID);
  } catch (err) {
    sdk.console.error(`Failed to create project directory: ${err}`);
    return error(
      `Notes++ storage unavailable${rootPath === undefined ? "" : ` at ${rootPath}`}: ${err instanceof Error ? err.message : String(err)}`,
    );
  }
}

/**
 * Make sure path ends with .json for notes
 */
export function ensureJsonExtension(path: string): string {
  validateNotePath(path);
  return path.endsWith(".json") ? path : `${path}.json`;
}

/**
 * Get name from path
 */
export function getNameFromPath(filepath: string): string {
  const parts = filepath.split("/");
  const filename = parts[parts.length - 1] || "";
  const lastDotIndex = filename.lastIndexOf(".");
  return lastDotIndex === -1 ? filename : filename.substring(0, lastDotIndex);
}
