import * as fs from "fs";
import path from "path";

import type { Reminder } from "shared";
import { z } from "zod";

import { writeJsonAtomic } from "./atomic";
import {
  createDirectory,
  directoryExists,
  fileExists,
  toSystemPath,
} from "./fileSystem";
import { getNoteRootPath } from "./paths";
import { assertNoLinks } from "./safePath";

const REMINDERS_FILENAME = "reminders.json";

const ReminderSchema = z.object({
  id: z.string(),
  notePath: z.string(),
  context: z.string(),
  reminderAt: z.string(),
  createdAt: z.string(),
  triggered: z.boolean(),
  dismissed: z.boolean(),
});

const RemindersArraySchema = z.array(ReminderSchema);

export function getRemindersFilePath(projectID: string): string {
  return path.join(
    getNoteRootPath(projectID),
    ".notesplusplus-metadata",
    REMINDERS_FILENAME,
  );
}

export function readRemindersFile(projectID: string): Reminder[] {
  const filePath = getRemindersFilePath(projectID);
  assertNoLinks(filePath);

  if (!fileExists(filePath)) {
    const legacy = path.join(getNoteRootPath(projectID), REMINDERS_FILENAME);
    assertNoLinks(legacy);
    if (fileExists(legacy)) {
      const parsed: unknown = JSON.parse(fs.readFileSync(legacy, "utf8"));
      const result = RemindersArraySchema.safeParse(parsed);
      if (result.success) {
        writeJsonAtomic(filePath, result.data);
        // Keep the original as a hidden backup, without replacing another backup.
        const backup = path.join(
          getNoteRootPath(projectID),
          `.notesplusplus-reminders-${Date.now()}.bak`,
        );
        fs.renameSync(legacy, backup);
        return result.data;
      }
      if (Array.isArray(parsed))
        throw new Error("Invalid legacy reminders; original preserved");
    }
    return [];
  }

  try {
    const raw = fs.readFileSync(toSystemPath(filePath), "utf8");
    const parsed = JSON.parse(raw);
    const result = RemindersArraySchema.safeParse(parsed);
    if (!result.success) throw new Error("Invalid reminders file");
    return result.data;
  } catch {
    throw new Error("Cannot read reminders; file preserved for recovery");
  }
}

export function writeRemindersFile(
  projectID: string,
  reminders: Reminder[],
): void {
  const filePath = getRemindersFilePath(projectID);
  const dirPath = path.dirname(filePath);

  if (!directoryExists(dirPath)) {
    createDirectory(dirPath);
  }

  writeJsonAtomic(toSystemPath(filePath), reminders);
}
