import { randomUUID } from "crypto";
import * as fs from "fs";

import type { ReplayAssociation } from "shared";
import { z } from "zod";

import { writeJsonAtomic } from "./atomic";
import { assertNoLinks } from "./safePath";

export type Identity = {
  id: string;
  revision: number;
  association?: ReplayAssociation;
};
export function identity(file: string): Identity {
  assertNoLinks(file);
  const document = JSON.parse(fs.readFileSync(file, "utf8"));
  if (document.notesplusplus === undefined) {
    document.notesplusplus = { id: randomUUID(), revision: 0 };
    writeJsonAtomic(file, document);
  }
  return z
    .object({
      id: z.string().uuid(),
      revision: z.number().int().nonnegative(),
      association: z
        .object({
          sessionId: z.string().regex(/^[a-zA-Z0-9_-]+$/),
          entryId: z
            .string()
            .regex(/^[a-zA-Z0-9_-]+$/)
            .optional(),
        })
        .optional(),
    })
    .parse(document.notesplusplus);
}
