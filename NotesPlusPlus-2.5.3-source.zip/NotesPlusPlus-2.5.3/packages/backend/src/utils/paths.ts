import * as fs from "fs";
import { homedir } from "os";
import path from "path";

export const NOTES_ROOT_DIR = ".CaidoNotesPlusPlusV2";
export const LEGACY_NOTES_DIR = ".CaidoNotesPlusPlus";
let pluginDataPath: string | undefined;

/** Caido's plugin directory is the stable storage location on POSIX hosts. */
export function configureNoteStorage(dataPath: string): void {
  pluginDataPath = path.resolve(dataPath);
}

function existingHomeProject(projectID: string): string | undefined {
  const homeProject = path.join(homedir(), NOTES_ROOT_DIR, projectID);
  try {
    return fs.statSync(homeProject).isDirectory() ? homeProject : undefined;
  } catch {
    return undefined;
  }
}

/**
 * Get the root path for notes storage
 */
export function getNoteRootPath(projectID?: string, legacy?: boolean): string {
  if (projectID !== undefined && !/^[a-zA-Z0-9_-]+$/.test(projectID))
    throw new Error("Invalid project ID");
  if (!legacy && pluginDataPath !== undefined) {
    if (projectID !== undefined) {
      const existing = existingHomeProject(projectID);
      if (existing !== undefined) return existing;
    }
    return path.join(pluginDataPath, "notes", projectID ?? "");
  }
  if (!projectID) {
    return path.join(homedir(), legacy ? LEGACY_NOTES_DIR : NOTES_ROOT_DIR);
  }
  return path.join(
    homedir(),
    legacy ? LEGACY_NOTES_DIR : NOTES_ROOT_DIR,
    projectID,
  );
}

/**
 * Build a full file path for a note
 */
export function buildNotePath(
  projectID: string,
  filepath: string[],
  legacy?: boolean,
): string {
  return path.join(getNoteRootPath(projectID, legacy), ...filepath);
}
