# Notes++ 2.5.3

Target: Caido 0.58.3. Linux storage fix for the note-tree and note-creation errors shown on Kali.

## Changes

- New Linux installations store notes beneath Caido's plugin data directory, provided by the documented backend `sdk.meta.path()` API. This avoids assuming that the process home directory and every ancestor of it can be scanned by the plugin runtime.
- An existing project directory under the prior `~/.CaidoNotesPlusPlusV2` location is still used. No existing notes are moved or overwritten by this update.
- Path validation continues to reject symbolic links inside both the Caido-managed storage directory and an existing home-based notes directory.
- Storage failures now include the attempted directory path to make any remaining environment problem identifiable.

## Validation

42 automated tests passed. A POSIX filesystem simulation denies directory listing of `/`, then verifies loading an empty note tree, creating and reading a new note in Caido's plugin data directory, and reading an existing project in the old home location. Existing Windows, security, Replay, editor, and export regressions also passed. Type checking, lint, and the production build passed.

The Linux check is a simulated runtime on the development machine. The ZIP has not been installed in the user's Kali instance by the agent.

Install `dist/NotesPlusPlus-2.5.3.zip` as an update. Existing Windows storage and notes remain in their previous location.
