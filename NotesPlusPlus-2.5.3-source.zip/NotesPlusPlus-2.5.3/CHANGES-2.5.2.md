# Notes++ 2.5.2

Target: Caido 0.58.3. Update from 2.5.1.

## Fixes

- Replay **Session note** and **Execution note** can now be saved when optional revision and note ID arguments cross the frontend/backend bridge as `null`. The previous handler treated `null` as a supplied revision and reported that a new annotation had been deleted. The handler now treats `null` and omitted optional arguments alike. Revision and note ID checks still protect existing notes from conflicting edits.
- Saved textual request and response evidence now uses Caido's native HTTP editors in read-only mode, restoring its syntax colors. Binary responses remain download-only. The source bytes stored in a snapshot are unchanged.
- Evidence downloads are compact icon-only buttons with accessible labels and tooltips.

## Validation

40 automated tests passed, including a regression for serialized `null` optional arguments, a mounted request/response card with read-only HTTP editors and download controls, and the earlier security, storage, Replay and export coverage. Type checking, lint and the production build passed. The packaged manifest was verified as version 2.5.2.

The editor and RPC tests use SDK doubles. This build has not been installed or exercised in a real Caido 0.58.3 instance by the agent.

Install `dist/NotesPlusPlus-2.5.2.zip` as a plugin update. An unsaved draft from the prior error remains in the existing dialog until it is closed or reloaded; save a recovery copy before replacing the plugin if the dialog is still open.
