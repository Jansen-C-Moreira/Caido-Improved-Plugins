import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { after, test } from 'node:test';
import { build } from 'esbuild';
import { JSDOM } from 'jsdom';

const dom = new JSDOM('<!doctype html><html><body></body></html>', { pretendToBeVisual: true });
for (const key of ['window','document','navigator','Node','HTMLElement','Element','MutationObserver','getComputedStyle','DOMParser','requestAnimationFrame','cancelAnimationFrame']) {
  Object.defineProperty(globalThis, key, { configurable: true, value: typeof dom.window[key] === 'function' && ['requestAnimationFrame','cancelAnimationFrame','getComputedStyle'].includes(key) ? dom.window[key].bind(dom.window) : dom.window[key] });
}
const root = fileURLToPath(new URL('../', import.meta.url));
const temp = fs.mkdtempSync(path.join(root, '.notesplusplus-test-dom-'));
await build({ stdin: { contents: `
  export { Editor } from '@tiptap/core';
  export { StarterKit } from '@tiptap/starter-kit';
  export { Table, TableRow, TableCell, TableHeader } from '@tiptap/extension-table';
  export { CustomImage } from './src/components/content/editor/extensions/custom-image';
  export { createSessionMention } from './src/components/content/editor/extensions/mentions/mention-request';
  export { ReminderNode } from './src/components/content/editor/extensions/reminder-node';
  export { convertMarkdownToTipTap } from './src/utils/markdownToJSON';
  export { convertTipTapToMarkdown } from './src/utils/jsonToMarkdown';
  export { emitter } from './src/utils/eventBus';
`, resolveDir: path.join(root, 'packages/frontend') },
  bundle: true, platform: 'browser', format: 'esm', outfile: path.join(temp, 'editor.mjs'),
  alias: { '@': path.join(root, 'packages/frontend/src') },
});
const { Editor, StarterKit, Table, TableRow, TableCell, TableHeader, CustomImage, createSessionMention, convertMarkdownToTipTap, convertTipTapToMarkdown, emitter } = await import(pathToFileURL(path.join(temp, 'editor.mjs')).href);
after(() => { dom.window.close(); assert(temp.startsWith(root)); fs.rmSync(temp, { recursive: true, force: true }); });

test('Tiptap 3 edits existing documents and tables without schema errors', () => {
  const editor = new Editor({ extensions: [StarterKit.configure({ link: false, underline: false }), Table, TableRow, TableCell, TableHeader], content: { type:'doc', content:[{type:'paragraph',content:[{type:'text',text:'existing note'}]}] } });
  assert.equal(editor.getText(), 'existing note');
  editor.commands.insertTable({rows:2,cols:2,withHeaderRow:true});
  assert(editor.getJSON().content.some(n => n.type === 'table'));
  editor.destroy();
});

test('remote images never become img sources; embedded images still work', () => {
  const editor = new Editor({ extensions: [StarterKit, CustomImage.configure({allowBase64:true})], content: { type:'doc', content:[{type:'image',attrs:{src:'https://example.invalid/tracker'}},{type:'image',attrs:{src:'data:image/png;base64,aGVsbG8='}}] } });
  assert(!editor.getHTML().includes('https://example.invalid'));
  assert(editor.getHTML().includes('Remote image blocked'));
  assert(editor.getHTML().includes('data:image/png;base64,'));
  editor.destroy();
});

test('Markdown migration and export work with upgraded editor', async () => {
  const content = convertMarkdownToTipTap('# Title\n\nSome **bold** text.');
  assert.equal(content.type, 'doc');
  const markdown = await convertTipTapToMarkdown(content, {});
  assert(markdown.includes('Title')); assert(markdown.includes('**bold**'));
});

test('Replay mention renders current HTTP content and cleans up its own listener', async () => {
  let displayed = ''; let refreshed = 0;
  const sdk = { graphql: { replaySessionEntries: async () => ({ replaySession:{activeEntry:{__typename:'ReplayEntryHttp',raw:btoa('GET /canary HTTP/1.1')}} }) },
    ui: { httpRequestEditor: () => ({ getElement: () => document.createElement('div'), getEditorView: () => ({ state:{doc:{length:0}},dispatch: transaction => {displayed=transaction.changes.insert;} }) }) },
    navigation:{goTo(){}},replay:{openTab(){}} };
  const unrelated = () => {refreshed++;}; emitter.on('refreshEditors', unrelated);
  const editor = new Editor({ extensions:[StarterKit, createSessionMention(sdk)], content:{type:'doc',content:[{type:'paragraph',content:[{type:'mention',attrs:{id:'1',label:'canary'}}]}]} });
  document.body.appendChild(editor.view.dom);
  await new Promise(resolve => setTimeout(resolve, 40));
  assert.equal(displayed, 'GET /canary HTTP/1.1');
  editor.destroy(); emitter.emit('refreshEditors'); assert.equal(refreshed,1);
  emitter.off('refreshEditors', unrelated);
});

test('X removes only its request reference, follows its current position and supports undo', () => {
  let opened = 0;
  const sdk = {
    graphql: { replaySessionEntries: async () => ({ replaySession: { activeEntry: { __typename: 'ReplayEntryHttp', raw: btoa('GET / HTTP/1.1') } } }) },
    ui: { httpRequestEditor: () => ({ getElement: () => document.createElement('div'), getEditorView: () => ({ state: { doc: { length: 0 } }, dispatch() {} }) }) },
    replay: { openTab() { opened++; } }, navigation: { goTo() { opened++; } },
  };
  const editor = new Editor({ extensions: [StarterKit, createSessionMention(sdk)], content: {
    type: 'doc', content: [{ type: 'paragraph', content: [
      { type: 'text', text: 'before ' },
      { type: 'mention', attrs: { id: '1', label: 'first' } },
      { type: 'text', text: ' between ' },
      { type: 'mention', attrs: { id: '2', label: 'second' } },
      { type: 'text', text: ' after' },
    ] }],
  } });
  const button = editor.view.dom.querySelectorAll('.embedded-replay-remove')[1];
  assert.equal(button.getAttribute('aria-label'), 'Remove request from note');
  editor.commands.insertContentAt(1, 'prefix ');
  button.dispatchEvent(new window.MouseEvent('mousedown', { bubbles: true, cancelable: true }));
  button.click();
  const ids = () => editor.getJSON().content.flatMap(n => n.content ?? []).filter(n => n.type === 'mention').map(n => n.attrs.id);
  assert.deepEqual(ids(), ['1']);
  assert(editor.getText().includes('prefix before'));
  assert(editor.getText().includes('after'));
  assert.equal(opened, 0);
  editor.commands.undo();
  assert.deepEqual(ids(), ['1','2']);
  editor.destroy();
});

test('Markdown export decodes Replay Base64 exactly once', async () => {
  const raw = 'POST /test HTTP/1.1\r\nHost: example.test\r\n\r\nação YWJj';
  const sdk = { graphql: { replaySessionEntries: async () => ({ replaySession: { activeEntry: { __typename: 'ReplayEntryHttp', raw: Buffer.from(raw).toString('base64') } } }) } };
  const content = { type: 'doc', content: [{ type: 'mention', attrs: { id: '1' } }] };
  const markdown = await convertTipTapToMarkdown(content, sdk);
  assert(markdown.includes('POST /test HTTP/1.1'));
  assert(markdown.includes('ação YWJj'));
  assert(!markdown.includes(Buffer.from(raw).toString('base64')));
});
