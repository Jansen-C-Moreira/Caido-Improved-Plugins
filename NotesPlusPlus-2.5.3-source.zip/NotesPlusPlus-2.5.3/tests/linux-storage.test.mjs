import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { after, test } from 'node:test';
import { build } from 'esbuild';

const root=fileURLToPath(new URL('../',import.meta.url));
const temp=fs.mkdtempSync(path.join(root,'.notesplusplus-linux-'));
const mappedRoot=path.join(temp,'linux-root');
fs.mkdirSync(path.join(mappedRoot,'caido','plugin'),{recursive:true});
const outfile=path.join(temp,'linux-backend.mjs');
const fsModule=`
import * as fs from 'node:fs';
import path from 'node:path';
const root=${JSON.stringify(mappedRoot)};
const map=value=>path.join(root,String(value).replace(/^\\/+/,''));
export const readdirSync=(value,options)=>{
 if(value==='/') throw Error('IO Error: No such file or directory (os error 2)');
 return fs.readdirSync(map(value),options);
};
export const statSync=value=>fs.statSync(map(value));
export const mkdirSync=(value,options)=>fs.mkdirSync(map(value),options);
export const readFileSync=(value,options)=>fs.readFileSync(map(value),options);
export const writeFileSync=(value,data,options)=>fs.writeFileSync(map(value),data,options);
export const renameSync=(source,destination)=>fs.renameSync(map(source),map(destination));
export const rmSync=(value,options)=>fs.rmSync(map(value),options);
`;
await build({stdin:{contents:`
export * from './src/api/index';
export {configureNoteStorage,getNoteRootPath} from './src/utils/paths';
export {configureTrustedRoot} from './src/utils/safePath';
`,resolveDir:path.join(root,'packages/backend')},bundle:true,platform:'node',format:'esm',outfile,plugins:[{
 name:'posix-runtime',setup(builder){
  builder.onResolve({filter:/^fs$/},()=>({path:'fs',namespace:'linux'}));
  builder.onLoad({filter:/.*/,namespace:'linux'},()=>({contents:fsModule,resolveDir:root}));
  builder.onResolve({filter:/^os$/},()=>({path:'os',namespace:'linux-os'}));
  builder.onLoad({filter:/.*/,namespace:'linux-os'},()=>({contents:'export const homedir=()=>"/home/kali";'}));
  builder.onResolve({filter:/^path$/},()=>({path:'path',namespace:'linux-path'}));
  builder.onLoad({filter:/.*/,namespace:'linux-path'},()=>({contents:'import path from "node:path"; export default path.posix;'}));
 }
}]});
const api=await import(pathToFileURL(outfile).href);
after(()=>{assert(path.resolve(temp).startsWith(path.resolve(root)+path.sep));fs.rmSync(temp,{recursive:true,force:true});});
const sdk={projects:{getCurrent:async()=>({getId:()=> 'project-a'})},console:{log(){},error(){}},api:{send(){}}};
const content={type:'doc',content:[{type:'paragraph',content:[{type:'text',text:'Linux note'}]}]};

test('fresh POSIX installation uses Caido plugin storage without scanning filesystem root',async()=>{
 api.configureNoteStorage('/caido/plugin');
 api.configureTrustedRoot('/caido/plugin');
 api.configureTrustedRoot('/home/kali');
 const first=await api.getTree(sdk);
 assert.equal(first.kind,'Success',JSON.stringify(first));
 assert.equal(api.getNoteRootPath('project-a'),'/caido/plugin/notes/project-a');
 const created=await api.createNote(sdk,'/Kali note',content,'project-a');
 assert.equal(created.kind,'Success',JSON.stringify(created));
 assert(fs.existsSync(path.join(mappedRoot,'caido','plugin','notes','project-a','Kali note.json')));
 const loaded=await api.getTree(sdk);
 assert.equal(loaded.kind,'Success',JSON.stringify(loaded));
 assert.equal(loaded.value.children[0].name,'Kali note');
});

test('existing POSIX home project remains readable at its previous storage path',async()=>{
 fs.mkdirSync(path.join(mappedRoot,'home','kali','.CaidoNotesPlusPlusV2','project-b'),{recursive:true});
 assert.equal(api.getNoteRootPath('project-b'),'/home/kali/.CaidoNotesPlusPlusV2/project-b');
 const previous={...sdk,projects:{getCurrent:async()=>({getId:()=> 'project-b'})}};
 const saved=await api.createNote(previous,'/Older note',content,'project-b');
 assert.equal(saved.kind,'Success',JSON.stringify(saved));
 const tree=await api.getTree(previous);
 assert.equal(tree.kind,'Success',JSON.stringify(tree));
 assert.equal(tree.value.children[0].name,'Older note');
});
