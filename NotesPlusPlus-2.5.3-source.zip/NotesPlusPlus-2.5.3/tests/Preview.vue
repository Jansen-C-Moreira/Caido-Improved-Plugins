<script setup lang="ts">
import Button from "primevue/button";
import { ref } from "vue";
import SearchNoteViewer from "../packages/frontend/src/components/shared/SearchNoteViewer.vue";
import ReplayNotes from "../packages/frontend/src/components/shared/ReplayNotes.vue";
import ExportDialog from "../packages/frontend/src/components/content/ExportDialog.vue";
const replay = ref(false); const exporting = ref(false);
const content = ref({ type: "doc", content: [
 {type:"heading",attrs:{level:1},content:[{type:"text",text:"Authorization testing"}]},
 {type:"paragraph",content:[{type:"text",text:"Captured evidence remains unchanged when the Replay draft is edited. ",marks:[{type:"bold"}]},{type:"text",text:"Review the response before reporting.",marks:[{type:"highlight"}]}]},
 {type:"evidence",attrs:{projectId:"preview",evidenceId:"sample"}},
 {type:"paragraph",content:[{type:"text",text:"Next steps",marks:[{type:"underline"}]}]},
 {type:"bulletList",content:[{type:"listItem",content:[{type:"paragraph",content:[{type:"text",text:"Repeat with a second test account."}]}]}]},
]});
</script>
<template>
 <div id="plugin--notesplusplus" style="padding:24px;max-width:1200px;margin:auto">
  <div class="npp-actions"><h1 style="font-size:22px;margin-right:auto">Notes++ · Mock SDK preview</h1><Button label="Replay Notes" @click="replay = true"/><Button label="Export" @click="exporting = true"/></div>
  <SearchNoteViewer :content="content" @save="content = $event" />
  <ReplayNotes v-if="replay" project-id="preview" session-id="43" entry-id="301" title="Authorization test" @close="replay = false" />
  <ExportDialog v-if="exporting" project-id="preview" :tree="{type:'folder',path:'/',name:'Root',metadata:{},children:[]}" :note="{type:'note',path:'/Authorization.json',name:'Authorization',content,metadata:{}}" @close="exporting = false" />
 </div>
</template>
