import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { after, test } from 'node:test';
import { build } from 'esbuild';
import { JSDOM } from 'jsdom';

const root = fileURLToPath(new URL('../', import.meta.url));
const temp = fs.mkdtempSync(path.join(root, '.notesplusplus-features-'));
const dom = new JSDOM('<!doctype html><html><body></body></html>', { pretendToBeVisual: true });
for (const key of ['window','document','navigator','Node','HTMLElement','Element','MutationObserver','getComputedStyle','DOMParser']) Object.defineProperty(globalThis, key, { configurable: true, value: dom.window[key] });
await build({ stdin: { contents: `
 export * from './src/utils/evidence';
 export * from './src/utils/markdownExport';
 export * from './src/utils/export';
 export * from './src/components/content/editor/extensions/format';
 export { Editor } from '@tiptap/core';
 export { StarterKit } from '@tiptap/starter-kit';
`, resolveDir: path.join(root, 'packages/frontend') }, bundle: true, platform: 'browser', format: 'esm', outfile: path.join(temp, 'features.mjs'), alias: { '@': path.join(root, 'packages/frontend/src') } });
const feature = await import(pathToFileURL(path.join(temp, 'features.mjs')).href);
await build({ entryPoints: [path.join(root, 'packages/backend/src/api/evidence.ts')], bundle: true, platform: 'node', format: 'esm', outfile: path.join(temp, 'backend.mjs'), plugins: [{name:'test-home',setup(build){
 build.onResolve({filter:/^os$/},()=>({path:'home',namespace:'test'}));
 build.onLoad({filter:/.*/,namespace:'test'},()=>({contents:`export const homedir = () => ${JSON.stringify(temp)};`}));
}}] });
const backend = await import(pathToFileURL(path.join(temp, 'backend.mjs')).href);
const backendSdk = {
 console: {log(){},error(){}},
 projects: {getCurrent:async()=>({getId:()=> 'project'})},
 requests: {get:async id => {assert.equal(id,'sent');return {
  request:{getId:()=>id,getMethod:()=> 'GET',getUrl:()=> 'https://example.test/sent',getRaw:()=>({toBytes:()=>Buffer.from('GET /sent HTTP/1.1\r\n\r\n')})},
  response:{getId:()=> 'response',getRaw:()=>({toBytes:()=>Buffer.from('HTTP/1.1 200 OK\r\n\r\nactual response')})},
 };}},
};
after(() => { dom.window.close(); assert(path.resolve(temp).startsWith(path.resolve(root) + path.sep)); fs.rmSync(temp, { recursive: true, force: true }); });
const doc = content => ({ type: 'doc', content });
const text = (text, marks) => ({ type:'paragraph', content:[{type:'text',text,marks}] });
const ok = value => ({kind:'Success',value});
const sdk = { replay: { getSessions: () => [{id:'session',name:'Example'}], getEntry: id => ({id,sessionId:'session',requestId:'sent'}) }, graphql: {
 request: async ({id}) => { assert.equal(id,'sent'); return {request:{id,raw:btoa('GET /sent HTTP/1.1\r\n\r\n'),method:'GET',host:'example.test',path:'/sent',query:'',response:{id:'response'}}}; },
 response: async ({id}) => { assert.equal(id,'response'); return {response:{raw:btoa('HTTP/1.1 200 OK\r\n\r\nactual response')}}; },
 replaySessionEntries: async () => ({replaySession:{activeEntry:{__typename:'ReplayEntryHttp',raw:btoa('saved'),draft:{raw:btoa('GET /unsent HTTP/1.1')}}}}),
 getFinding: async () => ({finding:{id:'finding',title:'Finding',description:'<script>alert(1)</script>',reporter:'test',host:'example.test',path:'/sent',request:{id:'sent'}}}),
}, backend: { getCurrentProjectId: async () => ok('project'), getHttpEvidence: (...args) => backend.getHttpEvidence(backendSdk,...args) } };
// These scalars must never be used as an original-byte transport.
sdk.graphql.request = async () => {throw Error('Do not capture HTTP from GraphQL Blob strings');};
sdk.graphql.response = async () => {throw Error('Do not capture HTTP from GraphQL Blob strings');};

test('historical evidence uses sent request and paired response, never the draft', async () => {
 const capture = await feature.captureReplay(sdk,'session','history','both','project');
 assert.match(feature.httpText(capture.request), /\/sent/); assert.match(feature.httpText(capture.response), /actual response/);
 assert.equal(capture.entryId,'history'); assert.equal(capture.requestId,'sent'); assert.equal(capture.responseId,'response');
 const draft = await feature.captureReplay(sdk,'session',undefined,'request'); assert.match(feature.httpText(draft.request), /\/unsent/); assert.equal(draft.response,undefined);
 await assert.rejects(feature.captureReplay(sdk,'session',undefined,'response'), /Drafts have no response/);
 await assert.rejects(feature.captureReplay(sdk,'other','history','both','project'), /no sent HTTP request/);
 const saved=await backend.saveEvidence(backendSdk,'project',capture);
 assert.equal(saved.kind,'Success',JSON.stringify(saved));
 const stored=await backend.getEvidence(backendSdk,'project',saved.value.id);
 assert.equal(stored.value.request,capture.request); assert.equal(stored.value.response,capture.response);
});

test('binary and Unicode evidence retain original bytes', () => {
 const raw = Buffer.from('GET /café HTTP/1.1\r\n\r\n').toString('base64');
 assert.equal(feature.httpText(raw),'GET /café HTTP/1.1\r\n\r\n');
 assert.equal(feature.httpText(Buffer.from([0,255,1]).toString('base64')),undefined);
 assert.deepEqual([...feature.bytes(Buffer.from([0,255,1]).toString('base64'))],[0,255,1]);
});

test('large backtick-heavy HTTP exports do not overflow the call stack', () => {
 const payload='`x'.repeat(200000);
 const result=feature.fence(payload,'http');
 assert.equal(result,`\x60\x60\x60http\n${payload}\n\x60\x60\x60\n\n`);
});

test('finding-only capture does not fetch HTTP and binary clipboard exports warn', async () => {
 const finding=await feature.captureFinding({...sdk,backend:{getHttpEvidence(){throw Error('Unnecessary HTTP fetch');}}},'finding','none','project');
 assert.equal(finding.request,undefined);
 const context=feature.exportContext(true);context.project='project';
 const local={...sdk,backend:{getEvidence:async()=>ok({id:'binary',kind:'replay',title:'binary',capturedAt:'today',projectId:'project',request:'AP8='})}};
 const md=await feature.serializeMarkdown(doc([{type:'evidence',attrs:{projectId:'project',evidenceId:'binary'}}]),local,context);
 assert.match(md,/Binary request/);assert.equal(context.warnings.length,1);
});

test('table exports preserve fenced payloads outside cells and escape inline pipes', async () => {
 const context=feature.exportContext();
 const payload='GET / HTTP/1.1\nX-Test: a|b\n\n<script>inert</script>';
 const md=await feature.serializeMarkdown(doc([{type:'table',content:[{type:'tableRow',content:[
  {type:'tableHeader',content:[text('a|b',[{type:'code'}])]},
  {type:'tableCell',content:[{type:'codeBlock',content:[{type:'text',text:payload}]}]},
 ]}]}]),sdk,context);
 assert(md.includes('a\\|b')); assert(md.includes('See Table 1, row 1, column 2 below'));
 assert(md.includes(feature.fence(payload).trim()));assert(!md.includes('```<br>'));
});

test('clipboard binary files produce warnings instead of lossy text', async () => {
 const context=feature.exportContext(true);
 const md=await feature.serializeMarkdown(doc([{type:'fileMention',attrs:{id:'file',name:'binary.dat'}}]),{backend:{getFileBytes:async()=> 'AP8='}},context);
 assert.match(md,/Binary file binary/); assert.equal(context.warnings.length,1);assert(!md.includes('\ufffd'));
});

test('HTML sanitization strips executable and remote content while preserving supported marks', () => {
 const clean = feature.sanitizeHTML('<p onclick="evil()"><u>underlined</u><mark>marked</mark><a href="javascript:alert(1)">bad</a><a href="https://example.test">safe</a><img src="https://remote.test/pixel"><script>evil()</script><svg onload="evil()"></svg><span style="font-family:serif;font-size:20px;background:url(https://remote.test)">font</span></p>');
 assert(!/onclick|javascript:|<img|<script|<svg|remote.test|background/.test(clean));
 assert(clean.includes('<u>underlined</u>')); assert(clean.includes('<mark>marked</mark>')); assert(clean.includes('font-size: 20px'));
 const editor = new feature.Editor({extensions:[feature.StarterKit.configure({link:{isAllowedUri:feature.safeLink}}),feature.Font,feature.Highlight],content:clean});
 assert(editor.getHTML().includes('<u>underlined</u>')); assert(editor.getHTML().includes('<mark>marked</mark>')); editor.destroy();
});

test('Markdown exports safe styles, inert findings, fenced HTTP and unavailable-source warnings', async () => {
 const finding = await feature.captureFinding(sdk,'finding','both','project');
 const context = feature.exportContext(); context.project='project';
 const local = {...sdk,backend:{...sdk.backend,getEvidence:async()=>ok({...finding,id:'snapshot',projectId:'project',capturedAt:'2026-09-29'})}};
 const content = doc([text('format',[{type:'underline'},{type:'highlight'},{type:'font',attrs:{family:'serif',size:'20px'}}]),{type:'evidence',attrs:{projectId:'project',evidenceId:'snapshot'}},{type:'evidence',attrs:{projectId:'other',evidenceId:'snapshot'}}]);
 const md = await feature.serializeMarkdown(content,local,context);
 assert(md.includes('<mark><u>format</u></mark>')); assert(md.includes('font-family:serif;font-size:20px'));
 assert(!md.includes('<script>')); assert(md.includes('&lt;script&gt;')); assert(md.includes('GET /sent HTTP/1.1')); assert(md.includes('actual response')); assert.equal(context.warnings.length,1);
 const fenced = feature.fence('```\n<script>alert(1)</script>\n```','http'); assert(fenced.startsWith('````http'));
});

test('live references resolve once per export and missing sources leave placeholders', async () => {
 let calls=0; const local={graphql:{replaySessionEntries:async()=>{calls++;return {replaySession:{activeEntry:{__typename:'ReplayEntryHttp',raw:btoa('GET /once HTTP/1.1')}}};}}};
 const context=feature.exportContext();
 const md=await feature.serializeMarkdown(doc([{type:'mention',attrs:{id:'1'}},{type:'mention',attrs:{id:'1'}}]),local,context);
 assert.equal(calls,1); assert.equal(md.match(/GET \/once/g).length,2);
 const absent=await feature.serializeMarkdown(doc([{type:'mention',attrs:{id:'2'}}]),{graphql:{replaySessionEntries:async()=>{throw Error('deleted')}}},context);
 assert(absent.includes('Unavailable')); assert.equal(context.warnings.length,1);
});

function readZip(bytes) {
 const buffer=Buffer.from(bytes); const files=new Map(); let offset=0;
 while(buffer.readUInt32LE(offset)===0x04034b50){const size=buffer.readUInt32LE(offset+18);const length=buffer.readUInt16LE(offset+26);const extra=buffer.readUInt16LE(offset+28);const name=buffer.subarray(offset+30,offset+30+length).toString('utf8');offset+=30+length+extra;files.set(name,buffer.subarray(offset,offset+size));offset+=size;}
 assert.equal(buffer.readUInt32LE(offset),0x02014b50); assert.equal(buffer.readUInt32LE(buffer.length-22),0x06054b50); return files;
}
test('project ZIP retains relative image/binary assets and resolves filename collisions', async () => {
 const note=(name,content)=>({name,path:`/${name}.json`,type:'note',content,metadata:{}});
 const binary=btoa(String.fromCharCode(0,255,1));
 const first=note('Report',doc([{type:'image',attrs:{src:'data:image/png;base64,aGVsbG8='}},{type:'bulletList',content:[{type:'listItem',content:[{type:'evidence',attrs:{projectId:'project',evidenceId:'binary'}}]}]}]));
 const second=note('report',doc([text('second')]));
 const local={...sdk,backend:{...sdk.backend,getEvidence:async()=>ok({id:'binary',kind:'replay',title:'binary',capturedAt:'today',projectId:'project',request:binary})}};
 const result=await feature.prepareExport(local,{type:'folder',path:'/',children:[first,second]},first,'Project');
 const files=readZip(result.data);
 assert(files.has('Report.md')); assert(files.has('report-2.md'));
 assert.equal([...files.keys()].filter(name=>name.endsWith('.http')).length,1,'nested evidence must not duplicate assets');
 assert([...files.values()].some(data=>data.equals(Buffer.from([0,255,1]))));
 const md=files.get('Report.md').toString(); assert(md.includes('Report-assets/asset-1.png')); assert(md.includes('Report-assets/asset-2.http'));
 assert.equal(feature.safeFilename('../NUL'),'.._NUL'); assert.equal(feature.safeFilename('NUL'),'_NUL');
 const single=await feature.prepareExport(local,{children:[second]},second,'Note'); assert(single.name.endsWith('.md')); assert.equal(Buffer.from(single.data).toString(),'second\n');
});
