import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { after, test } from 'node:test';
import { build } from 'esbuild';
import { JSDOM } from 'jsdom';

const root=fileURLToPath(new URL('../',import.meta.url));
const resolve=createRequire(path.join(root,'packages/frontend/package.json'));
const {parse,compileScript,compileTemplate}=resolve('vue/compiler-sfc');
const temp=fs.mkdtempSync(path.join(root,'.notesplusplus-ui-'));
const dom=new JSDOM('<!doctype html><html><body></body></html>',{pretendToBeVisual:true,url:'http://localhost/'});
for(const key of ['window','document','navigator','Node','HTMLElement','HTMLDivElement','HTMLInputElement','Element','SVGElement','ShadowRoot','MutationObserver','getComputedStyle','DOMParser','requestAnimationFrame','cancelAnimationFrame']) Object.defineProperty(globalThis,key,{configurable:true,value:typeof dom.window[key]==='function'&&['requestAnimationFrame','cancelAnimationFrame','getComputedStyle'].includes(key)?dom.window[key].bind(dom.window):dom.window[key]});
dom.window.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});
globalThis.ResizeObserver=class {observe(){} unobserve(){} disconnect(){}};
globalThis.IntersectionObserver=class {observe(){} unobserve(){} disconnect(){}};
dom.window.HTMLElement.prototype.scrollIntoView=function(){};
await build({stdin:{contents:`
 export { Editor, EditorContent } from '@tiptap/vue-3';
 export { EditorView } from '@codemirror/view';
 export { createApp, h, nextTick } from 'vue';
 export { default as PrimeVue } from 'primevue/config';
 export { SDKPlugin } from './src/plugins/sdk';
 export { editorExtensions } from './src/components/content/editor/extensions/shared';
 export { default as Toolbar } from './src/components/content/editor/Toolbar.vue';
 export { default as ReplayNotes } from './src/components/shared/ReplayNotes.vue';
 export { default as EvidencePicker } from './src/components/content/editor/EvidencePicker.vue';
`,resolveDir:path.join(root,'packages/frontend')},bundle:true,platform:'browser',format:'esm',outfile:path.join(temp,'ui.mjs'),alias:{'@':path.join(root,'packages/frontend/src')},define:{__VUE_OPTIONS_API__:'true',__VUE_PROD_DEVTOOLS__:'false',__VUE_PROD_HYDRATION_MISMATCH_DETAILS__:'false'},plugins:[{name:'vue',setup(builder){
 builder.onLoad({filter:/\.vue$/},async args=>{const {descriptor}=parse(fs.readFileSync(args.path,'utf8'),{filename:args.path});const id='test-component';const script=compileScript(descriptor,{id,inlineTemplate:!!descriptor.scriptSetup,genDefaultAs:'component'});let contents=script.content;if(!descriptor.scriptSetup&&descriptor.template){contents+='\n'+compileTemplate({source:descriptor.template.content,filename:args.path,id}).code+'\ncomponent.render = render;';}return {contents:contents+'\nexport default component;',loader:'ts',resolveDir:path.dirname(args.path)};});
 builder.onResolve({filter:/\.css\?raw$/},args=>({path:path.resolve(args.resolveDir,args.path.replace('@/',path.join(root,'packages/frontend/src/') ).replace('?raw','')),namespace:'raw'}));
 builder.onLoad({filter:/.*/,namespace:'raw'},args=>({contents:`export default ${JSON.stringify(fs.readFileSync(args.path,'utf8'))}`,loader:'js'}));
}}]});
const ui=await import(pathToFileURL(path.join(temp,'ui.mjs')).href);
after(()=>{dom.window.close();assert(path.resolve(temp).startsWith(path.resolve(root)+path.sep));fs.rmSync(temp,{recursive:true,force:true});});
const listeners=new Map();
let record;
const httpEditor=()=>{const view=new ui.EditorView();return {getElement:()=>view.dom,getEditorView:()=>view};};
const sdk={ui:{httpRequestEditor:httpEditor,httpResponseEditor:httpEditor},replay:{getSessions:()=>[],openTab(){},showEntry:async()=>{}},graphql:{},backend:{
 getCurrentProjectId:async()=>({kind:'Success',value:'project'}),
 getEvidence:async()=>({kind:'Success',value:{id:'snapshot',projectId:'project',kind:'replay',title:'Evidence title',capturedAt:'today',request:btoa('GET /proof HTTP/1.1'),response:btoa('HTTP/1.1 200 OK')}}),
 onEvent:(name,callback)=>{listeners.set(name,callback);return{stop:()=>listeners.delete(name)};},
 getReplayNote:async()=>({kind:'Success',value:record}),
 saveReplayNote:async(project,target,content,revision)=>{assert.equal(project,'project');assert.equal(target.sessionId,'session');record={id:'note',revision:(revision??-1)+1,path:'/Replay Notes/session.json',content};return{kind:'Success',value:record};}
},navigation:{goTo(){}},window:{showToast(){}}};
function mount(component,props={}){const host=document.createElement('div');document.body.append(host);const app=ui.createApp(component,props);app.use(ui.PrimeVue,{unstyled:true});app.use(ui.SDKPlugin,sdk);app.mount(host);return{host,close(){app.unmount();host.remove();}};}
const settle=async()=>{await ui.nextTick();await new Promise(resolve=>setTimeout(resolve,35));await ui.nextTick();};

test('shared Vue editor mounts evidence, removes it with X, and restores it with undo',async()=>{
 const editor=new ui.Editor({extensions:ui.editorExtensions(sdk),content:{type:'doc',content:[{type:'paragraph',content:[{type:'text',text:'Before'}]},{type:'evidence',attrs:{projectId:'project',evidenceId:'snapshot'}},{type:'paragraph',content:[{type:'text',text:'After'}]}]}});
 const mounted=mount({setup:()=>()=>ui.h('div',[ui.h(ui.Toolbar,{editor}),ui.h(ui.EditorContent,{editor})])});await settle();
 assert(mounted.host.textContent.includes('GET /proof HTTP/1.1'));
 assert(mounted.host.textContent.includes('HTTP/1.1 200 OK'));
 assert.equal(mounted.host.querySelectorAll('.npp-http-view .cm-editor').length,2);
 assert([...mounted.host.querySelectorAll('.npp-http-view .cm-content')].every(node=>node.getAttribute('contenteditable')==='false'));
 assert(mounted.host.querySelector('[aria-label="Download original request"].npp-icon-button'));
 assert(mounted.host.querySelector('[aria-label="Download original response"].npp-icon-button'));
 const button=mounted.host.querySelector('[aria-label="Remove evidence from note"]');assert(button);button.click();await settle();
 assert(!editor.getJSON().content.some(node=>node.type==='evidence'));assert(editor.getText().includes('Before'));assert(editor.getText().includes('After'));
 editor.commands.undo();await settle();assert(editor.getJSON().content.some(node=>node.type==='evidence'));
 assert.equal(typeof editor.commands.setMarkdownHeading,'function');editor.commands.setTextSelection(2);editor.commands.setMarkdownHeading({level:2});assert.equal(editor.getJSON().content[0].attrs.level,2);
 editor.destroy();mounted.close();
});

test('Replay annotation creates only on Save and uses its captured target',async()=>{
 record=undefined;const mounted=mount(ui.ReplayNotes,{projectId:'project',sessionId:'session',entryId:'execution',title:'Test Replay',onClose(){}});await settle();
 assert.equal(record,undefined);const editable=mounted.host.querySelector('.tiptap');assert(editable);
 editable.focus();document.getSelection().selectAllChildren(editable);editable.dispatchEvent(new dom.window.InputEvent('beforeinput',{inputType:'insertText',data:'annotation',bubbles:true}));
 // Use the actual editor view exposed by ProseMirror to model a keyboard edit.
 const view=editable.editor.view;view.dispatch(view.state.tr.insertText('annotation'));
 await settle();const save=[...mounted.host.querySelectorAll('button')].find(button=>button.textContent==='Save');assert(save&&!save.disabled);save.click();await settle();
 assert(record);assert(JSON.stringify(record.content).includes('annotation'));assert.equal(record.path,'/Replay Notes/session.json');mounted.close();
});

test('evidence picker retries failed history loads without losing executions and inserts both sides',async()=>{
 const previousReplay=sdk.replay,previousGraphql=sdk.graphql;
 let fail=true, captures=0;
 sdk.replay={...previousReplay,getSessions:()=>[{id:'session',name:'Replay test',entryIds:['execution']}],getEntry:()=>({sessionId:'session',requestId:'sent'})};
 sdk.graphql={request:async()=>{if(fail){fail=false;throw Error('Temporary history error');}return {request:{createdAt:'2026-09-29T12:00:00Z',method:'GET',host:'example.test',path:'/sent',raw:'GET /sent HTTP/1.1',response:{id:'response',statusCode:200}}};}};
 sdk.backend.getHttpEvidence=async(project,id,parts)=>{assert.equal(project,'project');assert.equal(id,'sent');assert.equal(parts,'both');captures++;return {kind:'Success',value:{requestId:id,responseId:'response',request:btoa('GET /sent HTTP/1.1'),response:btoa('HTTP/1.1 200 OK')}};};
 sdk.backend.saveEvidence=async(project,value)=>{assert.equal(project,'project');assert.equal(atob(value.response),'HTTP/1.1 200 OK');return {kind:'Success',value:{...value,id:'captured'}};};
 const editor=new ui.Editor({extensions:ui.editorExtensions(sdk),content:'<p>Note</p>'});
 const mounted=mount(ui.EvidencePicker,{editor});
 try {
  await settle();
  mounted.host.querySelector('[aria-label="Source"]').click();await settle();
  const selectOption=async(label)=>{const option=[...mounted.host.querySelectorAll('[role="option"]')].find(item=>item.textContent.includes(label));assert(option,`Missing option: ${label}`);option.click();await settle();};
  await selectOption('Replay test');
  assert.match(mounted.host.textContent,/Temporary history error/);
  const retry=[...mounted.host.querySelectorAll('button')].find(button=>button.textContent==='Load more executions');assert(retry&&!retry.disabled);retry.click();await settle();
  mounted.host.querySelector('[aria-label="Execution"]').click();await settle();await selectOption('example.test/sent');
  assert.match(mounted.host.textContent,/Request \+ Response/);
  const insert=[...mounted.host.querySelectorAll('button')].find(button=>button.textContent==='Insert evidence');assert(insert&&!insert.disabled);insert.click();await settle();
  assert.equal(captures,1);assert(editor.getJSON().content.some(node=>node.type==='evidence'&&node.attrs.evidenceId==='captured'));
 } finally {mounted.close();editor.destroy();sdk.replay=previousReplay;sdk.graphql=previousGraphql;delete sdk.backend.getHttpEvidence;delete sdk.backend.saveEvidence;}
});

test('failed finding discovery can be retried and defaults to finding-only evidence',async()=>{
 const previous=sdk.graphql;let calls=0;
 sdk.graphql={getFindingsByOffset:async()=>{if(++calls===1)throw Error('Temporary findings error');return {findingsByOffset:{edges:[{node:{id:'finding',title:'Test finding',host:'example.test',path:'/'}}]}};}};
 const editor=new ui.Editor({extensions:ui.editorExtensions(sdk),content:'<p>Note</p>'});
 const mounted=mount(ui.EvidencePicker,{editor,initial:'findings'});
 try {
  await settle();assert.match(mounted.host.textContent,/Temporary findings error/);
  const retry=[...mounted.host.querySelectorAll('button')].find(button=>button.textContent==='Load findings');assert(retry&&!retry.disabled);retry.click();await settle();
  mounted.host.querySelector('[aria-label="Source"]').click();await settle();
  [...mounted.host.querySelectorAll('[role="option"]')].find(item=>item.textContent.includes('Test finding')).click();await settle();
  assert.match(mounted.host.querySelector('[aria-label="Include request, response, both, or no HTTP evidence"]').textContent,/Finding only/);
 } finally {mounted.close();editor.destroy();sdk.graphql=previous;}
});

test('evidence load failure clears content from the previous snapshot',async()=>{
 const original=sdk.backend.getEvidence;
 const editor=new ui.Editor({extensions:ui.editorExtensions(sdk),content:{type:'doc',content:[{type:'evidence',attrs:{projectId:'project',evidenceId:'snapshot'}}]}});
 const mounted=mount({setup:()=>()=>ui.h(ui.EditorContent,{editor})});
 try {
  await settle();assert.match(mounted.host.textContent,/GET \/proof/);
  sdk.backend.getEvidence=async()=>({kind:'Error',error:'Snapshot unavailable'});
  editor.view.dispatch(editor.state.tr.setNodeMarkup(0,undefined,{projectId:'project',evidenceId:'missing'}));await settle();
  assert.match(mounted.host.textContent,/Snapshot unavailable/);assert(!mounted.host.textContent.includes('GET /proof'));
 } finally {editor.destroy();mounted.close();sdk.backend.getEvidence=original;}
});

test('Replay save failure retains the editable draft and allows retry',async()=>{
 record=undefined;const original=sdk.backend.saveReplayNote;let attempts=0;
 sdk.backend.saveReplayNote=async(...args)=>++attempts===1?{kind:'Error',error:'Conflict: recover or retry'}:original(...args);
 const mounted=mount(ui.ReplayNotes,{projectId:'project',sessionId:'session',title:'Replay'});
 try {
  await settle();const editable=mounted.host.querySelector('.tiptap');const view=editable.editor.view;view.dispatch(view.state.tr.insertText('Keep this draft'));await settle();
  const save=[...mounted.host.querySelectorAll('button')].find(button=>button.textContent==='Save');save.click();await settle();
  assert.match(mounted.host.textContent,/Conflict/);assert.match(editable.textContent,/Keep this draft/);assert.equal(record,undefined);
  assert(!save.disabled);save.click();await settle();assert(JSON.stringify(record.content).includes('Keep this draft'));
 } finally {mounted.close();sdk.backend.saveReplayNote=original;}
});
