import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { after, test } from 'node:test';
import { build } from 'esbuild';

const root = fileURLToPath(new URL('../', import.meta.url));
const temp = fs.mkdtempSync(path.join(root, '.notesplusplus-test-'));
const home = path.join(temp, 'home');
fs.mkdirSync(home);
const outfile = path.join(temp, 'backend.mjs');
await build({
  entryPoints: [path.join(root, 'packages/backend/src/api/index.ts')], outfile,
  bundle: true, platform: 'node', format: 'esm',
  plugins: [{ name: 'test-home', setup(build) {
    build.onResolve({ filter: /^os$/ }, () => ({ path: 'test-home', namespace: 'test' }));
    build.onLoad({ filter: /.*/, namespace: 'test' }, () => ({ contents: `export const homedir = () => ${JSON.stringify(home)};` }));
  } }],
});
const api = await import(pathToFileURL(outfile).href);
const { createSaveQueue } = await import('../packages/frontend/src/utils/saveQueue.ts');
const { fetchReplaySessionContent } = await import('../packages/frontend/src/utils/replay.ts');
const sdk = {
  api: { send() {} },
  projects: { getCurrent: async () => ({ getId: () => 'project-a' }) },
  console: { log() {}, error() {} },
  hostedFile: { getAll: async () => [{ id: 'hosted-1', path: path.join(home, 'hosted.txt') }] },
};
const doc = text => ({ type: 'doc', content: [{ type: 'paragraph', content: [{ type: 'text', text }] }] });
const notes = path.join(home, '.CaidoNotesPlusPlusV2', 'project-a');

test('HTTP byte capture preserves pairing, Unicode, binary and Base64-looking text without guessing', async () => {
  for (const payload of [Buffer.from('GET /café HTTP/1.1\r\n\r\n'),Buffer.from([0,255,128,13,10]),Buffer.from('SGVsbG8=')]) {
    let calls=0;
    const local={...sdk,requests:{get:async id=>{calls++;assert.equal(id,'sent');return {
      request:{getId:()=>id,getMethod:()=> 'GET',getUrl:()=> 'https://example.test/',getRaw:()=>({toBytes:()=>payload})},
      response:{getId:()=> 'paired',getRaw:()=>({toBytes:()=>payload})},
    };}}};
    for (const parts of ['request','response','both']) {
      const result=await api.getHttpEvidence(local,'project-a','sent',parts);
      assert.equal(result.kind,'Success',JSON.stringify(result));
      assert.equal(result.value.responseId,'paired');
      assert.equal(result.value.request,parts==='response'?undefined:payload.toString('base64'));
      assert.equal(result.value.response,parts==='request'?undefined:payload.toString('base64'));
      assert.equal((await api.saveEvidence(sdk,'project-a',{kind:'replay',title:'capture',...result.value})).kind,'Success');
    }
    assert.equal(calls,3,'each capture reads the paired exchange once');
  }
});

test('HTTP capture handles missing sources, limits, invalid inputs and project changes during lookup', async () => {
  const request={getId:()=> 'sent',getMethod:()=> 'GET',getUrl:()=> 'https://example.test/',getRaw:()=>({toBytes:()=>Buffer.from('request')})};
  const local={...sdk,requests:{get:async()=>({request})}};
  const missingResponse=await api.getHttpEvidence(local,'project-a','sent','both');
  assert.equal(missingResponse.kind,'Success'); assert.equal(missingResponse.value.response,undefined);
  assert.equal((await api.getHttpEvidence(local,'project-a','sent','invalid')).kind,'Error');
  assert.equal((await api.getHttpEvidence(local,'project-a','../bad','both')).kind,'Error');
  local.requests.get=async()=>undefined;
  assert.match((await api.getHttpEvidence(local,'project-a','sent','both')).error,/unavailable/);
  local.requests.get=async()=>({request:{...request,getRaw:()=>({toBytes:()=>Buffer.alloc(10*1024*1024+1)})}});
  assert.match((await api.getHttpEvidence(local,'project-a','sent','both')).error,/10 MB/);
  let project='project-a';
  local.projects={getCurrent:async()=>({getId:()=>project})};
  local.requests.get=async()=>{project='project-b';return {request};};
  assert.equal((await api.getHttpEvidence(local,'project-a','sent','both')).kind,'Error');
});

test('stable identity, revisions and conflicting writers survive moves', async () => {
  const first = await api.createNote(sdk, '/revision', doc('original'));
  assert.equal(first.kind, 'Success');
  assert.match(first.value.id, /^[a-f0-9-]{36}$/);
  const saved = await api.updateNote(sdk, '/revision', { content: doc('first writer'), revision: 0 }, 'project-a');
  assert.equal(saved.kind, 'Success'); assert.equal(saved.value.revision, 1);
  const stale = await api.updateNote(sdk, '/revision', { content: doc('stale writer'), revision: 0 }, 'project-a');
  assert.equal(stale.kind, 'Error'); assert.match(stale.error, /Conflict/);
  await api.moveItem(sdk, '/revision.json', '/revision-moved.json');
  const moved = await api.getNote(sdk, '/revision-moved');
  assert.equal(moved.value.id, first.value.id);
  assert.equal(moved.value.content.content[0].content[0].text, 'first writer');
  assert.equal(moved.value.content.notesplusplus, undefined);
});

test('Replay annotation lookup survives rename; concurrent first saves do not duplicate', async () => {
  const target = { sessionId: '12', entryId: '34' };
  assert.equal((await api.getReplayNote(sdk, 'project-a', target)).value, undefined);
  const results = await Promise.all([api.saveReplayNote(sdk, 'project-a', target, doc('one')), api.saveReplayNote(sdk, 'project-a', target, doc('two'))]);
  assert.equal(results.filter(result => result.kind === 'Success').length, 1);
  assert.equal(results.filter(result => result.kind === 'Error').length, 1);
  const first = results.find(result => result.kind === 'Success').value;
  await api.moveItem(sdk, first.path, '/moved-annotation.json');
  const found = await api.getReplayNote(sdk, 'project-a', target);
  assert.equal(found.value.id, first.id);
  assert.equal(found.value.path, '/moved-annotation.json');
  assert.equal((await api.saveReplayNote(sdk, 'project-b', target, doc('wrong project'))).kind, 'Error');
  assert.equal((await api.saveReplayNote(sdk, 'project-a', target, doc('updated'), first.revision)).kind, 'Success');
  const session = await api.saveReplayNote(sdk, 'project-a', { sessionId: '12' }, doc('session note'));
  assert.equal(session.kind, 'Success'); assert.notEqual(session.value.id, first.id);
});

test('Replay saves accept null optional arguments from JSON-style RPC serialization', async () => {
  const target={sessionId:'rpc-null'};
  const first=await api.saveReplayNote(sdk,'project-a',target,doc('first'),null,null);
  assert.equal(first.kind,'Success',JSON.stringify(first));
  assert.equal(first.value.revision,0);
  const second=await api.saveReplayNote(sdk,'project-a',target,doc('second'),0,null);
  assert.equal(second.kind,'Success',JSON.stringify(second));
  assert.equal(second.value.revision,1);
  assert.equal((await api.getReplayNote(sdk,'project-a',target)).value.content.content[0].content[0].text,'second');
  assert.equal((await api.saveReplayNote(sdk,'project-a',target,doc('stale'),null,null)).kind,'Error');
});

test('evidence preserves bytes, rejects paths and remains independent from note deletion', async () => {
  const raw = Buffer.from([71,69,84,0,255]).toString('base64');
  const saved = await api.saveEvidence(sdk, 'project-a', { kind: 'replay', title: 'binary', request: raw, sessionId: '12', entryId: '34' });
  assert.equal(saved.kind, 'Success');
  assert.equal((await api.getEvidence(sdk, 'project-a', saved.value.id)).value.request, raw);
  assert.equal((await api.getEvidence(sdk, 'project-a', '../../canary')).kind, 'Error');
  assert.equal((await api.getEvidence(sdk, 'project-b', saved.value.id)).kind, 'Error');
  assert.equal((await api.saveEvidence(sdk, 'project-a', { kind: 'replay', title: 'invalid', request: 'not base64!' })).kind, 'Error');
  await api.deleteNote(sdk, '/moved-annotation');
  assert.equal((await api.getEvidence(sdk, 'project-a', saved.value.id)).value.request, raw);
});

test('new document styles reject unsafe links, arbitrary CSS and unknown nodes', async () => {
  const unsafe = [
    {type:'doc',content:[{type:'script',text:'alert(1)'}]},
    {type:'doc',content:[{type:'paragraph',content:[{type:'text',text:'click',marks:[{type:'link',attrs:{href:'javascript:alert(1)'}}]}]}]},
    {type:'doc',content:[{type:'paragraph',content:[{type:'text',text:'font',marks:[{type:'font',attrs:{family:'url(https://evil.test)',size:'9999px'}}]}]}]},
  ];
  for (const document of unsafe) assert.equal((await api.createNote(sdk,'/unsafe-style',document)).kind,'Error');
  const first=await api.createNote(sdk,'/replaced-path',doc('first'));
  await api.deleteNote(sdk,'/replaced-path');
  const second=await api.createNote(sdk,'/replaced-path',doc('second'));
  assert.notEqual(first.value.id,second.value.id);
  assert.equal((await api.updateNote(sdk,'/replaced-path',{id:first.value.id,revision:0,content:doc('stale')})).kind,'Error');
  assert.equal((await api.getNote(sdk,'/replaced-path')).value.content.content[0].content[0].text,'second');
});

test('oversized snapshots are rejected before persistence', async () => {
  const result=await api.saveEvidence(sdk,'project-a',{kind:'replay',title:'oversized',request:Buffer.alloc(10*1024*1024+1).toString('base64')});
  assert.equal(result.kind,'Error');
});
after(() => {
  const resolved = path.resolve(temp);
  assert(resolved.startsWith(path.resolve(root) + path.sep + '.notesplusplus-test-'));
  fs.rmSync(resolved, { recursive: true, force: true });
});

test('CRUD works; traversal, roots, Windows paths and reserved metadata are rejected', async () => {
  assert.equal((await api.createNote(sdk, '/normal', doc('one'))).kind, 'Success');
  fs.writeFileSync(path.join(home, 'canary.txt'), 'do not touch');
  for (const input of ['../../escape', '/../escape', '.', '/', '..', 'C:/escape', '\\server\\share', 'a\\..\\escape', 'a/../b', '//server/share', '.notesplusplus-metadata/reminders', 'NUL', 'x:stream']) {
    assert.equal((await api.createNote(sdk, input, doc('bad'))).kind, 'Error', input);
    assert.equal((await api.deleteFolder(sdk, input)).kind, 'Error', input);
    assert.equal((await api.deleteNote(sdk, input)).kind, 'Error', input);
  }
  assert.equal(fs.readFileSync(path.join(home, 'canary.txt'), 'utf8'), 'do not touch');
  assert.equal((await api.moveItem(sdk, '/normal.json', '../../escape')).kind, 'Error');
  assert.equal((await api.updateNote(sdk, '/normal', { content: doc('wrong') }, 'project-b')).kind, 'Error');
  assert.equal((await api.updateNote(sdk, '/normal', { content: doc('two') }, 'project-a')).kind, 'Success');
  assert.equal((await api.moveItem(sdk, '/normal.json', '/renamed.json')).kind, 'Success');
  assert.equal((await api.getNote(sdk, '/renamed')).value.content.content[0].content[0].text, 'two');
  assert.equal((await api.deleteNote(sdk, '/renamed')).kind, 'Success');
});

test('folder moves into descendants and link traversal are rejected', async () => {
  await api.createFolder(sdk, '/folder');
  assert.equal((await api.moveItem(sdk, '/folder', '/folder/child')).kind, 'Error');
  const external = path.join(temp, 'external'); fs.mkdirSync(external);
  fs.symlinkSync(external, path.join(notes, 'linked'), os.platform() === 'win32' ? 'junction' : 'dir');
  assert.equal((await api.createNote(sdk, '/linked/escape', doc('bad'))).kind, 'Error');
  assert.equal((await api.deleteFolder(sdk, '/linked')).kind, 'Error');
  fs.unlinkSync(path.join(notes, 'linked'));
});

test('hosted reads require a server-resolved ID and enforce real size', async () => {
  const file = path.join(home, 'hosted.txt'); fs.writeFileSync(file, 'safe');
  assert.equal(await api.getFileContent(sdk, 'hosted-1'), 'safe');
  await assert.rejects(api.getFileContent(sdk, file), /not found/);
  fs.writeFileSync(file, Buffer.alloc(5 * 1024 * 1024 + 1));
  await assert.rejects(api.getFileContent(sdk, 'hosted-1'), /5 MB/);
});

test('reminders do not overwrite a user note named reminders', async () => {
  await api.createNote(sdk, '/reminders', doc('keep this note'));
  assert.equal((await api.createReminder(sdk, '/reminders.json', 'test', '2099-01-01T00:00:00Z')).kind, 'Success');
  assert.equal((await api.getNote(sdk, '/reminders')).value.content.content[0].content[0].text, 'keep this note');
  const tree = (await api.getTree(sdk)).value;
  assert(!tree.children.some(n => n.path.includes('.notesplusplus-')));
});

test('legacy reminders migrate with backup; corruption is not overwritten', async () => {
  const other = { ...sdk, projects: { getCurrent: async () => ({ getId: () => 'project-legacy' }) } };
  const folder = path.join(home, '.CaidoNotesPlusPlusV2', 'project-legacy');
  fs.mkdirSync(folder, { recursive: true });
  const reminder = { id: 'old', notePath: '/note', context: 'keep', reminderAt: '2099-01-01T00:00:00Z', createdAt: '2026-01-01T00:00:00Z', triggered: false, dismissed: false };
  fs.writeFileSync(path.join(folder, 'reminders.json'), JSON.stringify([reminder]));
  assert.equal((await api.getReminders(other)).value[0].id, 'old');
  assert(fs.readdirSync(folder).some(n => n.endsWith('.bak')));
  const target = path.join(folder, '.notesplusplus-metadata', 'reminders.json');
  fs.writeFileSync(target, 'corrupted');
  assert.equal((await api.createReminder(other, '/note', 'test', '2099-01-01T00:00:00Z')).kind, 'Error');
  assert.equal(fs.readFileSync(target, 'utf8'), 'corrupted');
});

test('migration preserves both versions on conflict', async () => {
  const legacy = path.join(home, '.CaidoNotesPlusPlus', 'project-a');
  fs.mkdirSync(legacy, { recursive: true }); fs.writeFileSync(path.join(legacy, 'conflict'), 'old');
  await api.createNote(sdk, '/conflict', doc('new'));
  assert.equal((await api.migrateNote(sdk, 'conflict', doc('old'))).kind, 'Error');
  assert.equal(fs.readFileSync(path.join(legacy, 'conflict'), 'utf8'), 'old');
  assert.equal((await api.getNote(sdk, '/conflict')).value.content.content[0].content[0].text, 'new');
  fs.writeFileSync(path.join(legacy, 'migrate'), 'old');
  assert.equal((await api.migrateNote(sdk, 'migrate', doc('old'))).kind, 'Success');
  assert(!fs.existsSync(path.join(legacy, 'migrate')));
});

test('invalid, unsafe and oversized documents cannot replace valid notes', async () => {
  await api.createNote(sdk, '/valid', doc('safe'));
  for (const content of [[], {}, JSON.parse('{"type":"doc","content":[],"__proto__":{"x":1}}'), doc('x'.repeat(10 * 1024 * 1024))]) {
    assert.equal((await api.updateNote(sdk, '/valid', { content })).kind, 'Error');
  }
  assert.equal((await api.getNote(sdk, '/valid')).value.content.content[0].content[0].text, 'safe');
  assert(!fs.readdirSync(notes).some(n => n.endsWith('.tmp')));
});

test('save queue snapshots notes and orders overlapping writes', async () => {
  const writes = []; let release;
  const gate = new Promise(resolve => { release = resolve; });
  const queue = createSaveQueue(async note => { await gate; writes.push(note); });
  const first = { project: 'a', path: '/A', content: doc('A changed') };
  const a = queue.save(first); first.content = doc('B selected');
  const b = queue.save({ project: 'a', path: '/B', content: doc('B changed') });
  release(); await Promise.all([a,b]);
  assert.deepEqual(writes.map(n => [n.path, n.content.content[0].content[0].text]), [['/A','A changed'], ['/B','B changed']]);
  assert.equal(queue.pending.size, 0);
});

test('failed saves remain recoverable and allow retry', async () => {
  let fail = true;
  const queue = createSaveQueue(async () => { if (fail) throw Error('disk full'); });
  await assert.rejects(queue.save({ project: 'a', path: '/A', content: doc('recover') }), /disk full/);
  assert.equal(queue.pending.size, 1);
  fail = false; await queue.save([...queue.pending.values()][0]);
  assert.equal(queue.pending.size, 0);
});

test('Replay HTTP union returns saved raw and prefers unsent draft', async () => {
  const mock = entry => ({ graphql: { replaySessionEntries: async () => ({ replaySession: { activeEntry: entry } }) } });
  const request = 'POST /a%20b HTTP/1.1\r\nHost: example.test\r\n\r\nação 😀 YWJj';
  assert.equal(await fetchReplaySessionContent(mock({ __typename: 'ReplayEntryHttp', raw: Buffer.from(request).toString('base64') }), '1'), request);
  assert.equal(await fetchReplaySessionContent(mock({ __typename: 'ReplayEntryHttp', raw: btoa('old'), draft: { raw: btoa('draft') } }), '1'), 'draft');
  assert.equal(await fetchReplaySessionContent(mock({ __typename: 'ReplayEntryHttp', raw: btoa('GET / HTTP/1.1\r\n\r\n\xff') }), '1'), 'GET / HTTP/1.1\r\n\r\n\xff');
  await assert.rejects(fetchReplaySessionContent(mock({ __typename: 'ReplayEntryHttp', raw: '!invalid!' }), '1'), /invalid Base64/);
  await assert.rejects(fetchReplaySessionContent(mock(undefined), '1'), /unavailable/);
  await assert.rejects(fetchReplaySessionContent(mock({ __typename: 'ReplayEntryWebSocket' }), '1'), /Only HTTP/);
  await assert.rejects(fetchReplaySessionContent(mock({ __typename: 'ReplayEntryHttp', raw: '' }), '1'), /empty/);
});
