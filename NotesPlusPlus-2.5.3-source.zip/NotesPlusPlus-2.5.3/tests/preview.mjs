// Optional local visual harness. Uses synthetic data only; never connects to Caido.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {build} from 'esbuild';
const root=fileURLToPath(new URL('../',import.meta.url));
const require=createRequire(path.join(root,'packages/frontend/package.json'));
const {parse,compileScript,compileTemplate}=require('vue/compiler-sfc');
const output=path.join(root,'dist/preview');fs.mkdirSync(output,{recursive:true});
await build({stdin:{contents:`
import {createApp} from 'vue';
import PrimeVue from 'primevue/config';
import {EditorView} from '@codemirror/view';
import {Classic} from '@caido/primevue';
import Preview from '${path.join(root,'tests/Preview.vue').replaceAll('\\','/')}';
import {SDKPlugin} from './src/plugins/sdk';
const listeners=new Set();let annotation;
const evidence=new Map([['sample',{id:'sample',projectId:'preview',kind:'replay',title:'Authorization test',capturedAt:'2026-09-29T15:00:00Z',sessionId:'43',entryId:'301',endpoint:'GET example.test/api/account',request:btoa('GET /api/account HTTP/1.1\\r\\nHost: example.test\\r\\nAccept: application/json\\r\\n\\r\\n'),response:btoa('HTTP/1.1 200 OK\\r\\nContent-Type: application/json\\r\\n\\r\\n{"id":42,"role":"reader"}')}]]);
const ok=value=>({kind:'Success',value});
const sdk={backend:{getCurrentProjectId:async()=>ok('preview'),getEvidence:async(_,id)=>ok(evidence.get(id)),saveEvidence:async(_,value)=>{const id=crypto.randomUUID();const stored={...value,id,projectId:'preview',capturedAt:new Date().toISOString()};evidence.set(id,stored);return ok(stored)},onEvent:(_,callback)=>{listeners.add(callback);return{stop:()=>listeners.delete(callback)}},getReplayNote:async()=>ok(annotation),saveReplayNote:async(_,target,content)=>{annotation={id:'note',revision:0,path:'/Replay Notes/Session.json',content};listeners.forEach(fn=>fn('preview'));return ok(annotation)}},replay:{getSessions:()=>[{id:'43',name:'Authorization test',entryIds:['301']}],getEntry:id=>({id,sessionId:'43',requestId:'request'}),openTab(){},showEntry:async()=>{}},graphql:{request:async()=>({request:{id:'request',raw:evidence.get('sample').request,method:'GET',host:'example.test',path:'/api/account',query:'',createdAt:new Date(),response:{id:'response',statusCode:200}}}),response:async()=>({response:{raw:evidence.get('sample').response}}),replaySessionEntries:async()=>({replaySession:{activeEntry:{__typename:'ReplayEntryHttp',raw:evidence.get('sample').request}}}),getFindingsByOffset:async()=>({findingsByOffset:{edges:[{node:{id:'finding',title:'Authorization review',host:'example.test',path:'/api/account'}}]}}),getFinding:async()=>({finding:{id:'finding',title:'Authorization review',description:'Synthetic finding for preview.',reporter:'Preview',host:'example.test',path:'/api/account',request:{id:'request'}}})},navigation:{goTo(){}},window:{showToast:console.log}};
sdk.backend.getHttpEvidence=async(_,id,parts)=>ok({requestId:id,responseId:'response',request:parts==='response'?undefined:evidence.get('sample').request,response:parts==='request'?undefined:evidence.get('sample').response});
const httpEditor=()=>{const view=new EditorView();return{getElement:()=>view.dom,getEditorView:()=>view};};
sdk.ui={httpRequestEditor:httpEditor,httpResponseEditor:httpEditor};
createApp(Preview).use(PrimeVue,{unstyled:true,pt:Classic}).use(SDKPlugin,sdk).mount('#app');
`,resolveDir:path.join(root,'packages/frontend')},nodePaths:[path.join(root,'packages/frontend/node_modules')],bundle:true,format:'esm',platform:'browser',outfile:path.join(output,'index.js'),alias:{'@':path.join(root,'packages/frontend/src')},define:{__VUE_OPTIONS_API__:'true',__VUE_PROD_DEVTOOLS__:'false',__VUE_PROD_HYDRATION_MISMATCH_DETAILS__:'false'},plugins:[{name:'vue',setup(builder){builder.onLoad({filter:/\.vue$/},args=>{const {descriptor}=parse(fs.readFileSync(args.path,'utf8'),{filename:args.path});const script=compileScript(descriptor,{id:'preview',inlineTemplate:!!descriptor.scriptSetup,genDefaultAs:'component'});let contents=script.content;if(!descriptor.scriptSetup&&descriptor.template)contents+='\n'+compileTemplate({source:descriptor.template.content,filename:args.path,id:'preview'}).code+'\ncomponent.render=render;';return{contents:contents+'\nexport default component;',loader:'ts',resolveDir:path.dirname(args.path)}});builder.onResolve({filter:/\.css\?raw$/},args=>({path:path.resolve(args.resolveDir,args.path.replace('@/',path.join(root,'packages/frontend/src/')).replace('?raw','')),namespace:'raw'}));builder.onLoad({filter:/.*/,namespace:'raw'},args=>({contents:'export default '+JSON.stringify(fs.readFileSync(args.path,'utf8')),loader:'js'}));}}]});
const html='<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="/index.css"><style>body{background:#27272a;color:#e4e4e7;font:14px system-ui;margin:0}.p-button{padding:6px;border:1px solid #52525b;border-radius:4px}.p-dialog{background:#27272a}.p-select{border:1px solid #52525b;padding:6px}</style></head><body><div id="app"></div><script type="module" src="/index.js"></script></body></html>';
http.createServer((request,response)=>{const route=request.url;if(route==='/'){response.setHeader('Content-Type','text/html');response.end(html)}else if(route==='/index.js'){response.setHeader('Content-Type','text/javascript');response.end(fs.readFileSync(path.join(output,'index.js')))}else if(route==='/index.css'){response.setHeader('Content-Type','text/css');response.end(fs.readFileSync(path.join(root,'packages/frontend/dist/index.css')))}else{response.statusCode=404;response.end()}}).listen(43821,'127.0.0.1',()=>console.log('Mock preview: http://127.0.0.1:43821'));
