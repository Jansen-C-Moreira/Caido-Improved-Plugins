# Notes++ 2.5.1

Target: Caido 0.58.3. Bug-fix release for 2.5.0.

## Historical evidence capture

Fixed the `Invalid Base64` error when inserting a historical Replay request, response, or both. The old implementation treated GraphQL request/response Blob strings as canonical Base64. The screenshot demonstrated that this assumption does not hold in the user's instance. The previous test fixtures repeated that assumption and therefore missed the integration defect.

Historical Replay and finding HTTP evidence now use the backend Requests SDK to retrieve one stored request/response pair, read each selected side with `getRaw().toBytes()`, and encode those bytes once for storage. No encoding heuristics or text conversion are applied. Current Replay drafts retain their separate existing capture path.

The byte API is documented in the [Caido Requests SDK reference](https://developer.caido.io/plugins/reference/sdks/backend/requests). Capture checks the expected project before and after lookup, rejects oversized evidence explicitly, and handles deleted requests and absent responses. Snapshot validation remains strict, with concise field-specific errors instead of a raw validation array.

## Additional fixes

- Failed Replay history pages retain unprocessed entries for retry. Finding discovery can also be retried after its first load fails.
- Picker controls are disabled during capture/loading; closed pickers cannot insert delayed results. Choices use readable labels such as **Request + Response** and **Finding only**.
- Evidence cards clear stale content on load failure and ignore outdated finding refresh results.
- Recovery copies pass the original project to the backend. Annotation loads ignore superseded results.
- Markdown export handles payloads with many backtick runs without a JavaScript argument-stack overflow.
- Binary evidence and hosted files produce explicit clipboard warnings instead of silently losing bytes. File exports retain original attachments.
- Tables containing multiline evidence, code, or other block content refer to labeled sections below the table, preserving valid code fences. Inline pipes are escaped.
- Changing export scope clears a previously prepared export and its warnings.

## Validation

39 automated tests passed. Coverage includes frontend capture through the actual backend capture/storage implementation with SDK doubles; original Unicode, binary and Base64-looking bytes; historical pairing and draft separation; missing responses/sources; size limits; project switches during lookup; finding capture; mounted Vue picker retry and insertion; stale card failures; removal/undo; annotation failed-save recovery; note identity/revisions/moves; unsafe content and filesystem protections; and single/bulk Markdown exports with attachments.

Type checking, lint, and the production build passed. The installable ZIP manifest and bundled backend API registration were checked.

These are automated tests with SDK doubles and a simulated DOM, not verification inside Caido. This release has not been installed or exercised in a real Caido 0.58.3 instance by the agent. The earlier 2.5.0 mock-preview checks did not establish the runtime format of GraphQL Blob strings.

## Installation

Install `dist/NotesPlusPlus-2.5.1.zip` as an update to Notes++. Reopen the plugin after the update, then retry the historical **Request + Response** selection. Existing notes and successfully stored snapshots require no content migration. Failed inserts did not create valid evidence cards.
