# Notes++ 2.4.1 — Caido 0.58.3

- Corrigida a exibição de requests em Base64: o campo Blob do GraphQL agora é decodificado uma única vez antes da visualização e exportação Markdown. Texto UTF-8 preserva acentos; conteúdo binário não UTF-8 mantém uma representação por byte. URLs percent-encoded e conteúdo Base64 dentro do corpo não são decodificados novamente.
- Botão X sempre visível no canto superior direito de cada referência ao Replay, com identificação acessível e acionamento por teclado. Remove somente a referência da nota, mantém a sessão no Replay e suporta Undo do editor.
- Respostas de carregamento pendentes não atualizam referências já removidas.
- 16 testes de regressão passaram, incluindo duas referências na mesma nota, alteração de posição antes da remoção, Undo e exportação do request decodificado. Validação DOM com JSDOM e SDK simulado; não houve teste dentro de uma instância real do Caido.

Instale `dist/plugin_package.zip` sobre a versão anterior. As notas existentes não precisam ser recriadas.
