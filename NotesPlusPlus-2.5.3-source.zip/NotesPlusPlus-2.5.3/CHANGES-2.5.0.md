# Notes++ 2.5.0

Targets Caido 0.58.3. All new controls and messages are in English.

## Evidence

- Type `@` or use the toolbar's **Insert evidence** button. Choose Replay or Findings, then search/select a source.
- Replay offers a current draft or individual sent executions, labeled with time, method, endpoint and response status. History loads in batches of 25; findings load in batches of 50. Search filters the loaded sources; use **Load more** for older entries.
- Insert a request, response, or matching pair. Drafts can only provide a request. Snapshots are the default; an explicit live draft option is available.
- Snapshots retain original Base64-encoded bytes and source IDs outside note text. They survive deletion of the original Caido source. Textual HTTP is read-only; binary content can be downloaded without decoding or modification.
- Cards support collapse, copy, removal with undo, and navigation to an exact Replay execution where available. Findings include title, description, reporter and endpoint; HTTP evidence is optional. **Refresh finding snapshot** creates a replacement snapshot, leaving the previous one available to undo.
- Existing Replay mentions remain live and now have explicit live labeling and collapse/copy controls.

## Editing and Replay annotations

- A shared toolbar provides headings, predefined fonts/sizes, bold, italic, underline, strike, highlighting, lists, quotations, links, code, tables, undo and redo.
- **Markdown** opens an insertion dialog with a sanitized preview. Markdown shortcuts remain available. This is not a full Markdown source-editing mode.
- Replay's **Notes** button opens **Session note** or **Execution note** for the target captured when the dialog opens. Unsaved drafts do not create notes. Click **Save** to persist changes under **Replay Notes**, then **Open in Notes++** to open that same document.
- Notes have stable IDs, revision checks and project-scoped associations. Renaming/moving a note retains its association. Changes made in either editor notify the other.
- Concurrent edits fail visibly instead of silently overwriting. Main-editor failed saves offer **Retry** and **Save recovery copy**. The Replay dialog preserves an unsaved draft, offers **Download draft**, and requires an explicit discard before reloading it. Draft downloads are JSON documents for recovery, not Markdown reports.

## Markdown exports

- **Copy as Markdown**, **Export Note**, **Export Folder**, and **Export Project** use the same serializer. Folder exports include the open note's folder and descendants.
- A note with no assets downloads as `.md`. Notes with assets and bulk exports download as ZIP files with relative asset links and sanitized, collision-safe filenames. Binary HTTP and hosted files are included as attachments; raster images are stored locally.
- Replay annotation exports identify their associated session/execution. Live data is resolved once per export. Missing sources produce a warning and an explicit option to export with placeholders.
- Underline, highlighting and font presets use generated `<u>`, `<mark>` and restricted `<span>` styles. Their appearance depends on the Markdown viewer. Clipboard exports cannot include binary attachments; use file export for them.

## Security, storage and compatibility

- Imported HTML is parsed in an inert template and rebuilt from an allowlist. Scripts, event handlers, remote images, arbitrary CSS and unsafe URL schemes are excluded. Finding descriptions and HTTP payloads are displayed as text.
- Backend validation checks supported nodes and marks, safe links and font presets. Existing path, symlink, hosted-file ID and project protections remain in place.
- Limits: 10 MB per note; 10 MB combined raw HTTP bytes per snapshot (with a separate serialized-size bound); 5 MB per hosted attachment. Oversized input fails explicitly without truncation.
- Existing note documents receive internal identity metadata without changing their editor content. New evidence is stored under the project's `.notesplusplus-metadata/evidence` directory. Removed references do not automatically delete snapshots, preserving undo/recovery. Back up the entire project note directory, including hidden metadata, to retain evidence.
- Do not edit new evidence-rich notes with an older plugin version: older editors do not understand the new nodes and marks.

## Validation

All 29 automated regression tests passed, covering storage/project isolation, identity and revisions, simultaneous first saves, renamed annotations, unsafe content, raw-byte preservation, historical pairing, export assets/collisions, mounted Vue evidence removal/undo, and Replay annotation saving. Type checking, lint (without warnings), and the production package build also passed.

A local browser preview with a synthetic SDK was used to exercise historical request/response insertion and quick Replay annotation saving. No real Caido session was attached to the available browser; installation and end-to-end behavior inside Caido 0.58.3 remain to be verified in the user's instance.

## Deferred ideas

Revision history/trash, export redaction previews, comparison between Replay executions, and templates/tags/backlinks are not included in this release.
