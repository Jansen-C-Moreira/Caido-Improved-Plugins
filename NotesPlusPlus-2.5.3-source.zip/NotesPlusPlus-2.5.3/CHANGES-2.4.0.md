# Notes++ 2.4.0 — versão local para Caido 0.58.3

Base: Notes++ 2.3.2, de Tanner Barnes e colaboradores. Licença MIT e atribuições originais preservadas. Esta é uma versão modificada localmente, não uma release oficial do projeto.

## Correções

- Replay: leitura da entrada HTTP pela resposta tipada de `replaySessionEntries`, incluindo rascunho ainda não enviado. A API atual distingue tipos de entrada; a antiga chamada de `replayEntry` não fornecia o novo parâmetro `sessionKind`. A visualização e a exportação agora compartilham uma única implementação. Sessões ausentes, vazias ou de outros protocolos recebem mensagens específicas.
- Atalho de envio do Replay: usa `sdk.replay.getCurrentSession()`, sem depender da estrutura HTML interna do Caido.
- Caminhos: validação antes de adicionar extensão, bloqueio de `..`, raiz, caminhos de Windows/UNC/ADS, nomes reservados e diretórios internos. Verificação de links existentes com as APIs de filesystem documentadas pelo Caido. Movimentação para dentro da própria pasta também é rejeitada.
- Arquivos incorporados: o backend recebe o ID do arquivo hospedado e resolve o caminho a partir do cadastro do Caido. Caminhos arbitrários não são aceitos. Limite real de 5 MB e apenas arquivos regulares.
- Salvamento: snapshots de projeto/caminho/conteúdo e fila de gravação ordenada, independentes do editor selecionado posteriormente. Respostas de erro são tratadas. Alterações com falha ficam em memória e podem ser reenviadas pelo botão Retry. O navegador recebe aviso de saída enquanto há alterações pendentes. Movimentação/exclusão aguarda as gravações e bloqueia se há erro pendente.
- Troca de projeto: gravações pendentes de outro projeto são rejeitadas; árvore/histórico são reiniciados. Atualizações atrasadas da árvore não substituem alterações mais recentes.
- Persistência: escrita em temporário seguida de rename, com validação do documento, tamanho em bytes e limites de complexidade. Não é garantia de durabilidade contra falha de energia (não há fsync nesta implementação).
- Lembretes: armazenamento separado em `.notesplusplus-metadata/reminders.json`. Arrays antigos são migrados preservando backup oculto; uma nota comum chamada `reminders` não é sobrescrita. Arquivo de lembretes corrompido causa erro em vez de ser silenciosamente substituído.
- Migração de notas: destino existente produz conflito e preserva ambas as versões. Falhas são mostradas e não entram na contagem de notas migradas.
- Imagens: URLs externas são bloqueadas na renderização, mantendo imagens PNG/JPEG/GIF/WebP embutidas em base64.
- Renderizadores: remoção do listener de Replay apenas da instância destruída; descarte de respostas antigas e limpeza de editores de arquivos.
- Dependências: SDKs 0.58.3, Tiptap 3.31.3 e tiptap-markdown 0.9.0. Dependências transitivas vulneráveis atualizadas com overrides explícitos e lockfile. Scripts de instalação desativados durante a preparação.
- CI: Node 24, pnpm 11, instalação com lockfile congelado e sem scripts; testes de regressão antes de publicar. O comando lint agora verifica sem alterar os arquivos; `lint:fix` é separado.

## Instalação e compatibilidade

1. Faça backup de `~/.CaidoNotesPlusPlusV2` e, se existir, `~/.CaidoNotesPlusPlus` na máquina que executa o backend do Caido. Se usa servidor remoto, o backup é nesse servidor.
2. No Caido 0.58.3, instale `dist/plugin_package.zip` pela opção de instalar plugin a partir de arquivo. Mantive o ID `notesplusplus`, portanto esta versão substitui a original.
3. Confira uma nota de teste, digitação seguida de troca imediata de nota, uma referência `@` ao Replay HTTP e a exportação Markdown.

As referências existentes mantêm os IDs das sessões/arquivos. A estrutura das notas continua em JSON e o diretório principal não foi alterado. Não apague os backups antes de conferir os dados.

## Validação automatizada

`pnpm test` executa testes de filesystem em diretório temporário, SDK simulado e testes DOM com JSDOM. Não acessa notas reais do usuário. Cobre traversal, links, CRUD/movimentação, troca de projeto, limites de arquivos/documentos, migrações, corrupção de lembretes, snapshots/falhas de gravação, Replay HTTP/rascunhos, imagens remotas, edição de tabelas e conversão Markdown.

Resultado final em 29/09/2026: **14 testes passaram**, `pnpm typecheck` e `pnpm lint` passaram, `pnpm peers check` não encontrou incompatibilidades, `pnpm audit` retornou zero alertas e `pnpm build` gerou o pacote 2.4.0. A auditoria é um retrato dos avisos conhecidos no registro, não uma certificação de segurança.

Não foi instalado nem testado dentro de uma instância real do Caido nesta etapa. Os testes de Replay usam o formato documentado/tipado do SDK 0.58.3. O diretório dos fontes mantém o nome original `NotesPlusPlus-2.3.2`, mas o manifest gerado identifica 2.4.0.

## Limites e próximos aprimoramentos

- Alterações pendentes ficam na memória da janela: o botão Retry não é um backup persistente e não protege contra encerramento forçado do processo.
- As notas continuam sem criptografia própria e acessíveis ao usuário do sistema operacional. Proteger o computador/servidor e seus backups continua necessário.
- As verificações de links não são uma barreira contra outro processo local hostil trocando arquivos entre a checagem e a operação; o runtime não expõe primitivas equivalentes a operações por descritor com no-follow.
- Esta versão incorpora Replay HTTP. Outros protocolos recebem aviso de incompatibilidade em vez de conteúdo vazio.
- Overrides de ferramentas de build devem ser revisados quando o pacote oficial de desenvolvimento do Caido atualizar suas dependências.

Melhorias sugeridas para uma próxima etapa:

1. Histórico de versões e lixeira, com recuperação de notas apagadas ou sobrescritas.
2. Snapshot fixo de request/response no momento de inserir o Replay, como alternativa à referência dinâmica, preservando evidência para relatórios.
3. Templates de achados, tags e busca no conteúdo, além do nome/caminho.
4. Backup/exportação de todas as notas com anexos e opção de criptografia.
