// packages/shared/src/tokens.ts
import { Buffer } from "buffer";
function objectJson(text) {
  const value = JSON.parse(text);
  if (typeof value !== "object" || value === null || Array.isArray(value))
    throw new Error("Enter a valid JSON object.");
  return value;
}
function decodeToken(token) {
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("JWT must have three segments.");
  return {
    header: objectJson(
      Buffer.from(
        (parts[0] ?? "").replace(/-/g, "+").replace(/_/g, "/"),
        "base64"
      ).toString("utf8")
    ),
    payload: objectJson(
      Buffer.from(
        (parts[1] ?? "").replace(/-/g, "+").replace(/_/g, "/"),
        "base64"
      ).toString("utf8")
    ),
    signature: parts[2] ?? ""
  };
}
function scanMessage(text) {
  const pattern = /(?<![A-Za-z0-9_.-])[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*(?![A-Za-z0-9_.-])/g;
  for (const match of text.matchAll(pattern)) {
    try {
      const { header } = decodeToken(match[0]);
      if (typeof header.alg === "string" || typeof header.typ === "string")
        return true;
    } catch {
    }
  }
  return false;
}

// packages/backend/src/index.ts
function containsJwt(message) {
  if (scanMessage(message.getRaw().toText())) return true;
  const body = message.getBody();
  return body !== void 0 && scanMessage(body.toText());
}
function init(sdk) {
  const status = {
    requests: 0,
    responses: 0,
    detections: 0,
    lastError: ""
  };
  sdk.api.register("getDetectionStatus", () => ({ ...status }));
  sdk.events.onInterceptRequest((_sdk, request) => {
    status.requests++;
    try {
      if (containsJwt(request)) {
        status.detections++;
        sdk.api.send("jwt:detected", {
          id: request.getId(),
          request: true,
          response: false
        });
      }
    } catch (error) {
      status.lastError = String(error);
      sdk.console.error(`JWT request detection failed: ${String(error)}`);
    }
  });
  sdk.events.onInterceptResponse((_sdk, request, response) => {
    status.responses++;
    try {
      const req = containsJwt(request);
      const res = containsJwt(response);
      if (req || res) {
        status.detections++;
        sdk.api.send("jwt:detected", {
          id: request.getId(),
          request: req,
          response: res
        });
      }
    } catch (error) {
      status.lastError = String(error);
      sdk.console.error(`JWT response detection failed: ${String(error)}`);
    }
  });
}
export {
  init
};
